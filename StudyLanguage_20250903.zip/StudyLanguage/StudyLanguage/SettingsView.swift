import SwiftUI

struct SettingsView: View {
    @StateObject private var settingsManager = SettingsManager()
    @StateObject private var practiceDatabase = PracticeDatabase()
    @State private var showingClearAlert = false
    @State private var clearAlertType: ClearAlertType = .all
    
    enum ClearAlertType {
        case all
        case current
    }
    
    var body: some View {
        NavigationView {
            Form {
                // MARK: - TTS Settings Section
                Section(header: Text("語音播放設定")) {
                    // Target Language Toggle
                    HStack {
                        Image(systemName: "target")
                            .foregroundColor(.blue)
                        Toggle("播放目標語言", isOn: $settingsManager.playTargetLanguage)
                    }
                    
                    // Native Language Toggle
                    HStack {
                        Image(systemName: "house")
                            .foregroundColor(.green)
                        Toggle("播放母語", isOn: $settingsManager.playNativeLanguage)
                    }
                    
                    // Playback Order
                    HStack {
                        Image(systemName: "arrow.up.arrow.down")
                            .foregroundColor(.orange)
                        
                        VStack(alignment: .leading) {
                            Text("播放順序")
                            Picker("播放順序", selection: $settingsManager.playbackOrder) {
                                ForEach(SettingsManager.PlaybackOrder.allCases, id: \.self) { order in
                                    Text(order.displayName).tag(order)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                        }
                    }
                    
                    // Repeat Count
                    HStack {
                        Image(systemName: "repeat")
                            .foregroundColor(.purple)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("單句播放次數")
                            Stepper(value: $settingsManager.singleSentenceRepeatCount, in: 1...10) {
                                Text("\(settingsManager.singleSentenceRepeatCount) 次")
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    
                    // Speech Rate
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "speedometer")
                                .foregroundColor(.red)
                            Text("播放速度")
                            Spacer()
                            Text(String(format: "%.1fx", settingsManager.speechRate))
                                .foregroundColor(.secondary)
                        }
                        
                        Slider(value: $settingsManager.speechRate, in: 0.1...2.0, step: 0.1) {
                            Text("播放速度")
                        } minimumValueLabel: {
                            Text("慢")
                                .font(.caption)
                        } maximumValueLabel: {
                            Text("快")
                                .font(.caption)
                        }
                    }
                }
                
                // MARK: - Continuous Play Section
                Section(header: Text("連續播放設定")) {
                    HStack {
                        Image(systemName: "play.circle")
                            .foregroundColor(.indigo)
                        Toggle("啟用連續播放", isOn: $settingsManager.continuousPlayEnabled)
                    }
                    
                    if settingsManager.continuousPlayEnabled {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Image(systemName: "timer")
                                    .foregroundColor(.cyan)
                                Text("句子間暫停時間")
                                Spacer()
                                Text(String(format: "%.1f秒", settingsManager.pauseBetweenSentences))
                                    .foregroundColor(.secondary)
                            }
                            
                            Slider(value: $settingsManager.pauseBetweenSentences, in: 0.0...5.0, step: 0.5) {
                                Text("暫停時間")
                            } minimumValueLabel: {
                                Text("0s")
                                    .font(.caption)
                            } maximumValueLabel: {
                                Text("5s")
                                    .font(.caption)
                            }
                        }
                    }
                }
                
                // MARK: - Progress Management Section
                Section(header: Text("學習進度管理")) {
                    // Clear All Progress
                    Button(action: {
                        clearAlertType = .all
                        showingClearAlert = true
                    }) {
                        HStack {
                            Image(systemName: "trash")
                                .foregroundColor(.red)
                            Text("清除所有學習進度")
                                .foregroundColor(.red)
                        }
                    }
                    
                    // Reset Settings
                    Button(action: {
                        settingsManager.resetToDefaults()
                    }) {
                        HStack {
                            Image(systemName: "arrow.counterclockwise")
                                .foregroundColor(.orange)
                            Text("重置設定為預設值")
                                .foregroundColor(.orange)
                        }
                    }
                }
                
                // MARK: - About Section
                Section(header: Text("關於")) {
                    HStack {
                        Image(systemName: "info.circle")
                            .foregroundColor(.blue)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("版本資訊")
                            Text("Language Study v1.0")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    HStack {
                        Image(systemName: "book")
                            .foregroundColor(.green)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("課程架構")
                            Text("100課 × 30句")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    HStack {
                       Image(systemName: "envelope")
                           .foregroundColor(.orange)
                       VStack(alignment: .leading, spacing: 2) {
                           Text("服務信箱")
                           Text("share35app@gmail.com")
                               .font(.caption)
                               .foregroundColor(.secondary)
                       }
                   }
                    
                }
            }
            .navigationTitle("設定")
            .navigationBarTitleDisplayMode(.inline)
            .alert("清除學習進度", isPresented: $showingClearAlert) {
                Button("取消", role: .cancel) {}
                Button("清除", role: .destructive) {
                    switch clearAlertType {
                    case .all:
                        practiceDatabase.clearAllProgress()
                    case .current:
                        // This would require course context
                        break
                    }
                }
            } message: {
                Text(clearAlertType == .all ?
                     "確定要清除所有課程的學習進度嗎？此操作無法復原。" :
                     "確定要清除當前課程的學習進度嗎？此操作無法復原。")
            }
        }
    }
}

// MARK: - Preview
struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
