import Foundation
import SQLite3
import os.log

class PracticeDatabase: ObservableObject {
    private var db: OpaquePointer?
    private let logger = Logger(subsystem: "org.share35app.BibleTTS", category: "PracticeDatabase")
    
    init() {
        openDatabase()
        createTables()
    }
    
    private func openDatabase() {
        let fileURL = try! FileManager.default
            .url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
            .appendingPathComponent("practise.db")
        
        if sqlite3_open(fileURL.path, &db) == SQLITE_OK {
            logger.info("Successfully opened practice database")
        } else {
            logger.error("Unable to open practice database")
            db = nil
        }
    }
    
    private func createTables() {
        let createTableSQL = """
        CREATE TABLE IF NOT EXISTS practice_progress (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lesson_id INTEGER NOT NULL,
            course_sort_order INTEGER NOT NULL,
            target_language TEXT NOT NULL,
            native_language TEXT NOT NULL,
            completed_count INTEGER DEFAULT 0,
            total_practice_count INTEGER DEFAULT 0,
            last_practiced_date TEXT,
            is_completed INTEGER DEFAULT 0,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(lesson_id, course_sort_order, target_language, native_language)
        );
        """
        
        if sqlite3_exec(db, createTableSQL, nil, nil, nil) == SQLITE_OK {
            logger.info("Practice progress table created successfully")
        } else {
            logger.error("Failed to create practice progress table")
        }
    }
    
    // MARK: - Progress Management
    
    func updateProgress(lessonId: Int, courseOrder: Int, targetLang: String, nativeLang: String, isCompleted: Bool = false) {
        let insertOrUpdateSQL = """
        INSERT OR REPLACE INTO practice_progress 
        (lesson_id, course_sort_order, target_language, native_language, 
         completed_count, total_practice_count, last_practiced_date, is_completed, updated_at)
        VALUES (?, ?, ?, ?, 
                COALESCE((SELECT completed_count FROM practice_progress 
                         WHERE lesson_id = ? AND course_sort_order = ? AND target_language = ? AND native_language = ?), 0) + ?,
                COALESCE((SELECT total_practice_count FROM practice_progress 
                         WHERE lesson_id = ? AND course_sort_order = ? AND target_language = ? AND native_language = ?), 0) + 1,
                ?, ?, ?);
        """
        
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, insertOrUpdateSQL, -1, &statement, nil) == SQLITE_OK {
            let currentDate = ISO8601DateFormatter().string(from: Date())
            
            sqlite3_bind_int(statement, 1, Int32(lessonId))
            sqlite3_bind_int(statement, 2, Int32(courseOrder))
            sqlite3_bind_text(statement, 3, targetLang, -1, nil)
            sqlite3_bind_text(statement, 4, nativeLang, -1, nil)
            
            // For completed count check
            sqlite3_bind_int(statement, 5, Int32(lessonId))
            sqlite3_bind_int(statement, 6, Int32(courseOrder))
            sqlite3_bind_text(statement, 7, targetLang, -1, nil)
            sqlite3_bind_text(statement, 8, nativeLang, -1, nil)
            sqlite3_bind_int(statement, 9, isCompleted ? 1 : 0)
            
            // For total practice count check
            sqlite3_bind_int(statement, 10, Int32(lessonId))
            sqlite3_bind_int(statement, 11, Int32(courseOrder))
            sqlite3_bind_text(statement, 12, targetLang, -1, nil)
            sqlite3_bind_text(statement, 13, nativeLang, -1, nil)
            
            sqlite3_bind_text(statement, 14, currentDate, -1, nil)
            sqlite3_bind_int(statement, 15, isCompleted ? 1 : 0)
            sqlite3_bind_text(statement, 16, currentDate, -1, nil)
            
            if sqlite3_step(statement) == SQLITE_DONE {
                logger.info("Progress updated for lesson \(lessonId)")
            } else {
                logger.error("Failed to update progress")
            }
        }
        
        sqlite3_finalize(statement)
    }
    
    func getCompletedLessons(courseOrder: Int, targetLang: String, nativeLang: String) -> Set<Int> {
        let querySQL = """
        SELECT lesson_id FROM practice_progress 
        WHERE course_sort_order = ? AND target_language = ? AND native_language = ? AND is_completed = 1;
        """
        
        var statement: OpaquePointer?
        var completedLessons: Set<Int> = []
        
        if sqlite3_prepare_v2(db, querySQL, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_int(statement, 1, Int32(courseOrder))
            sqlite3_bind_text(statement, 2, targetLang, -1, nil)
            sqlite3_bind_text(statement, 3, nativeLang, -1, nil)
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let lessonId = Int(sqlite3_column_int(statement, 0))
                completedLessons.insert(lessonId)
            }
        }
        
        sqlite3_finalize(statement)
        return completedLessons
    }
    
    func getProgressStats(courseOrder: Int, targetLang: String, nativeLang: String) -> (completed: Int, total: Int, totalPractice: Int) {
        let querySQL = """
        SELECT 
            COUNT(CASE WHEN is_completed = 1 THEN 1 END) as completed,
            COUNT(*) as total,
            SUM(total_practice_count) as total_practice
        FROM practice_progress 
        WHERE course_sort_order = ? AND target_language = ? AND native_language = ?;
        """
        
        var statement: OpaquePointer?
        var stats = (completed: 0, total: 0, totalPractice: 0)
        
        if sqlite3_prepare_v2(db, querySQL, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_int(statement, 1, Int32(courseOrder))
            sqlite3_bind_text(statement, 2, targetLang, -1, nil)
            sqlite3_bind_text(statement, 3, nativeLang, -1, nil)
            
            if sqlite3_step(statement) == SQLITE_ROW {
                stats.completed = Int(sqlite3_column_int(statement, 0))
                stats.total = Int(sqlite3_column_int(statement, 1))
                stats.totalPractice = Int(sqlite3_column_int(statement, 2))
            }
        }
        
        sqlite3_finalize(statement)
        return stats
    }
    
    // MARK: - Database Management
    
    func clearAllProgress() {
        let deleteSQL = "DELETE FROM practice_progress;"
        
        if sqlite3_exec(db, deleteSQL, nil, nil, nil) == SQLITE_OK {
            logger.info("All practice progress cleared successfully")
        } else {
            logger.error("Failed to clear practice progress")
        }
    }
    
    func clearCourseProgress(courseOrder: Int, targetLang: String, nativeLang: String) {
        let deleteSQL = """
        DELETE FROM practice_progress 
        WHERE course_sort_order = ? AND target_language = ? AND native_language = ?;
        """
        
        var statement: OpaquePointer?
        
        if sqlite3_prepare_v2(db, deleteSQL, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_int(statement, 1, Int32(courseOrder))
            sqlite3_bind_text(statement, 2, targetLang, -1, nil)
            sqlite3_bind_text(statement, 3, nativeLang, -1, nil)
            
            if sqlite3_step(statement) == SQLITE_DONE {
                logger.info("Course progress cleared successfully")
            } else {
                logger.error("Failed to clear course progress")
            }
        }
        
        sqlite3_finalize(statement)
    }
    
    deinit {
        sqlite3_close(db)
    }
}
