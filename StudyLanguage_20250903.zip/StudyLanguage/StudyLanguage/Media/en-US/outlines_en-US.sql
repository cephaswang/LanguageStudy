BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES


 ('en-US','Basic Daily Expressions',1),
 ('en-US','Social Life & Interests',2),
 ('en-US','Home & Daily Life',3),
 ('en-US','Study & Work',4),
 ('en-US','Travel & Culture',5),
 ('en-US','Advanced Communication',6),
 ('en-US','Society & News',7),
 ('en-US','Advanced Thinking',8),
 ('en-US','Professional Language',9),
 ('en-US','Integrated Application',10);


COMMIT;
