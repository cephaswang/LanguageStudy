//
//  aiApp.swift
//  ai
//
//  Created by admin on 2025/8/26.
//

import SwiftUI

@main
struct aiApp: App {
    var body: some Scene {
        WindowGroup {
              ContentView()
            
          //  ContentView303()
          //  StudyPathView()
           // PhrasePage()
           // PhasePinPage()
        }
    }
}
