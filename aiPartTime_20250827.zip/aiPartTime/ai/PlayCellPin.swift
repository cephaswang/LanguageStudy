import SwiftUI
import AVFoundation

/*
// 單例播放器：確保一次只播放一個音檔，且不循環
final class AudioPlaybackCenter {
    static let shared = AudioPlaybackCenter()
    private var player: AVAudioPlayer?

    func play(fileName: String) {
        let name = (fileName as NSString).deletingPathExtension
        var ext = (fileName as NSString).pathExtension
        if ext.isEmpty { ext = "mp3" }

        guard let url = Bundle.main.url(forResource: name, withExtension: ext) else {
            print("Audio file not found in bundle: \(fileName)")
            return
        }

        player?.stop()

        do {
            let newPlayer = try AVAudioPlayer(contentsOf: url)
            newPlayer.numberOfLoops = 0
            newPlayer.prepareToPlay()
            newPlayer.play()
            self.player = newPlayer
        } catch {
            print("Failed to init AVAudioPlayer: \(error)")
        }
    }
}*/

struct PlayCellPin: View {
    let targetLanguage: String
    let nativeLanguage: String
    let pinyin: String
    let audioFileName: String  // e.g. "en001.mp3"

    @State private var isCoolingDown = false

    var body: some View {
        HStack {
            // 左側文字區塊
            VStack(alignment: .leading, spacing: 8) {
                // 母語
                Text(nativeLanguage)
                    .font(.system(size: 16, weight: .regular))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.leading)

                // 拼音
                Text(pinyin)
                    .font(.system(size: 16, weight: .regular))
                    .foregroundColor(.gray)
                    .multilineTextAlignment(.leading)

                // 目標語言
                Text(targetLanguage)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
                    .multilineTextAlignment(.leading)
                
                Button {
                    guard !isCoolingDown else { return }
                    isCoolingDown = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                        isCoolingDown = false
                    }
                    AudioPlaybackCenter.shared.play(fileName: audioFileName)
                } label: {
                    if isCoolingDown {
                        // 事件期間：紅色，無底
                        Image(systemName: "speaker.wave.2.fill")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 32, height: 32)
                            .foregroundColor(.red)
                    } else {
                        // 平時：有圓底
                        ZStack {
                            Circle()
                                .fill(Color.gray.opacity(0.2))
                                .frame(width: 48, height: 48)
                            Image(systemName: "speaker.wave.2.fill")
                                .resizable()
                                .scaledToFit()
                                .frame(width: 24, height: 24)
                                .foregroundColor(.primary)
                        }
                    }
                }
                .disabled(isCoolingDown)
                .animation(.easeInOut(duration: 0.2), value: isCoolingDown)
                
            }

            Spacer() // 撐開，讓右側靠右

            // 右側按鈕
            VStack {
                
                Text("左側元件")

            }
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 16)
        .frame(
            width: UIScreen.main.bounds.width * 0.9,
            height: UIScreen.main.bounds.width * 0.4
        )
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 4)
    }
}

#Preview {
    PlayCellPin(
        targetLanguage: "Hello",
        nativeLanguage: "你好",
        pinyin: "nǐ hǎo",
        audioFileName: "en001.mp3"
    )
}
