import SwiftUI
import AVFoundation

// 簡單的單例播放器：確保一次只播放一個音檔，且不循環
final class AudioPlaybackCenter {
    static let shared = AudioPlaybackCenter()
    private var player: AVAudioPlayer?

    func play(fileName: String) {
        // 將 "en001.mp3" 拆成名稱與副檔名
        let name = (fileName as NSString).deletingPathExtension
        var ext = (fileName as NSString).pathExtension
        if ext.isEmpty { ext = "mp3" }

        guard let url = Bundle.main.url(forResource: name, withExtension: ext) else {
            print("Audio file not found in bundle: \(fileName)")
            return
        }

        // 停掉上一個播放
        player?.stop()

        do {
            let newPlayer = try AVAudioPlayer(contentsOf: url)
            newPlayer.numberOfLoops = 0      // 播放一次
            newPlayer.prepareToPlay()
            newPlayer.play()
            self.player = newPlayer
        } catch {
            print("Failed to init AVAudioPlayer: \(error)")
        }
    }
}

struct PlayCell: View {
    // 定義屬性，傳入目標語言、母語文字與音檔名
    let targetLanguage: String
    let nativeLanguage: String
    let audioFileName: String  // e.g. "en001.mp3"

    // 5 秒冷卻控制
    @State private var isCoolingDown = false

    var body: some View {
        VStack(spacing: 20) {
            HStack(spacing: 12) {
                Spacer()
                Image(systemName: "headphones")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 16, height: 16)
                    .foregroundColor(.green)
                Text("純聽模式")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.green)
                Spacer()
            }
            .padding(.top, 20)

            Spacer()

            // 母語
            Text(nativeLanguage)
                .font(.system(size: 16, weight: .regular))
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 8)

            // 目標語言
            Text(targetLanguage)
                .font(.system(size: 18, weight: .semibold))
                .foregroundColor(.black)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 8)

            Spacer()

            // 揚聲器：點擊播放對應音檔一次
            Button {
                // 5 秒處理期間不接受新事件
                guard !isCoolingDown else { return }
                isCoolingDown = true

                // 5 秒後還原
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    isCoolingDown = false
                }
                
                // 播放音檔
                AudioPlaybackCenter.shared.play(fileName: audioFileName)

            } label: {
                Image(systemName: "speaker.wave.2.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 32, height: 32)
                    .padding(.bottom, 20)
                    // 點選後變紅，5 秒後還原
                    .foregroundColor(isCoolingDown ? .red : .primary)
                    .accessibilityLabel(Text(isCoolingDown
                        ? "冷卻中，稍後可再次播放"
                        : "播放音檔 \(audioFileName)"))
            }
            // 冷卻中停用按鈕（不接收事件）
            .disabled(isCoolingDown)
            .animation(.easeInOut(duration: 0.2), value: isCoolingDown)
        }
        .padding(.vertical, 8)
        .padding(.horizontal, 16)
        .frame(
            width: UIScreen.main.bounds.width * 0.7,
            height: UIScreen.main.bounds.width * 0.7
        ) // 頁面寬度 * 0.7
        .background(Color.white)   // 白底
        .cornerRadius(30)          // 圓角
        .shadow(radius: 4)         // 陰影 (可選)
    }
}
