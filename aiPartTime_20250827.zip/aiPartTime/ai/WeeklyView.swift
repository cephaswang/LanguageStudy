import SwiftUI
import Foundation

struct WeeklyView: View {
    @State private var startDate = Date()
    // Initialize arrays with default values instead of empty arrays
    @State private var studyData: [Int] = Array(repeating: 0, count: 7)
    @State private var reviewData: [Int] = Array(repeating: 0, count: 7)
    
    private let weekdays = ["日", "一", "二", "三", "四", "五", "六"]
    private let maxCount = 10
    private let chartHeight: CGFloat = 300
    private let chartWidth: CGFloat = 280
    private let barWidth: CGFloat = 30
    
    var body: some View {
        VStack(spacing: 20) {
            // 標題和導航控制列
            headerView
            
            // 統計圖表
            chartView
            
            Spacer()
        }
        .padding()
        .onAppear {
            generateRandomData()
        }
    }
    
    // MARK: - 標題列
    private var headerView: some View {
        HStack {
            // 學習標示
            HStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 4)
                    .fill(Color.green.opacity(0.3))
                    .frame(width: 16, height: 16)
                Text("學習")
                    .font(.system(size: 16, weight: .medium))
            }
            
            // 複習標示
            HStack(spacing: 8) {
                RoundedRectangle(cornerRadius: 4)
                    .fill(Color.blue)
                    .frame(width: 16, height: 16)
                Text("複習")
                    .font(.system(size: 16, weight: .medium))
            }
            
            Spacer()
            
            // 導航控制
            HStack(spacing: 15) {
                Button(action: previousWeek) {
                    Image(systemName: "chevron.left")
                        .font(.title2)
                        .foregroundColor(.gray)
                }
                
                Text(currentWeekText)
                    .font(.system(size: 16, weight: .semibold))
                    .frame(minWidth: 120)
                
                Button(action: nextWeek) {
                    Image(systemName: "chevron.right")
                        .font(.title2)
                        .foregroundColor(.gray)
                }
            }
        }
    }
    
    // MARK: - 圖表視圖
    private var chartView: some View {
        VStack(spacing: 8) {
            // 圖表主體
            HStack(alignment: .bottom, spacing: 0) {
                // Y軸標籤（0到10，從下到上）
                VStack(alignment: .trailing, spacing: 0) {
                    // 頂部標題
                    Text("次數")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(.black)
                        .frame(height: 20)
                    
                    ForEach((0...maxCount).reversed(), id: \.self) { count in
                        Text("\(count)")
                            .font(.system(size: 12))
                            .foregroundColor(.gray)
                            .frame(height: (chartHeight - 20) / CGFloat(maxCount + 1))
                    }
                }
                .padding(.trailing, 8)
                
                // 圖表區域
                ZStack(alignment: .bottomLeading) {
                    // 背景網格線
                    gridLines
                    
                    // 數據條形圖
                    HStack(alignment: .bottom, spacing: 0) {
                        ForEach(weekdays.indices, id: \.self) { dayIndex in
                            dayBarsView(for: dayIndex)
                        }
                    }
                }
                .frame(width: chartWidth, height: chartHeight + 20)
            }
            
            // X軸標籤（週日到週六）
            xAxisLabels
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.gray.opacity(0.05))
        )
    }
    
    // MARK: - 網格線
    private var gridLines: some View {
        ZStack {
            // 水平網格線（對應Y軸的數值）
            VStack(spacing: 0) {
                ForEach(0...maxCount, id: \.self) { _ in
                    Rectangle()
                        .fill(Color.gray.opacity(0.2))
                        .frame(height: 0.5)
                        .frame(maxWidth: .infinity)
                    Spacer()
                }
            }
            
            // 垂直網格線（對應X軸的日期）
            HStack(spacing: 0) {
                ForEach(0..<weekdays.count, id: \.self) { _ in
                    Rectangle()
                        .fill(Color.gray.opacity(0.2))
                        .frame(width: 0.5)
                        .frame(maxHeight: .infinity)
                    Spacer()
                }
                // 最後一條線
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 0.5)
                    .frame(maxHeight: .infinity)
            }
        }
    }
    
    // MARK: - 每日數據條形圖
    private func dayBarsView(for dayIndex: Int) -> some View {
        // Add bounds checking as an extra safety measure
        let studyCount = dayIndex < studyData.count ? studyData[dayIndex] : 0
        let reviewCount = dayIndex < reviewData.count ? reviewData[dayIndex] : 0
        let dayWidth = chartWidth / CGFloat(weekdays.count)
        let barHeight = chartHeight / CGFloat(maxCount)
        
        return HStack(alignment: .bottom, spacing: 1) {
            // 學習數據條（淺綠色）- 底部對齊
            Rectangle()
                .fill(Color.green.opacity(0.3))
                .frame(width: barWidth / 2, height: CGFloat(studyCount) * barHeight)
            
            // 複習數據條（藍色）- 底部對齊
            Rectangle()
                .fill(Color.blue)
                .frame(width: barWidth / 2, height: CGFloat(reviewCount) * barHeight)
        }
        .frame(width: dayWidth, height: chartHeight, alignment: .bottom)
    }
    
    // MARK: - X軸標籤
    private var xAxisLabels: some View {
        HStack(spacing: 0) {
            ForEach(weekdays.indices, id: \.self) { index in
                dayLabelView(for: index)
            }
        }
        .padding(.top, 4)
    }
    
    // MARK: - 單日標籤視圖
    private func dayLabelView(for index: Int) -> some View {
        let dayDate = Calendar.current.date(byAdding: .day, value: index, to: startOfWeek(for: startDate)) ?? startDate
        let dayFormatter = DateFormatter()
        dayFormatter.dateFormat = "d"
        
        return VStack(spacing: 2) {
            Text(dayFormatter.string(from: dayDate))
                .font(.system(size: 11))
                .foregroundColor(.gray)
            Text(weekdays[index])
                .font(.system(size: 12))
                .foregroundColor(.gray)
        }
        .frame(width: chartWidth / CGFloat(weekdays.count))
    }
    
    // MARK: - 計算屬性
    private var currentWeekText: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy年M月"
        return formatter.string(from: startDate)
    }
    
    // MARK: - 輔助方法
    private func startOfWeek(for date: Date) -> Date {
        let calendar = Calendar.current
        let components = calendar.dateComponents([.yearForWeekOfYear, .weekOfYear], from: date)
        return calendar.date(from: components) ?? date
    }
    
    private func previousWeek() {
        startDate = Calendar.current.date(byAdding: .weekOfYear, value: -1, to: startDate) ?? startDate
        generateRandomData()
    }
    
    private func nextWeek() {
        startDate = Calendar.current.date(byAdding: .weekOfYear, value: 1, to: startDate) ?? startDate
        generateRandomData()
    }
    
    private func generateRandomData() {
        studyData = (0..<7).map { _ in Int.random(in: 0...maxCount) }
        reviewData = (0..<7).map { _ in Int.random(in: 0...maxCount) }
    }
}

// MARK: - 預覽
struct WeeklyView_Previews: PreviewProvider {
    static var previews: some View {
        WeeklyView()
            .previewLayout(.sizeThatFits)
            .padding()
    }
}
