import SwiftUI

struct StudyPathView: View {
    // 左側級別項目 (3*5 = 15個級別)
    let leftItems = [
        "A1", "|", "|",
        "A2", "|", "|",
        "B1", "|", "|",
        "B2", "|", "|",
        "C1", "|", "|"
    ]
    
    let rightItems = [
        "入門級", "初階", "進階",
        "基礎級", "初階", "進階",
        "進階級", "初階", "進階",
        "高階級", "初階", "進階",
        "流利級", "初階", "進階"
    ]
    
    // 設定值陣列 - 可手動修改每個級別的狀態
    // 0: 淺灰色(未完成), 1: 淺土黃色(已完成)
    @State private var levelStates: [Int] = [
        1, 1, 1,  // A1: 已完成, |: 已完成, |: 已完成
        1, 1, 1,  // A2: 已完成, |: 已完成, |: 已完成
        0, 0, 0,  // B1: 未完成, |: 未完成, |: 未完成
        0, 0, 0,  // B2: 未完成, |: 未完成, |: 未完成
        0, 0, 0   // C1: 未完成, |: 未完成, |: 未完成
    ]
    
    // 右側 StepStatusView 的進度參數陣列
    @State private var rightItemsProgress: [Int] = [
        0, 86, 45,    // 入門級: 0%, 初階: 86%, 進階: 45%
        0, 72, 30,    // 基礎級: 0%, 初階: 72%, 進階: 30%
        0, 0, 0,      // 進階級: 0%, 初階: 0%, 進階: 0%
        0, 0, 0,      // 高階級: 0%, 初階: 0%, 進階: 0%
        0, 0, 0       // 流利級: 0%, 初階: 0%, 進階: 0%
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                GeometryReader { geometry in
                    let screenWidth = geometry.size.width
                    let padding = screenWidth * 0.05   // 左右邊距各5%
                    let availableWidth = screenWidth - (padding * 2) // 扣除左右邊距後的可用寬度
                    let spacing = availableWidth * 0.05   // 間距佔可用寬度5%
                    let leftWidth = availableWidth * 0.25  // 左側佔可用寬度25%
                    let rightWidth = availableWidth - leftWidth - spacing // 右側佔剩餘寬度
                    let itemHeight = screenWidth * 0.12 // 項目高度基於螢幕寬度12%
                    let circleSize = screenWidth * 0.13 // 圓形大小基於螢幕寬度13%
                    
                    HStack(alignment: .top, spacing: spacing) {
                        // 左側列表 - 基於頁寬比例
                        VStack(alignment: .leading, spacing: 0) { // 改為無間隔，直接疊放
                            ForEach(0..<leftItems.count, id: \.self) { index in
                                StudyLevelItemView(
                                    text: leftItems[index],
                                    isTitle: isTitle(leftItems[index]),
                                    isPlaceholder: leftItems[index] == "|",
                                    colorState: levelStates[index],
                                    isLastPlaceholder: isLastPlaceholder(index),
                                    itemHeight: itemHeight,
                                    circleSize: circleSize
                                )
                            }
                        }
                        .frame(width: leftWidth, alignment: .leading)
                        
                        // 右側列表 - 基於頁寬比例，直接對應左側每個項目
                        VStack(alignment: .leading, spacing: 0) { // 改為無間隔，直接疊放
                            ForEach(0..<rightItems.count, id: \.self) { index in
                                if isTitle(rightItems[index]) {
                                    // 標題項目 - 對應左側圓形
                                    StudyItemView(
                                        text: rightItems[index],
                                        isTitle: true,
                                        isPlaceholder: false,
                                        itemHeight: circleSize
                                    )
                                    .frame(height: circleSize) // 與左側圓形對齊
                                } else {
                                    // 初階、進階項目 - 對應左側垂直線
                                    StepStatusView(
                                        level: rightItems[index],
                                        progress: rightItemsProgress[index]
                                    ) { level, progress in
                                        print("點擊了級別: \(level), 進度: \(progress)%")
                                    }
                                    .frame(height: itemHeight) // 與左側垂直線對齊
                                }
                            }
                        }
                        .frame(width: rightWidth, alignment: .leading)
                    }
                    .padding(.horizontal, padding) // 使用計算好的邊距
                    .padding(.top, screenWidth * 0.05) // 頂部邊距為寬度5%
                    .frame(height: calculateContentHeight(itemHeight: itemHeight, circleSize: circleSize)) // 設定內容總高度
                }
                .frame(height: calculateContentHeight(itemHeight: UIScreen.main.bounds.width * 0.12, circleSize: UIScreen.main.bounds.width * 0.13)) // 為 GeometryReader 提供高度
            }
            .navigationTitle("StudyPath")
            .navigationBarTitleDisplayMode(.large)
        }
    }
    
    // 計算內容總高度的輔助函數
    private func calculateContentHeight(itemHeight: CGFloat, circleSize: CGFloat) -> CGFloat {
        let topPadding = UIScreen.main.bounds.width * 0.05
        let totalHeight = topPadding + (circleSize * 5) + (itemHeight * 10) // 5個圓形 + 10個垂直線/StepView
        return totalHeight + 50 // 額外的底部空間
    }
    
    func isTitle(_ text: String) -> Bool {
        return ["A1", "A2", "B1", "B2", "C1", "入門級", "基礎級", "進階級", "高階級", "流利級"].contains(text)
    }
    
    func isLastPlaceholder(_ index: Int) -> Bool {
        // 檢查是否為C1後面的兩個"|" (索引13, 14)
        return [13, 14].contains(index) && leftItems[index] == "|"
    }
}

struct StudyLevelItemView: View {
    let text: String
    let isTitle: Bool
    let isPlaceholder: Bool
    let colorState: Int
    let isLastPlaceholder: Bool
    let itemHeight: CGFloat
    let circleSize: CGFloat
    
    private var backgroundColor: Color {
        switch colorState {
        case 1:
            return Color(red: 0.85, green: 0.75, blue: 0.55) // 淺土黃色
        default:
            return Color.gray.opacity(0.3) // 淺灰色
        }
    }
    
    var body: some View {
        if isPlaceholder {
            // 垂直線 - 最後一個不顯示
            if !isLastPlaceholder {
                Rectangle()
                    .fill(lineColor)
                    .frame(width: circleSize * 0.04, height: itemHeight) // 線寬基於圓形大小
                    .padding(.leading, circleSize * 0.48) // 置中對齊圓形
            } else {
                // 佔位符保持高度但不顯示
                Color.clear
                    .frame(height: itemHeight)
            }
        } else if isTitle {
            // 級別圓形設計
            ZStack {
                // 實心圓背景
                Circle()
                    .fill(backgroundColor)
                    .frame(width: circleSize, height: circleSize)
                
                // 白色線內縮圓 (描邊圓)
                Circle()
                    .stroke(Color.white, lineWidth: circleSize * 0.04) // 線寬基於圓形大小
                    .frame(width: circleSize * 0.76, height: circleSize * 0.76)
                
                // 文字
                Text(text)
                    .font(.system(size: circleSize * 0.3, weight: .bold)) // 字體大小基於圓形
                    .foregroundColor(.primary)
            }
            .frame(height: circleSize)
        } else {
            // 其他項目保持原樣
            Text(text)
                .font(.system(size: itemHeight * 0.35, weight: .regular)) // 字體大小基於高度
                .foregroundColor(.secondary)
                .padding(.horizontal, itemHeight * 0.27)
                .padding(.vertical, itemHeight * 0.18)
                .background(Color.gray.opacity(0.2))
                .cornerRadius(itemHeight * 0.18)
                .frame(height: itemHeight)
        }
    }
    
    private var lineColor: Color {
        switch colorState {
        case 1:
            return Color(red: 0.85, green: 0.75, blue: 0.55) // 淺土黃色
        default:
            return Color.gray.opacity(0.4) // 淺灰色
        }
    }
}

struct StudyItemView: View {
    let text: String
    let isTitle: Bool
    let isPlaceholder: Bool
    let itemHeight: CGFloat
    
    var body: some View {
        Text(text)
            .font(.system(size: itemHeight * 0.35, weight: isTitle ? .semibold : .regular)) // 字體大小基於高度
            .foregroundColor(isPlaceholder ? .gray.opacity(0.3) : (isTitle ? .primary : .secondary))
            .padding(.horizontal, isTitle ? 0 : itemHeight * 0.27)
            .padding(.vertical, isTitle ? itemHeight * 0.24 : itemHeight * 0.18) // 標題增加垂直padding
            .background(
                Group {
                    if isTitle {
                        Color.clear // 標題透明底色
                    } else if !isPlaceholder {
                        Color.gray.opacity(0.2) // 初階、進階灰底
                    } else {
                        Color.clear // 佔位符透明
                    }
                }
            )
            .cornerRadius(isTitle ? 0 : itemHeight * 0.18) // 標題無圓角，其他有圓角
            .frame(maxWidth: .infinity, alignment: .leading) // 確保標題左對齊且佔滿寬度
    }
}

struct StudyPathView_Previews: PreviewProvider {
    static var previews: some View {
        StudyPathView()
    }
}

/*
設定值完整表列：

左側 levelStates 陣列 (維持不變)：
索引 | 級別    | 當前狀態 | 說明
-----|---------|----------|----------
0    | A1      | 1        | 淺土黃色(已完成)
1    | |       | 1        | 垂直線-淺土黃色(已完成)
2    | |       | 1        | 垂直線-淺土黃色(已完成)
3    | A2      | 1        | 淺土黃色(已完成)
4    | |       | 1        | 垂直線-淺土黃色(已完成)
5    | |       | 1        | 垂直線-淺土黃色(已完成)
6    | B1      | 0        | 淺灰色(未完成)
7    | |       | 0        | 垂直線-淺灰色(未完成)
8    | |       | 0        | 垂直線-淺灰色(未完成)
9    | B2      | 0        | 淺灰色(未完成)
10   | |       | 0        | 垂直線-淺灰色(未完成)
11   | |       | 0        | 垂直線-淺灰色(未完成)
12   | C1      | 0        | 淺灰色(未完成)
13   | |       | 0        | 垂直線(不顯示-最後一級)
14   | |       | 0        | 垂直線(不顯示-最後一級)

右側 rightItemsProgress 陣列 (新增)：
索引 | 項目    | 進度 | 說明
-----|---------|------|----------
0    | 入門級  | 0    | 標題項目(不使用進度值)
1    | 初階    | 86   | StepStatusView 顯示86%進度
2    | 進階    | 45   | StepStatusView 顯示45%進度
3    | 基礎級  | 0    | 標題項目(不使用進度值)
4    | 初階    | 72   | StepStatusView 顯示72%進度
5    | 進階    | 30   | StepStatusView 顯示30%進度
6    | 進階級  | 0    | 標題項目(不使用進度值)
7    | 初階    | 0    | StepStatusView 顯示0%進度(鎖定狀態)
8    | 進階    | 0    | StepStatusView 顯示0%進度(鎖定狀態)
9    | 高階級  | 0    | 標題項目(不使用進度值)
10   | 初階    | 0    | StepStatusView 顯示0%進度(鎖定狀態)
11   | 進階    | 0    | StepStatusView 顯示0%進度(鎖定狀態)
12   | 流利級  | 0    | 標題項目(不使用進度值)
13   | 初階    | 0    | StepStatusView 顯示0%進度(鎖定狀態)
14   | 進階    | 0    | StepStatusView 顯示0%進度(鎖定狀態)

修改方式：
- 修改左側狀態：直接編輯 levelStates 陣列
- 修改右側進度：直接編輯 rightItemsProgress 陣列

例如：
- 將"初階"項目設為50%進度：rightItemsProgress[1] = 50
- 將"進階"項目設為100%進度：rightItemsProgress[2] = 100
*/
