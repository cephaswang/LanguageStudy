import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {   // 用 NavigationStack 包起來
            ZStack {
                Color.blue
                    .ignoresSafeArea()
                
                VStack(spacing: 30) {
                    Text("萬語練習範例")
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    // 按鍵一：列表 直
                    NavigationLink(destination: PhasePinPage()) {
                        Text("列表 直")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.blue)
                            .cornerRadius(12)
                            .shadow(radius: 3)
                    }
                    .padding(.horizontal, 40)
                    
                    // 按鍵二：列表 橫
                    NavigationLink(destination: PhrasePage()) {
                        Text("列表 橫")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.blue)
                            .cornerRadius(12)
                            .shadow(radius: 3)
                    }
                    .padding(.horizontal, 40)
                    
                    
                    // 按鍵三：級別
                    NavigationLink(destination: StudyPathView()) {
                        Text("級別進度")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.white)
                            .foregroundColor(.blue)
                            .cornerRadius(12)
                            .shadow(radius: 3)
                    }
                    .padding(.horizontal, 40)
                    
                    
                    // 按鍵四：週報表
                     NavigationLink(destination: WeeklyView()) {
                         Text("週報表")
                             .font(.headline)
                             .frame(maxWidth: .infinity)
                             .padding()
                             .background(Color.white)
                             .foregroundColor(.blue)
                             .cornerRadius(12)
                             .shadow(radius: 3)
                     }
                     .padding(.horizontal, 40)
                    
                    
                    
                    Spacer()
                }
                .padding(.top, 60)
            }
        }
    }
}

#Preview {
    ContentView()
}
