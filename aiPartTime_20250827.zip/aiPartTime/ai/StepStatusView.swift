import SwiftUI

struct StepStatusView: View {
    let level: String
    let progress: Int // 0-100
    let onTap: (String, Int) -> Void
    
    // 可配置的顏色變量
    var activeBackgroundColor: Color = Color(red: 0.85, green: 0.75, blue: 0.55) // 土黃色
    var inactiveBackgroundColor: Color = Color.gray.opacity(0.3) // 淺灰色
    var activeTextColor: Color = .black
    var inactiveTextColor: Color = .gray
    var progressBarColor: Color =  Color(red: 0.85, green: 0.85, blue: 0.85) // 土黃色
    var progressBarBackgroundColor: Color = Color.gray.opacity(0.2)
    
    private var isActive: Bool {
        progress > 0
    }
    
    private var backgroundColor: Color {
        isActive ? activeBackgroundColor : inactiveBackgroundColor
    }
    
    private var textColor: Color {
        isActive ? activeTextColor : inactiveTextColor
    }
    
    var body: some View {
        HStack(spacing: 12) {
            // 文字：級別
            Text(level)
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(textColor)
                .frame(minWidth: 60, alignment: .leading)
            
            // 狀態條：進度百分比顯示
            VStack(alignment: .leading, spacing: 4) {
                GeometryReader { geometry in
                    ZStack(alignment: .leading) {
                        // 背景條
                        Rectangle()
                            .fill(progressBarBackgroundColor)
                            .frame(height: 8)
                            .cornerRadius(4)
                        
                        // 進度條
                        if isActive {
                            Rectangle()
                                .fill(progressBarColor)
                                .frame(width: geometry.size.width * CGFloat(progress) / 100, height: 8)
                                .cornerRadius(4)
                        }
                    }
                }
                .frame(height: 8)
            }
            .frame(maxWidth: .infinity)
            
            // 進度/圖示，文字
            HStack(spacing: 4) {
                if isActive {
                    // 顯示百分比
                    Text("\(progress)%")
                        .font(.system(size: 14, weight: .medium))
                        .foregroundColor(textColor)
                } else {
                    // 顯示鎖住圖示
                    Image(systemName: "lock.fill")
                        .font(.system(size: 14))
                        .foregroundColor(textColor)
                }
            }
            .frame(minWidth: 40, alignment: .trailing)
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(backgroundColor)
        .cornerRadius(8)
        .onTapGesture {
            // 事件：打印級別和進度百分比
            onTap(level, progress)
            print("級別: \(level), 進度百分比: \(progress)")
        }
    }
}

// MARK: - 預覽和使用範例
struct StepStatusView_Previews: PreviewProvider {
    static var previews: some View {
        VStack(spacing: 12) {
            // 有進度的狀態 (土黃色背景)
            StepStatusView(
                level: "初級",
                progress: 75
            ) { level, progress in
                print("點擊了: \(level), 進度: \(progress)%")
            }
            
            // 無進度的狀態 (淺灰色背景，顯示鎖住圖示)
            StepStatusView(
                level: "中級",
                progress: 0
            ) { level, progress in
                print("點擊了: \(level), 進度: \(progress)%")
            }
            
            // 自定義顏色的範例
            StepStatusView(
                level: "高級",
                progress: 45
            ) { level, progress in
                print("點擊了: \(level), 進度: \(progress)%")
            }
            .modifier(CustomStepStatusStyle(
                activeBackgroundColor: .orange.opacity(0.3),
                progressBarColor: .green
            ))
        }
        .padding()
        .previewLayout(.sizeThatFits)
    }
}

// MARK: - 自定義樣式修飾器
struct CustomStepStatusStyle: ViewModifier {
    let activeBackgroundColor: Color?
    let inactiveBackgroundColor: Color?
    let activeTextColor: Color?
    let inactiveTextColor: Color?
    let progressBarColor: Color?
    let progressBarBackgroundColor: Color?
    
    init(
        activeBackgroundColor: Color? = nil,
        inactiveBackgroundColor: Color? = nil,
        activeTextColor: Color? = nil,
        inactiveTextColor: Color? = nil,
        progressBarColor: Color? = nil,
        progressBarBackgroundColor: Color? = nil
    ) {
        self.activeBackgroundColor = activeBackgroundColor
        self.inactiveBackgroundColor = inactiveBackgroundColor
        self.activeTextColor = activeTextColor
        self.inactiveTextColor = inactiveTextColor
        self.progressBarColor = progressBarColor
        self.progressBarBackgroundColor = progressBarBackgroundColor
    }
    
    func body(content: Content) -> some View {
        // 這裡可以通過環境變量或其他方式來自定義顏色
        content
    }
}


// MARK: - 使用範例
struct ContentView303: View {
    @State private var steps = [
        ("基礎", 100),
        ("進階", 60),
        ("專家", 0),
        ("大師", 0)
    ]
    
    var body: some View {
        NavigationView {
            ScrollView {
                VStack(spacing: 8) {
                    ForEach(Array(steps.enumerated()), id: \.offset) { index, step in
                        StepStatusView(
                            level: step.0,
                            progress: step.1
                        ) { level, progress in
                            print("用戶點擊了級別: \(level), 當前進度: \(progress)%")
                            // 這裡可以添加其他事件處理邏輯
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("學習進度")
        }
    }
}
