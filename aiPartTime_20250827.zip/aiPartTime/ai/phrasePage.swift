import SwiftUI

struct Phrase: Identifiable, Codable {
    let id = UUID()
    let targetLanguage: String
    let nativeLanguage: String
    let audioFileName: String  // e.g. "en001.mp3"
}

struct PhrasePage: View {
    
    // 使用 presentationMode 以支援更廣的系統版本
    @Environment(\.presentationMode) private var presentationMode
    
    let phrases: [Phrase] = [
        Phrase(targetLanguage: "She always reads books.", nativeLanguage: "她總是讀書。", audioFileName: "en001.mp3"),
        Phrase(targetLanguage: "He often plays soccer.", nativeLanguage: "他經常踢足球。", audioFileName: "en002.mp3"),
        Phrase(targetLanguage: "They rarely go to the park.", nativeLanguage: "他們很少去公園。", audioFileName: "en003.mp3"),
        Phrase(targetLanguage: "We sometimes watch movies.", nativeLanguage: "我們有時看電影。", audioFileName: "en004.mp3"),
        Phrase(targetLanguage: "I never drink coffee.", nativeLanguage: "我從不喝咖啡。", audioFileName: "en005.mp3"),
        Phrase(targetLanguage: "You usually walk to school.", nativeLanguage: "你通常走路上學。", audioFileName: "en006.mp3")
    ]
    
    var body: some View {
        NavigationView {
            VStack(spacing: 40) {
                Text("一句接著一句\n輕鬆學習英文(英語)")
                    .padding(.top, 40)
                    .font(.title2)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                    .padding(.horizontal)
                    .foregroundColor(.white)
                
                
                Text("每個回合由結構相似的句子組成。觀察、理解並大聲重覆\n一一你的大腦會幫助你串聯起來。")
                    .font(.system(size: 13, weight: .medium))
                    .multilineTextAlignment(.center)
                    .foregroundColor(.white)
                
                
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 15) {
                        ForEach(phrases) { phrase in
                            PlayCell(
                                targetLanguage: phrase.targetLanguage,
                                nativeLanguage: phrase.nativeLanguage,
                                audioFileName: phrase.audioFileName
                            )
                        }
                    }
                    .padding(.horizontal)
                }
                
                Button(action: {
                    print("Continue tapped")
                }) {
                    Text("繼續")
                        .font(.headline)
                        .foregroundColor(.white)
                        .padding()
                        .frame(maxWidth: .infinity)
                        .background(Color.yellow)
                        .cornerRadius(30)
                        .padding(.horizontal)
                }
                .padding(.bottom, 20)
                
                Spacer()
            }
            .padding()
            .background(Color.blue)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        print("Back tapped")
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.white)
                    }
                }
                ToolbarItem(placement: .principal) {
                    Image("Logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 60, height: 60)
                }
            }
        }
    }
}

struct PhrasePage_Previews: PreviewProvider {
    static var previews: some View {
        PhrasePage()
    }
}

