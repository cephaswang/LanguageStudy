import SwiftUI
import SQLite3

/*
// 大綱資料模型
struct Outline: Identifiable {
    let id = UUID()
    let sortOrder: Int
    let targetLanguageText: String
    let nativeLanguageText: String
}
*/

/*
// 資料庫管理器
class DatabaseManager: ObservableObject {
    private var db: OpaquePointer?
    @Published var error: Error?
    
    deinit {
        if db != nil {
            sqlite3_close(db)
        }
    }
    
    func openDatabase() {
        if db != nil { return } // Avoid re-opening
        
        guard let path = Bundle.main.path(forResource: "study", ofType: "db") else {
            print("找不到資料庫檔案")
            self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "找不到資料庫檔案"])
            return
        }
        
        print("資料庫完整路徑: \(path)") // Print the full database path
        
        if sqlite3_open(path, &db) != SQLITE_OK {
            print("無法開啟資料庫")
            self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "無法開啟資料庫"])
            sqlite3_close(db)
            db = nil
        }
    }
    
    func fetchOutlines(targetLanguage: String, nativeLanguage: String) -> [Outline] {
        openDatabase() // Open database only when needed
        guard let db = db else { return [] }
        
        let query = """
            SELECT t.sort_order, t.outline as target_text, n.outline as native_text
            FROM outlines t
            JOIN outlines n ON t.sort_order = n.sort_order
            WHERE t.lang_code = ? AND n.lang_code = ?
            ORDER BY t.sort_order
        """
        
        var statement: OpaquePointer?
        var outlines: [Outline] = []
        
        if sqlite3_prepare_v2(db, query, -1, &statement, nil) == SQLITE_OK {
            sqlite3_bind_text(statement, 1, targetLanguage, -1, nil)
            sqlite3_bind_text(statement, 2, nativeLanguage, -1, nil)
            
            while sqlite3_step(statement) == SQLITE_ROW {
                let sortOrder = Int(sqlite3_column_int(statement, 0))
                let targetText = String(cString: sqlite3_column_text(statement, 1))
                let nativeText = String(cString: sqlite3_column_text(statement, 2))
                
                let outline = Outline(
                    sortOrder: sortOrder,
                    targetLanguageText: targetText,
                    nativeLanguageText: nativeText
                )
                outlines.append(outline)
            }
        } else {
            print("查詢失敗")
            self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "查詢失敗"])
        }
        
        sqlite3_finalize(statement)
        return outlines
    }
}
*/

// 主要的 OutlineView
struct OutlineView: View {
    let targetLanguage: String
    let nativeLanguage: String
    
    @StateObject private var databaseManager = DatabaseManager()
    @State private var outlines: [Outline] = []
    @State private var isLoading = true
    @State private var showError = false
    
    // 用於導航到 TopicView 的回調
    var onSelectOutline: (Int, String, String) -> Void
    
    var body: some View {
        NavigationView {
            VStack {
                if isLoading {
                    ProgressView("載入中...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if outlines.isEmpty {
                    Text("無資料或載入失敗")
                        .foregroundColor(.red)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(outlines) { outline in
                        OutlineRowView(
                            outline: outline,
                            targetLanguage: targetLanguage,
                            nativeLanguage: nativeLanguage
                        ) {
                            onSelectOutline(
                                outline.sortOrder,
                                targetLanguage,
                                nativeLanguage
                            )
                        }
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .navigationTitle("學習大綱")
            .navigationBarTitleDisplayMode(.large)
            .onAppear {
                loadOutlines()
            }
            .alert(isPresented: $showError) {
                Alert(
                    title: Text("錯誤"),
                    message: Text(databaseManager.error?.localizedDescription ?? "未知錯誤")
                )
            }
            .onReceive(databaseManager.$error) { error in
                showError = error != nil
            }
        }
    }
    
    private func loadOutlines() {
        isLoading = true
        DispatchQueue.global(qos: .userInitiated).async {
            let fetchedOutlines = self.databaseManager.fetchOutlines(
                targetLanguage: self.targetLanguage,
                nativeLanguage: self.nativeLanguage
            )
            
            DispatchQueue.main.async {
                self.outlines = fetchedOutlines
                self.isLoading = false
            }
        }
    }
}

// 大綱列表項目視圖
struct OutlineRowView: View {
    let outline: Outline
    let targetLanguage: String
    let nativeLanguage: String
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            HStack {
                // 排序號碼圓圈
                ZStack {
                    Circle()
                        .fill(Color.blue)
                        .frame(width: 40, height: 40)
                    
                    Text("\(outline.sortOrder)")
                        .foregroundColor(.white)
                        .font(.system(size: 16, weight: .semibold))
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    // 目標語言文字
                    Text(outline.targetLanguageText)
                        .font(.system(size: 18, weight: .medium))
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                    
                    // 母語文字（較小字體）
                    Text(outline.nativeLanguageText)
                        .font(.system(size: 14))
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.leading)
                }
                
                Spacer()
                
                // 右箭頭
                Image(systemName: "chevron.right")
                    .foregroundColor(.gray)
                    .font(.system(size: 14))
            }
            .padding(.vertical, 8)
            .contentShape(Rectangle())
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// 使用範例
struct ContentView: View {
    @State private var showTopicView = false
    @State private var selectedSortOrder: Int = 0
    @State private var selectedTargetLanguage: String = ""
    @State private var selectedNativeLanguage: String = ""
    
    var body: some View {
        OutlineView(
            targetLanguage: "en",
            nativeLanguage: "zh_TW"
        ) { sortOrder, targetLang, nativeLang in
            selectedSortOrder = sortOrder
            selectedTargetLanguage = targetLang
            selectedNativeLanguage = nativeLang
            showTopicView = true
        }
        .fullScreenCover(isPresented: $showTopicView) {
            TopicView(
                sortOrder: selectedSortOrder,
                targetLanguage: selectedTargetLanguage,
                nativeLanguage: selectedNativeLanguage
            )
        }
    }
}


struct TopicView: View {
    @Environment(\.dismiss) private var dismiss

    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String

    var body: some View {
        VStack(spacing: 20) {
            Text("主題頁面")
                .font(.title)

            Text("排序: \(sortOrder)")
            Text("目標語言: \(targetLanguage)")
            Text("母語: \(nativeLanguage)")

            Spacer()

            Button {
                dismiss()
            } label: {
                Text("結束")
                    .font(.headline)
                    .foregroundColor(.white)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.red)
                    .cornerRadius(10)
            }
            .padding(.horizontal, 20)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity) // 內容佔滿可視區
        .background(Color(.systemBackground))             // 或任意你要的底色
        .ignoresSafeArea()                                // 若需要延伸到安全區以外
        .padding()
    }
}



#Preview {
    ContentView()
}
