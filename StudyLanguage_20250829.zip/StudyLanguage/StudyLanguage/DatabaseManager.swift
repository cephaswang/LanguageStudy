// DatabaseManager.swift — robust bootstrap & fallback to bundled SQL/DB
import SQLite3
import SwiftUI

class DatabaseManager: ObservableObject {
    private var database: OpaquePointer?
    @Published var error: Error?
    private let queue = DispatchQueue(label: "DatabaseManager", qos: .background)
    private var isInitialized = false

    deinit {
        if database != nil {
            sqlite3_close(database)
        }
    }

    func openDatabase() {
        queue.sync {
            guard !isInitialized else { return }
            _openDatabase()
            isInitialized = true
        }
    }
    
    private func _openDatabase() {
        // 1) Resolve Documents/study.db path
        guard let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            let err = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "無法找到 Documents 目錄"])
            print(err.localizedDescription)
            DispatchQueue.main.async {
                self.error = err
            }
            return
        }
        let dbURL = documentsPath.appendingPathComponent("study.db")
        let dbPath = dbURL.path

        // 2) If missing, try to create from bundled study.db first; if not present, execute database.sql
        if !FileManager.default.fileExists(atPath: dbPath) {
            if !copyBundledDB(to: dbURL) {
                // fall back to SQL bootstrap
                if !createDatabaseByExecutingBundledSQL(at: dbPath) {
                    let err = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "無法創建資料庫 (找不到 bundled study.db 或 database.sql 失敗)"])
                    print(err.localizedDescription)
                    DispatchQueue.main.async {
                        self.error = err
                    }
                    return
                }
            }
        }

        // 3) Open
        if sqlite3_open(dbPath, &database) != SQLITE_OK {
            let err = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "無法開啟資料庫"])
            print(err.localizedDescription)
            sqlite3_close(database)
            database = nil
            DispatchQueue.main.async {
                self.error = err
            }
            return
        }
        print("資料庫已開啟: \(dbPath)")

        // 4) Ensure schema populated (e.g., first run had empty file)
        if outlinesRowCount() == 0 {
            print("outlines 為 0，嘗試執行 bundled database.sql 進行初始化…")
            if executeBundledSQLOnOpenedDB() {
                print("已載入初始資料。outlines=\(outlinesRowCount())")
            } else {
                print("初始化失敗；請確認 database.sql 已加入 target")
            }
        }
    }

    private func copyBundledDB(to destinationURL: URL) -> Bool {
        // Try study.db (prebuilt) from bundle if present
        guard let bundledDB = Bundle.main.url(forResource: "study", withExtension: "db") else { return false }
        do {
            try FileManager.default.copyItem(at: bundledDB, to: destinationURL)
            print("已從 bundle 複製 study.db")
            return true
        } catch {
            print("複製 bundled study.db 失敗: \(error)")
            return false
        }
    }

    private func createDatabaseByExecutingBundledSQL(at path: String) -> Bool {
        var tempDb: OpaquePointer?
        guard sqlite3_open(path, &tempDb) == SQLITE_OK else {
            print("無法創建資料庫檔案")
            return false
        }
        defer { sqlite3_close(tempDb) }

        // locate database.sql in bundle
        guard let sqlURL = Bundle.main.url(forResource: "database", withExtension: "sql") else {
            print("找不到 database.sql 檔案 (請加入 Copy Bundle Resources)")
            return false
        }
        do {
            let sql = try String(contentsOf: sqlURL, encoding: .utf8)
            if sqlite3_exec(tempDb, sql, nil, nil, nil) != SQLITE_OK {
                let errorMessage = String(cString: sqlite3_errmsg(tempDb))
                print("執行 SQL 失敗: \(errorMessage)")
                return false
            }
            return true
        } catch {
            print("讀取 database.sql 失敗: \(error)")
            return false
        }
    }

    private func executeBundledSQLOnOpenedDB() -> Bool {
        guard let database = database else { return false }
        guard let sqlURL = Bundle.main.url(forResource: "database", withExtension: "sql") else { return false }
        do {
            let sql = try String(contentsOf: sqlURL, encoding: .utf8)
            if sqlite3_exec(database, sql, nil, nil, nil) != SQLITE_OK {
                let msg = String(cString: sqlite3_errmsg(database))
                print("執行 SQL 失敗: \(msg)")
                return false
            }
            return true
        } catch {
            print("讀取 database.sql 失敗: \(error)")
            return false
        }
    }

    private func outlinesRowCount() -> Int {
        guard let database = database else { return 0 }
        var stmt: OpaquePointer?
        defer { sqlite3_finalize(stmt) }
        if sqlite3_prepare_v2(database, "SELECT COUNT(*) FROM outlines", -1, &stmt, nil) == SQLITE_OK,
           sqlite3_step(stmt) == SQLITE_ROW {
            return Int(sqlite3_column_int(stmt, 0))
        }
        return 0
    }

    func fetchOutlines(targetLanguage: String, nativeLanguage: String) -> [Outline] {
        openDatabase()
        
        return queue.sync {
            guard let database = database else { return [] }

            let query = """
                SELECT t.sort_order, t.outline as target_text, n.outline as native_text
                FROM outlines t
                JOIN outlines n ON t.sort_order = n.sort_order
                WHERE t.lang_code = ? AND n.lang_code = ?
                ORDER BY t.sort_order
            """

            var statement: OpaquePointer?
            var results: [Outline] = []
            defer { sqlite3_finalize(statement) }

            if sqlite3_prepare_v2(database, query, -1, &statement, nil) == SQLITE_OK {
                // Bind languages ("en", "zh_TW", etc.)
                sqlite3_bind_text(statement, 1, (targetLanguage as NSString).utf8String, -1, SQLITE_TRANSIENT)
                sqlite3_bind_text(statement, 2, (nativeLanguage as NSString).utf8String, -1, SQLITE_TRANSIENT)

                while sqlite3_step(statement) == SQLITE_ROW {
                    let sortOrder = Int(sqlite3_column_int(statement, 0))
                    let targetText = String(cString: sqlite3_column_text(statement, 1))
                    let nativeText = String(cString: sqlite3_column_text(statement, 2))
                    results.append(Outline(sortOrder: sortOrder, targetLanguageText: targetText, nativeLanguageText: nativeText))
                }
            } else {
                let msg = String(cString: sqlite3_errmsg(database))
                print("查詢失敗: \(msg)")
                DispatchQueue.main.async {
                    self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "查詢失敗: \(msg)"])
                }
            }

            print("fetchOutlines -> \(results.count) 筆")
            return results
        }
    }
    
    func fetchTopics(targetLanguage: String, nativeLanguage: String, sortOrder: Int) -> [Topic] {
        openDatabase()
        
        return queue.sync {
            guard let database = database else { return [] }
            
            let startIndex = sortOrder * 10 - 10
            let endIndex = sortOrder * 10
            
            let query = """
                SELECT t.sort_order, t.topic as target_topic, n.topic as native_topic
                FROM topics_\(targetLanguage) t
                JOIN topics_\(nativeLanguage) n ON t.sort_order = n.sort_order
                WHERE t.sort_order > ? AND t.sort_order <= ?
                ORDER BY t.sort_order
            """
            
            var statement: OpaquePointer?
            var results: [Topic] = []
            defer { sqlite3_finalize(statement) }
            
            if sqlite3_prepare_v2(database, query, -1, &statement, nil) == SQLITE_OK {
                sqlite3_bind_int(statement, 1, Int32(startIndex))
                sqlite3_bind_int(statement, 2, Int32(endIndex))
                
                while sqlite3_step(statement) == SQLITE_ROW {
                    let index = Int(sqlite3_column_int(statement, 0))
                    let targetText = String(cString: sqlite3_column_text(statement, 1))
                    let nativeText = String(cString: sqlite3_column_text(statement, 2))
                    results.append(Topic(index: index, targetText: targetText, nativeText: nativeText))
                }
            } else {
                let msg = String(cString: sqlite3_errmsg(database))
                print("查詢主題失敗: \(msg)")
                DispatchQueue.main.async {
                    self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "查詢主題失敗: \(msg)"])
                }
            }
            
            print("fetchTopics -> \(results.count) 筆主題")
            return results
        }
    }
}

// Helper for safe transient binding
private let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
