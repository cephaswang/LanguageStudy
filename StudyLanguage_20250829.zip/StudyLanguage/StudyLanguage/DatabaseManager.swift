import Foundation
import SQLite3
import Combine

// 大綱資料模型
struct Outline: Identifiable {
    let id = UUID()
    let sortOrder: Int
    let targetLanguageText: String
    let nativeLanguageText: String
}

final class DatabaseManager: ObservableObject {
    private var db: OpaquePointer?
    @Published var error: Error?

    deinit {
        if db != nil { sqlite3_close(db) }
    }

    // 主要進入點：開啟或建立資料庫（可自我修復）
    func openDatabase() {
        guard db == nil else { return }

        let fm = FileManager.default
        guard let documentsURL = fm.urls(for: .documentDirectory, in: .userDomainMask).first else {
            let e = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "無法找到 Documents 目錄"])
            self.error = e
            print(e.localizedDescription)
            return
        }

        let targetPath = documentsURL.appendingPathComponent("study.db").path

        // 若 Documents 還沒有 study.db，先嘗試從 bundle 複製預建 db，否則才用 SQL 初始化
        if !fm.fileExists(atPath: targetPath) {
            if let bundleDB = Bundle.main.path(forResource: "study", ofType: "db") {
                do {
                    try fm.copyItem(atPath: bundleDB, toPath: targetPath)
                    print("已從 bundle 複製 study.db → \(targetPath)")
                } catch {
                    print("複製 bundle study.db 失敗：\(error.localizedDescription)；改用 SQL 初始化")
                    _ = createDatabaseFromSQL(at: targetPath)
                }
            } else {
                // 沒有預建 db，就用 SQL 初始化
                _ = createDatabaseFromSQL(at: targetPath)
            }
        }

        // 開啟資料庫
        if sqlite3_open(targetPath, &db) != SQLITE_OK {
            let msg = "無法開啟資料庫"
            print(msg)
            self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: msg])
            sqlite3_close(db)
            db = nil
            return
        }

        print("資料庫已開啟: \(targetPath)")

        // 自我修復：若 outlines 表不存在或沒資料，重建一次
        if !tableExists("outlines") || rowCount(of: "outlines") == 0 {
            print("偵測到 outlines 表不存在或沒有資料，將重建資料庫內容")
            sqlite3_close(db)
            db = nil
            // 重新建立
            do {
                // 移除舊檔再重建
                try fm.removeItem(atPath: targetPath)
            } catch {
                print("刪除舊資料庫失敗：\(error.localizedDescription)")
            }
            // 先嘗試 bundle 的 study.db，再退回 SQL
            if let bundleDB = Bundle.main.path(forResource: "study", ofType: "db") {
                do {
                    try fm.copyItem(atPath: bundleDB, toPath: targetPath)
                    print("修復：已從 bundle 複製 study.db")
                } catch {
                    print("修復：複製 bundle study.db 失敗，使用 SQL 初始化：\(error.localizedDescription)")
                    _ = createDatabaseFromSQL(at: targetPath)
                }
            } else {
                _ = createDatabaseFromSQL(at: targetPath)
            }

            // 重新開啟
            if sqlite3_open(targetPath, &db) != SQLITE_OK {
                let msg = "修復後仍無法開啟資料庫"
                print(msg)
                self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: msg])
                sqlite3_close(db)
                db = nil
            }
        }
    }

    // 以 database.sql 初始化資料庫
    private func createDatabaseFromSQL(at path: String) -> Bool {
        var tempDb: OpaquePointer?
        if sqlite3_open(path, &tempDb) != SQLITE_OK {
            print("無法創建資料庫檔案")
            return false
        }
        defer { sqlite3_close(tempDb) }

        guard let sqlPath = Bundle.main.path(forResource: "database", ofType: "sql") else {
            print("找不到 database.sql 檔案（請加入 Copy Bundle Resources）")
            return false
        }
        do {
            let sql = try String(contentsOfFile: sqlPath, encoding: .utf8)
            if sqlite3_exec(tempDb, sql, nil, nil, nil) != SQLITE_OK {
                let err = String(cString: sqlite3_errmsg(tempDb))
                print("執行 SQL 失敗: \(err)")
                return false
            }
            print("已用 database.sql 初始化資料庫")
            return true
        } catch {
            print("讀取 database.sql 失敗: \(error.localizedDescription)")
            return false
        }
    }

    // 檢查資料表是否存在
    private func tableExists(_ name: String) -> Bool {
        guard let db = db else { return false }
        let q = "SELECT name FROM sqlite_master WHERE type='table' AND name=? LIMIT 1"
        var stmt: OpaquePointer?
        guard sqlite3_prepare_v2(db, q, -1, &stmt, nil) == SQLITE_OK else { return false }
        defer { sqlite3_finalize(stmt) }
        (name as NSString).utf8String.map { sqlite3_bind_text(stmt, 1, $0, -1, SQLITE_TRANSIENT) }
        return sqlite3_step(stmt) == SQLITE_ROW
    }

    // 計算資料表筆數
    private func rowCount(of table: String) -> Int {
        guard let db = db else { return 0 }
        let q = "SELECT COUNT(*) FROM \(table)"
        var stmt: OpaquePointer?
        guard sqlite3_prepare_v2(db, q, -1, &stmt, nil) == SQLITE_OK else { return 0 }
        defer { sqlite3_finalize(stmt) }
        if sqlite3_step(stmt) == SQLITE_ROW {
            return Int(sqlite3_column_int(stmt, 0))
        }
        return 0
    }

    // 查詢 outlines（雙語對照）
    func fetchOutlines(targetLanguage: String, nativeLanguage: String) -> [Outline] {
        openDatabase()
        guard let db = db else { return [] }

        let query = """
        SELECT t.sort_order, t.outline as target_text, n.outline as native_text
        FROM outlines t
        JOIN outlines n ON t.sort_order = n.sort_order
        WHERE t.lang_code = ? AND n.lang_code = ?
        ORDER BY t.sort_order
        """

        var stmt: OpaquePointer?
        var items: [Outline] = []

        if sqlite3_prepare_v2(db, query, -1, &stmt, nil) == SQLITE_OK {
            // 綁定字串要用 utf8 C 指標
            (targetLanguage as NSString).utf8String.map {
                sqlite3_bind_text(stmt, 1, $0, -1, SQLITE_TRANSIENT)
            }
            (nativeLanguage as NSString).utf8String.map {
                sqlite3_bind_text(stmt, 2, $0, -1, SQLITE_TRANSIENT)
            }

            while sqlite3_step(stmt) == SQLITE_ROW {
                let sortOrder = Int(sqlite3_column_int(stmt, 0))
                guard
                    let tgtC = sqlite3_column_text(stmt, 1),
                    let natC = sqlite3_column_text(stmt, 2)
                else { continue }

                let outline = Outline(
                    sortOrder: sortOrder,
                    targetLanguageText: String(cString: tgtC),
                    nativeLanguageText: String(cString: natC)
                )
                items.append(outline)
            }
        } else {
            let err = String(cString: sqlite3_errmsg(db))
            let e = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "查詢失敗：\(err)"])
            self.error = e
            print(e.localizedDescription)
        }

        sqlite3_finalize(stmt)
        return items
    }
}

// 供 SQLite 釋放策略使用
private let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
