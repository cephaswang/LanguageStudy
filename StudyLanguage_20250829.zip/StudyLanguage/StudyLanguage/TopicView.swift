import SwiftUI

struct TopicView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    var body: some View {
        VStack {
            Text("主題頁面")
                .font(.custom(nativeLanguageFontName, size: 24))
                .fontWeight(.bold)
            
            Text("排序: \(sortOrder)")
                .font(.custom(nativeLanguageFontName, size: 18))
                .padding(.top, 8)
            
            Text("目標語言: \(targetLanguage)")
                .font(.custom(nativeLanguageFontName, size: 16))
                .padding(.top, 4)
            
            Text("母語: \(nativeLanguage)")
                .font(.custom(nativeLanguageFontName, size: 16))
                .padding(.top, 4)
        }
        .padding()
    }
}

#Preview {
    TopicView(
        sortOrder: 1,
        targetLanguage: "en",
        nativeLanguage: "zh_TW",
        targetLanguageFontName: "Helvetica",
        nativeLanguageFontName: "PingFangTC-Regular"
    )
}
