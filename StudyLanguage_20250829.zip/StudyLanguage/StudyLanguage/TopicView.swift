import SwiftUI
import SQLite3

struct Topic {
    let index: Int
    let targetText: String
    let nativeText: String
}

struct TopicView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    @StateObject private var databaseManager = DatabaseManager()
    @State private var topics: [Topic] = []
    @State private var isLoading = true
    
    var body: some View {
        NavigationView {
            VStack {
                if isLoading {
                    ProgressView("載入中...")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if topics.isEmpty {
                    Text("沒有找到主題")
                        .foregroundColor(.gray)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(topics, id: \.index) { topic in
                        NavigationLink(
                            destination: LessonView(
                                sortOrder: topic.index,
                                targetLanguage: targetLanguage,
                                nativeLanguage: nativeLanguage,
                                targetLanguageFontName: targetLanguageFontName,
                                nativeLanguageFontName: nativeLanguageFontName
                            )
                        ) {
                            TopicRow(
                                topic: topic,
                                targetLanguageFontName: targetLanguageFontName,
                                nativeLanguageFontName: nativeLanguageFontName
                            )
                        }
                    }
                    .listStyle(PlainListStyle())
                }
            }
            .navigationTitle("主題")
            .onAppear {
                loadTopics()
            }
            .alert("錯誤", isPresented: .constant(databaseManager.error != nil)) {
                Button("確定") {
                    databaseManager.error = nil
                }
            } message: {
                Text(databaseManager.error?.localizedDescription ?? "")
            }
        }
    }
    
    private func loadTopics() {
        isLoading = true
        DispatchQueue.global(qos: .background).async {
            let fetchedTopics = databaseManager.fetchTopics(
                targetLanguage: targetLanguage,
                nativeLanguage: nativeLanguage,
                sortOrder: sortOrder
            )
            DispatchQueue.main.async {
                self.topics = fetchedTopics
                self.isLoading = false
            }
        }
    }
}

struct TopicRow: View {
    let topic: Topic
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Target language text
            Text(topic.targetText)
                .font(.custom(targetLanguageFontName, size: 16))
                .foregroundColor(.primary)
                .multilineTextAlignment(.leading)
            
            // Native language text
            Text(topic.nativeText)
                .font(.custom(nativeLanguageFontName, size: 14))
                .foregroundColor(.secondary)
                .multilineTextAlignment(.leading)
        }
        .padding(.vertical, 4)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
}

// Preview
struct TopicView_Previews: PreviewProvider {
    static var previews: some View {
        TopicView(
            sortOrder: 1,
            targetLanguage: "en",
            nativeLanguage: "zh_TW",
            targetLanguageFontName: "Helvetica",
            nativeLanguageFontName: "PingFangTC-Regular"
        )
    }
}
