import SwiftUI

struct TopicView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    
    var body: some View {
        VStack {
            Text("主題頁面")
                .font(.title)
            Text("排序: \(sortOrder)")
            Text("目標語言: \(targetLanguage)")
            Text("母語: \(nativeLanguage)")
        }
        .padding()
    }
}

#Preview {
    TopicView(sortOrder: 1, targetLanguage: "en", nativeLanguage: "zh_TW")
}
