import SwiftUI
import SQLite3

struct Topic {
    let index: Int
    let targetText: String
    let nativeText: String
}

struct TopicView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let targetOutline: String
    let nativeOutline: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    @StateObject private var databaseManager = DatabaseManager()
    @State private var topics: [Topic] = []
    @State private var isLoading = true
    
    var body: some View {
        NavigationView {
            VStack {
                if isLoading {
                    VStack(spacing: 16) {
                        ProgressView()
                            .scaleEffect(1.2)
                        Text("載入主題中...")
                            .font(.custom(nativeLanguageFontName, size: 16))
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if topics.isEmpty {
                    VStack(spacing: 20) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 50))
                            .foregroundColor(.orange)
                        
                        VStack(spacing: 8) {
                            Text("沒有找到主題")
                                .font(.custom(nativeLanguageFontName, size: 20))
                                .fontWeight(.semibold)
                            
                            Text("請檢查資料庫連接")
                                .font(.custom(nativeLanguageFontName, size: 16))
                                .foregroundColor(.secondary)
                        }
                        
                        Button("重新載入") {
                            loadTopics()
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .font(.custom(nativeLanguageFontName, size: 16))
                        .cornerRadius(8)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(topics, id: \.index) { topic in
                        NavigationLink(
                            destination: LessonView(
                                sortOrder: topic.index,
                                targetLanguage: targetLanguage,
                                nativeLanguage: nativeLanguage,
                                targetTopic: topic.targetText,
                                nativeTopic: topic.nativeText,
                                targetLanguageFontName: targetLanguageFontName,
                                nativeLanguageFontName: nativeLanguageFontName
                            )
                        ) {
                            TopicRow(
                                topic: topic,
                                targetLanguageFontName: targetLanguageFontName,
                                nativeLanguageFontName: nativeLanguageFontName
                            )
                        }
                    }
                    .listStyle(PlainListStyle())
                    .refreshable {
                        loadTopics()
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    BilingualNavigationTitle(
                        targetTitle: targetOutline,
                        nativeTitle: nativeOutline,
                        targetFontName: targetLanguageFontName,
                        nativeFontName: nativeLanguageFontName
                    )
                }
            }
            .onAppear {
                loadTopics()
            }
            .alert("錯誤", isPresented: .constant(databaseManager.error != nil)) {
                Button("確定") {
                    databaseManager.error = nil
                }
                Button("重試") {
                    loadTopics()
                }
            } message: {
                Text(databaseManager.error?.localizedDescription ?? "未知錯誤")
                    .font(.custom(nativeLanguageFontName, size: 14))
            }
        }
    }
    
    private func loadTopics() {
        print("🚀 開始載入主題資料... sortOrder: \(sortOrder)")
        isLoading = true
        
        databaseManager.error = nil
        
        DispatchQueue.global(qos: .userInitiated).async {
            let fetchedTopics = self.databaseManager.fetchTopics(
                targetLanguage: self.targetLanguage,
                nativeLanguage: self.nativeLanguage,
                sortOrder: self.sortOrder
            )
            
            DispatchQueue.main.async {
                self.topics = fetchedTopics
                self.isLoading = false
                
                if fetchedTopics.isEmpty {
                    print("⚠️ 主題載入完成，但沒有找到資料")
                } else {
                    print("✅ 成功載入 \(fetchedTopics.count) 個主題項目")
                }
            }
        }
    }
}

// 自定義雙語導航標題組件
struct BilingualNavigationTitle: View {
    let targetTitle: String
    let nativeTitle: String
    let targetFontName: String
    let nativeFontName: String
    
    var body: some View {
        VStack(spacing: 2) {
            Text(targetTitle)
                .font(.custom(targetFontName, size: 16))
                .fontWeight(.semibold)
                .foregroundColor(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
            
            Text(nativeTitle)
                .font(.custom(nativeFontName, size: 14))
                .foregroundColor(.secondary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
    }
}

struct TopicRow: View {
    let topic: Topic
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    var body: some View {
        HStack(spacing: 12) {
            // 索引圓圈
            ZStack {
                Circle()
                    .fill(Color.green)
                    .frame(width: 36, height: 36)
                
                Text("\(topic.index)")
                    .foregroundColor(.white)
                    .font(.system(size: 14, weight: .semibold))
            }
            
            // 文字內容
            VStack(alignment: .leading, spacing: 6) {
                // Target language text
                Text(topic.targetText)
                    .font(.custom(targetLanguageFontName, size: 17))
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(3)
                
                // Native language text
                Text(topic.nativeText)
                    .font(.custom(nativeLanguageFontName, size: 14))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
            }
            
            Spacer()
        }
        .padding(.vertical, 10)
        .contentShape(Rectangle())
    }
}

// Preview
struct TopicView_Previews: PreviewProvider {
    static var previews: some View {
        TopicView(
            sortOrder: 1,
            targetLanguage: "en",
            nativeLanguage: "zh_TW",
            targetOutline: "Basic Conversations",
            nativeOutline: "基本對話",
            targetLanguageFontName: "Helvetica",
            nativeLanguageFontName: "PingFangTC-Regular"
        )
    }
}
