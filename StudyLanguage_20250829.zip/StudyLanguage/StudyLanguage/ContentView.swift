import SwiftUI

struct ContentView: View {
    @State private var showTopicView = false
    @State private var selectedSortOrder: Int = 0
    @State private var selectedTargetLanguage: String = ""
    @State private var selectedNativeLanguage: String = ""
    
    var body: some View {
        OutlineView(
            targetLanguage: "en",
            nativeLanguage: "zh_TW",
            targetLanguageFontName: "Helvetica",
            nativeLanguageFontName: "PingFangTC-Regular"
        )
       
    }
}

#Preview {
    ContentView()
}
