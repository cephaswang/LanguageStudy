import SwiftUI

struct LessonView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    var body: some View {
        VStack {
            Text("課程 #\(sortOrder)")
                .font(.custom(targetLanguageFontName, size: 24))
                .padding()
            
            Text("目標語言: \(targetLanguage)")
                .font(.custom(targetLanguageFontName, size: 16))
            
            Text("母語: \(nativeLanguage)")
                .font(.custom(nativeLanguageFontName, size: 16))
            
            Spacer()
        }
        .navigationTitle("課程")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct LessonView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            LessonView(
                sortOrder: 1,
                targetLanguage: "en",
                nativeLanguage: "zh_TW",
                targetLanguageFontName: "Helvetica",
                nativeLanguageFontName: "PingFangTC-Regular"
            )
        }
    }
}
