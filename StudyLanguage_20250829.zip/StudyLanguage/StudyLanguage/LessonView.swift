import SwiftUI

struct Lesson {
    let id: Int
    let targetText: String
    let nativeText: String
    let audioPath: String?
}

struct LessonView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let targetTopic: String
    let nativeTopic: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    @StateObject private var databaseManager = DatabaseManager()
    @State private var lessons: [Lesson] = []
    @State private var isLoading = true
    
    var body: some View {
        VStack(spacing: 0) {
            // 頂部資訊區域
            VStack(spacing: 12) {
                HStack {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(
                                gradient: Gradient(colors: [Color.purple, Color.pink]),
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ))
                            .frame(width: 50, height: 50)
                        
                        Text("\(sortOrder)")
                            .foregroundColor(.white)
                            .font(.system(size: 18, weight: .bold))
                    }
                    
                    VStack(alignment: .leading, spacing: 4) {
                        Text(targetTopic)
                            .font(.custom(targetLanguageFontName, size: 20))
                            .fontWeight(.semibold)
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                        
                        Text(nativeTopic)
                            .font(.custom(nativeLanguageFontName, size: 16))
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.leading)
                    }
                    
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, 16)
                
                Divider()
                    .padding(.horizontal, 20)
            }
            .background(Color(.systemBackground))
            
            // 課程內容區域
            if isLoading {
                VStack(spacing: 16) {
                    ProgressView()
                        .scaleEffect(1.2)
                    Text("載入課程中...")
                        .font(.custom(nativeLanguageFontName, size: 16))
                        .foregroundColor(.secondary)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else if lessons.isEmpty {
                VStack(spacing: 20) {
                    Image(systemName: "book.closed.fill")
                        .font(.system(size: 50))
                        .foregroundColor(.orange)
                    
                    VStack(spacing: 8) {
                        Text("暫無課程內容")
                            .font(.custom(nativeLanguageFontName, size: 20))
                            .fontWeight(.semibold)
                        
                        Text("此主題的課程正在準備中")
                            .font(.custom(nativeLanguageFontName, size: 16))
                            .foregroundColor(.secondary)
                    }
                    
                    Button("重新載入") {
                        loadLessons()
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 10)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .cornerRadius(8)
                }
                .padding()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                ScrollView {
                    LazyVStack(spacing: 16) {
                        ForEach(lessons, id: \.id) { lesson in
                            LessonCard(
                                lesson: lesson,
                                targetLanguageFontName: targetLanguageFontName,
                                nativeLanguageFontName: nativeLanguageFontName
                            )
                        }
                    }
                    .padding(.horizontal, 20)
                    .padding(.vertical, 16)
                }
                .refreshable {
                    loadLessons()
                }
            }
        }
        .navigationTitle("課程")
        .navigationBarTitleDisplayMode(.inline)
        .onAppear {
            loadLessons()
        }
        .alert("載入錯誤", isPresented: .constant(databaseManager.error != nil)) {
            Button("確定") {
                databaseManager.error = nil
            }
            Button("重試") {
                loadLessons()
            }
        } message: {
            Text(databaseManager.error?.localizedDescription ?? "未知錯誤")
                .font(.custom(nativeLanguageFontName, size: 14))
        }
    }
    
    private func loadLessons() {
        print("🚀 開始載入課程資料... sortOrder: \(sortOrder)")
        isLoading = true
        
        /*
        databaseManager.error = nil
        
        DispatchQueue.global(qos: .userInitiated).async {
            let fetchedLessons = self.databaseManager.fetchLessons(
                targetLanguage: self.targetLanguage,
                nativeLanguage: self.nativeLanguage,
                topicSortOrder: self.sortOrder
            )
            
            DispatchQueue.main.async {
                self.lessons = fetchedLessons
                self.isLoading = false
                
                if fetchedLessons.isEmpty {
                    print("⚠️ 課程載入完成，但沒有找到資料")
                } else {
                    print("✅ 成功載入 \(fetchedLessons.count) 個課程項目")
                }
            }
        }*/
    }
}

struct LessonCard: View {
    let lesson: Lesson
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    @State private var isPlaying = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("第 \(lesson.id) 課")
                    .font(.custom(nativeLanguageFontName, size: 14))
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(Color.blue.opacity(0.1))
                    .cornerRadius(20)
                
                Spacer()
                
                if lesson.audioPath != nil {
                    Button(action: {
                        playAudio()
                    }) {
                        Image(systemName: isPlaying ? "pause.circle.fill" : "play.circle.fill")
                            .font(.system(size: 24))
                            .foregroundColor(.blue)
                    }
                }
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text(lesson.targetText)
                    .font(.custom(targetLanguageFontName, size: 18))
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(nil)
                
                Text(lesson.nativeText)
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(nil)
            }
        }
        .padding(16)
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color(.systemBackground))
                .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 2)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color(.systemGray5), lineWidth: 1)
        )
    }
    
    private func playAudio() {
        // TODO: 實現音頻播放功能
        isPlaying.toggle()
        
        if isPlaying {
            // 模擬播放時間
            DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                isPlaying = false
            }
        }
    }
}

struct LessonView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            LessonView(
                sortOrder: 1,
                targetLanguage: "en",
                nativeLanguage: "zh_TW",
                targetTopic: "Basic Greetings",
                nativeTopic: "基本問候",
                targetLanguageFontName: "Helvetica",
                nativeLanguageFontName: "PingFangTC-Regular"
            )
        }
    }
}
