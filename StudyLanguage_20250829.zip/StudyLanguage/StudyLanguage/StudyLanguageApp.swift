//
//  StudyLanguageApp.swift
//  StudyLanguage
//
//  Created by admin on 2025/8/29.
//

import SwiftUI

@main
struct StudyLanguageApp: App {
    var body: some Scene {
        WindowGroup {
            //ContentView()
           // CourseView(fileName: "zh_TW_course", voiceModel: "zh_TW", languageName: "中文繁體")
            
            /*
            CourseView(
                    targetFileName: "zh_TW_course",
                    targetVoiceModel: "zh_TW",
                    targetLanguageName: "中文繁體",
                    targetFontName: "PingFangTC-Regular",
                    nativeFileName: "en_course",
                    nativeVoiceModel: "en",
                    nativeLanguageName: "English",
                    nativeFontName: "Helvetica"
                )
            */
            
            ContentView()
        }
    }
}
