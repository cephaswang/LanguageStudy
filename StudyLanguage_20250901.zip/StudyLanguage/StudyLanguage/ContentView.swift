import SwiftUI

struct ContentView: View {
    @State private var showSplash = true
    private let splashDuration: TimeInterval = 5
    
    var body: some View {
        ZStack {
            // 主頁
            /*
            OutlineView(
                targetLanguage: "en-US",
                nativeLanguage: "zh_TW",
                targetLanguageFontName: "Helvetica",
                nativeLanguageFontName: "PingFangTC-Regular"
            )
             
             OutlineView(
                 targetLanguage: "zh_TW",
                 nativeLanguage: "en-US",
                 targetLanguageFontName: "PingFangTC-Regular",
                 nativeLanguageFontName: "Helvetica"
             )
            */
            OutlineView(
                targetLanguage: "it-IT",
                nativeLanguage: "en-US",
                targetLanguageFontName: "PingFangTC-Regular",
                nativeLanguageFontName: "Helvetica"
            )
            .opacity(showSplash ? 0 : 1)
            
            // 動畫頁
            if showSplash {
                SplashView()
                    .transition(.opacity.combined(with: .scale))
            }
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + splashDuration) {
                withAnimation(.easeInOut(duration: 0.6)) {
                    showSplash = false
                }
            }
        }
    }
}

// MARK: - 動畫頁（無文字）
struct SplashView: View {
    @State private var rotate = false
    @State private var pulse = false

    var body: some View {
        ZStack {
            LinearGradient(colors: [.blue, .teal],
                           startPoint: .topLeading, endPoint: .bottomTrailing)
                .ignoresSafeArea()

            ZStack {
                Circle()
                    .fill(.ultraThinMaterial)
                    .frame(width: 180, height: 180)
                    .shadow(radius: 20)

                Image(systemName: "globe.asia.australia.fill")
                    .font(.system(size: 80, weight: .semibold))
                    .rotationEffect(.degrees(rotate ? 360 : 0))
                    .scaleEffect(pulse ? 1.05 : 0.95)
                    .animation(.linear(duration: 5).repeatForever(autoreverses: false), value: rotate)
                    .animation(.easeInOut(duration: 1.2).repeatForever(autoreverses: true), value: pulse)
                    .foregroundStyle(.white)
            }
        }
        .onAppear {
            rotate = true
            pulse = true
        }
    }
}

#Preview {
    ContentView()
}
