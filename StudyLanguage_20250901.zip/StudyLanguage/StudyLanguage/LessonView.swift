import SwiftUI

struct Lesson {
    let id: Int
    let targetText: String
    let nativeText: String
    let pinyinText: String? // 拼音字段
    let hiraganaText: String? // 平假名字段
    let katakanaText: String? // 片假名字段
    let audioPath: String?
}

struct UpdatedLessonView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let targetTopic: String
    let nativeTopic: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    @StateObject private var databaseManager = DatabaseManager()
    @StateObject private var settingsManager = SettingsManager()
    @StateObject private var practiceDatabase = PracticeDatabase()
    @StateObject private var playService: EnhancedPlayService
    
    @State private var lessons: [Lesson] = []
    @State private var isLoading = true
    @State private var completedLessons: Set<Int> = []
    @State private var displayMode: DisplayMode = .bilingual
    @State private var showingSettings = false
    @State private var showPinyin = true // 拼音顯示控制
    @State private var showKana = true // 日語假名顯示控制
    
    enum DisplayMode: String, CaseIterable {
        case bilingual = "雙語顯示"
        case targetOnly = "目標語言"
        case nativeOnly = "母語"
    }
    
    // 檢查是否為中文語言
    private var isChineseTarget: Bool {
        return targetLanguage == "zh_TW" || targetLanguage == "zh_CN"
    }
    
    // 檢查是否為日語語言
    private var isJapaneseTarget: Bool {
        return targetLanguage == "ja-JP"
    }
    
    // Custom initializer to properly initialize StateObject dependencies
    init(sortOrder: Int, targetLanguage: String, nativeLanguage: String, targetTopic: String, nativeTopic: String, targetLanguageFontName: String, nativeLanguageFontName: String) {
        self.sortOrder = sortOrder
        self.targetLanguage = targetLanguage
        self.nativeLanguage = nativeLanguage
        self.targetTopic = targetTopic
        self.nativeTopic = nativeTopic
        self.targetLanguageFontName = targetLanguageFontName
        self.nativeLanguageFontName = nativeLanguageFontName
        
        let settings = SettingsManager()
        let practice = PracticeDatabase()
        self._settingsManager = StateObject(wrappedValue: settings)
        self._practiceDatabase = StateObject(wrappedValue: practice)
        self._playService = StateObject(wrappedValue: EnhancedPlayService(settingsManager: settings, practiceDatabase: practice))
    }
    
    var progressPercentage: Double {
        guard !lessons.isEmpty else { return 0 }
        return Double(completedLessons.count) / Double(lessons.count)
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // 頂部資訊區域
            HeaderSection()
            
            // 播放控制區域
            PlaybackControlSection()
            
            // 主要內容區域
            if isLoading {
                LoadingView()
            } else if lessons.isEmpty {
                EmptyStateView()
            } else {
                LessonContentView()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                HStack {
                    // 拼音顯示開關（僅限中文）
                    if isChineseTarget {
                        Button(action: { showPinyin.toggle() }) {
                            Image(systemName: showPinyin ? "textformat.abc" : "textformat.abc.dottedunderline")
                                .foregroundColor(showPinyin ? .blue : .gray)
                        }
                    }
                    
                    // 假名顯示開關（僅限日語）
                    if isJapaneseTarget {
                        Button(action: { showKana.toggle() }) {
                            Image(systemName: showKana ? "character.book.closed.fill" : "character.book.closed")
                                .foregroundColor(showKana ? .purple : .gray)
                        }
                    }
                    
                    // 顯示模式選擇
                    Menu {
                        ForEach(DisplayMode.allCases, id: \.self) { mode in
                            Button(mode.rawValue) {
                                displayMode = mode
                            }
                        }
                    } label: {
                        Image(systemName: "textformat.alt")
                            .foregroundColor(.blue)
                    }
                    
                    // 設定按鈕
                    Button(action: { showingSettings = true }) {
                        Image(systemName: "gearshape.fill")
                            .foregroundColor(.gray)
                    }
                }
            }
        }
        .onAppear {
            loadLessons()
            loadCompletedLessons()
        }
        .onDisappear {
            // 當離開頁面時，停止播放
            playService.stopPlayback()
        }
        .sheet(isPresented: $showingSettings) {
            SettingsView()
        }
        .alert("載入錯誤",
               isPresented: Binding(
                get: { databaseManager.error != nil },
                set: { newVal in if !newVal { databaseManager.error = nil } }
               )) {
            Button("確定") {
                databaseManager.error = nil
            }
            Button("重試") {
                databaseManager.error = nil
                loadLessons()
            }
        } message: {
            Text(databaseManager.error?.localizedDescription ?? "未知錯誤")
                .font(.custom(nativeLanguageFontName, size: 14))
        }
    }
    
    // MARK: - Header Section
    @ViewBuilder
    private func HeaderSection() -> some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                // 課程編號圓圈
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [.purple, .pink, .orange],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 60, height: 60)
                        .shadow(color: .purple.opacity(0.3), radius: 8, x: 0, y: 4)
                    
                    VStack(spacing: 2) {
                        Text("第")
                            .font(.custom(nativeLanguageFontName, size: 12))
                            .foregroundColor(.white)
                        Text("\(sortOrder)")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                        Text("課")
                            .font(.custom(nativeLanguageFontName, size: 12))
                            .foregroundColor(.white)
                    }
                }
                
                // 主題資訊
                VStack(alignment: .leading, spacing: 8) {
                    Text(targetTopic)
                        .font(.custom(targetLanguageFontName, size: 20))
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                        .lineLimit(2)
                    
                    Text(nativeTopic)
                        .font(.custom(nativeLanguageFontName, size: 16))
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                    
                    // 語言標籤
                    HStack(spacing: 12) {
                        LanguageTag(language: targetLanguage, color: .blue)
                        LanguageTag(language: nativeLanguage, color: .green)
                        if isChineseTarget {
                            LanguageTag(language: "拼音", color: .purple)
                        }
                        if isJapaneseTarget {
                            LanguageTag(language: "假名", color: .orange)
                        }
                    }
                }
                
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
        }
        .background(
            LinearGradient(
                colors: [Color(.systemBackground), Color(.systemGray6)],
                startPoint: .top,
                endPoint: .bottom
            )
        )
    }
    
    // MARK: - Playback Control Section
    @ViewBuilder
    private func PlaybackControlSection() -> some View {
        HStack(spacing: 20) {
            // 播放狀態指示
            VStack(alignment: .leading, spacing: 4) {
                if playService.isPlaying || playService.isPaused {
                    Text("正在播放第 \(playService.currentPlayingLessonId ?? 0) 句")
                        .font(.custom(nativeLanguageFontName, size: 12))
                        .foregroundColor(.blue)
                    
                    if !playService.currentPlayingText.isEmpty {
                        Text(playService.currentPlayingText.prefix(30) + "...")
                            .font(.custom(targetLanguageFontName, size: 10))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                } else {
                    Text("準備播放")
                        .font(.custom(nativeLanguageFontName, size: 12))
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // 播放控制按鈕
            HStack(spacing: 16) {
                // 停止按鈕
                Button(action: {
                    playService.stopPlayback()
                }) {
                    Image(systemName: "stop.fill")
                        .font(.system(size: 18))
                        .foregroundColor(playService.isPlaying || playService.isPaused ? .red : .gray)
                }
                .disabled(!playService.isPlaying && !playService.isPaused)
                
                // 播放/暫停按鈕
                Button(action: {
                    playService.pauseResume()
                }) {
                    Image(systemName: playService.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                }
                
                // 連續播放按鈕
                if settingsManager.continuousPlayEnabled {
                    Button(action: {
                        if let firstLesson = lessons.first {
                            playService.startContinuousPlayback(
                                fromLessonId: firstLesson.id,
                                lessons: lessons,
                                courseOrder: sortOrder,
                                targetLang: targetLanguage,
                                nativeLang: nativeLanguage
                            )
                        }
                    }) {
                        Image(systemName: "play.rectangle.fill")
                            .font(.system(size: 18))
                            .foregroundColor(.green)
                    }
                    .disabled(playService.isPlaying || lessons.isEmpty)
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(Color(.systemGray6).opacity(0.5))
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(Color(.systemGray4)),
            alignment: .bottom
        )
    }
    
    // MARK: - Content Views
    @ViewBuilder
    private func LoadingView() -> some View {
        VStack(spacing: 20) {
            ProgressView()
                .scaleEffect(1.5)
                .tint(.blue)
            
            Text("載入課程中...")
                .font(.custom(nativeLanguageFontName, size: 18))
                .foregroundColor(.secondary)
            
            Text("共 30 個句子等待您的練習")
                .font(.custom(nativeLanguageFontName, size: 14))
                .foregroundColor(Color(.tertiaryLabel))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }
    
    @ViewBuilder
    private func EmptyStateView() -> some View {
        VStack(spacing: 24) {
            Image(systemName: "book.closed.fill")
                .font(.system(size: 60))
                .foregroundColor(.orange)
            
            VStack(spacing: 12) {
                Text("暫無課程內容")
                    .font(.custom(nativeLanguageFontName, size: 22))
                    .fontWeight(.bold)
                
                Text("此主題的課程正在準備中\n請稍後再試")
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
            }
            
            Button(action: loadLessons) {
                HStack(spacing: 8) {
                    Image(systemName: "arrow.clockwise")
                    Text("重新載入")
                        .font(.custom(nativeLanguageFontName, size: 16))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
                .background(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(25)
            }
        }
        .padding(32)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }
    
    @ViewBuilder
    private func LessonContentView() -> some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(lessons, id: \.id) { lesson in
                        EnhancedLessonCard(
                            lesson: lesson,
                            displayMode: displayMode,
                            targetLanguageFontName: targetLanguageFontName,
                            nativeLanguageFontName: nativeLanguageFontName,
                            isCompleted: completedLessons.contains(lesson.id),
                            isCurrentlyPlaying: playService.currentPlayingLessonId == lesson.id,
                            playService: playService,
                            settingsManager: settingsManager,
                            practiceDatabase: practiceDatabase,
                            courseOrder: sortOrder,
                            targetLanguage: targetLanguage,
                            nativeLanguage: nativeLanguage,
                            allLessons: lessons,
                            showPinyin: showPinyin && isChineseTarget, // 傳遞拼音顯示狀態
                            showKana: showKana && isJapaneseTarget, // 傳遞假名顯示狀態
                            onComplete: {
                                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                                    toggleLessonCompletion(lesson.id)
                                }
                            }
                        )
                        // 每個 card 綁定 id，供 scrollTo 使用
                        .id(lesson.id)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 20)
            }
            // 監聽 currentPlayingLessonId 變化，自動置頂
            .onChange(of: playService.currentPlayingLessonId) { newId in
                if let id = newId {
                    withAnimation(.easeInOut) {
                        proxy.scrollTo(id, anchor: .top)
                    }
                }
            }
        }
        .background(Color(.systemGroupedBackground))
        .refreshable {
            loadLessons()
            loadCompletedLessons()
        }
    }

    
    // MARK: - Helper Functions
    private func loadLessons() {
        print("🚀 開始載入課程資料... sortOrder: \(sortOrder)")
        isLoading = true
        
        DispatchQueue.global(qos: .userInitiated).async {
            let rows = databaseManager.fetchLessons(
                targetLanguage: targetLanguage,
                nativeLanguage: nativeLanguage,
                sortOrder: sortOrder
            )
            
            let mapped = rows.map { row in
                Lesson(
                    id: row.id,
                    targetText: row.targetText,
                    nativeText: row.nativeText,
                    pinyinText: row.pinyinText, // 使用拼音數據
                    hiraganaText: row.hiraganaText, // 使用平假名數據
                    katakanaText: row.katakanaText, // 使用片假名數據
                    audioPath: nil
                )
            }
            
            DispatchQueue.main.async {
                withAnimation(.easeInOut(duration: 0.5)) {
                    self.lessons = mapped
                    self.isLoading = false
                }
                print("✅ 成功載入 \(mapped.count) 個課程項目")
            }
        }
    }
    
    private func loadCompletedLessons() {
        completedLessons = practiceDatabase.getCompletedLessons(
            courseOrder: sortOrder,
            targetLang: targetLanguage,
            nativeLang: nativeLanguage
        )
    }
    
    private func toggleLessonCompletion(_ lessonId: Int) {
        if completedLessons.contains(lessonId) {
            completedLessons.remove(lessonId)
            // Update database to mark as incomplete
            practiceDatabase.updateProgress(
                lessonId: lessonId,
                courseOrder: sortOrder,
                targetLang: targetLanguage,
                nativeLang: nativeLanguage,
                isCompleted: false
            )
        } else {
            completedLessons.insert(lessonId)
            // Update database to mark as complete
            practiceDatabase.updateProgress(
                lessonId: lessonId,
                courseOrder: sortOrder,
                targetLang: targetLanguage,
                nativeLang: nativeLanguage,
                isCompleted: true
            )
        }
    }
}

// MARK: - Enhanced Lesson Card
struct EnhancedLessonCard: View {
    let lesson: Lesson
    let displayMode: UpdatedLessonView.DisplayMode
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    let isCompleted: Bool
    let isCurrentlyPlaying: Bool
    let playService: EnhancedPlayService
    let settingsManager: SettingsManager
    let practiceDatabase: PracticeDatabase
    let courseOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let allLessons: [Lesson]
    let showPinyin: Bool // 拼音顯示參數
    let showKana: Bool // 假名顯示參數
    let onComplete: () -> Void
    
    @State private var showTranslation = false
    
    var body: some View {
        VStack(spacing: 0) {
            // 卡片標題列
            HStack {
                // 課程編號
                Text("第 \(lesson.id) 句")
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(
                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: isCompleted ? [.green, .mint] : (isCurrentlyPlaying ? [.orange, .red] : [.blue, .purple]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                    )
                
                Spacer()
                
                // 功能按鈕
                HStack(spacing: 12) {
                    // 顯示翻譯按鈕
                    if displayMode == .targetOnly || displayMode == .nativeOnly {
                        Button(action: { showTranslation.toggle() }) {
                            Image(systemName: showTranslation ? "eye.slash" : "eye")
                                .font(.system(size: 16))
                                .foregroundColor(.blue)
                        }
                    }
                    
                    // 單句播放按鈕
                    Button(action: {
                        playService.playSingleSentence(
                            lessonId: lesson.id,
                            targetText: lesson.targetText,
                            nativeText: lesson.nativeText,
                            courseOrder: courseOrder,
                            targetLang: targetLanguage,
                            nativeLang: nativeLanguage
                        )
                    }) {
                        Image(systemName: isCurrentlyPlaying ? "waveform" : "play.circle.fill")
                            .font(.system(size: 20))
                            .foregroundColor(isCurrentlyPlaying ? .orange : .green)
                    }
                    .disabled(playService.isPlaying && !isCurrentlyPlaying)
                    
                    // 從此句開始連續播放按鈕
                    if settingsManager.continuousPlayEnabled {
                        Button(action: {
                            playService.startContinuousPlayback(
                                fromLessonId: lesson.id,
                                lessons: allLessons,
                                courseOrder: courseOrder,
                                targetLang: targetLanguage,
                                nativeLang: nativeLanguage
                            )
                        }) {
                            Image(systemName: "play.rectangle.fill")
                                .font(.system(size: 16))
                                .foregroundColor(.purple)
                        }
                        .disabled(playService.isPlaying)
                    }
                    
                    // 完成按鈕
                    Button(action: onComplete) {
                        Image(systemName: isCompleted ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 20))
                            .foregroundColor(isCompleted ? .green : .gray)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 12)
            
            // 句子內容
            VStack(alignment: .leading, spacing: 12) {
                // 根據顯示模式顯示內容
                switch displayMode {
                case .bilingual:
                    BilingualContent()
                case .targetOnly:
                    TargetOnlyContent()
                case .nativeOnly:
                    NativeOnlyContent()
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.systemBackground))
                .shadow(
                    color: isCurrentlyPlaying ? .orange.opacity(0.3) : (isCompleted ? .green.opacity(0.2) : .black.opacity(0.08)),
                    radius: 8,
                    x: 0,
                    y: 4
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(
                    isCurrentlyPlaying ? .orange.opacity(0.5) : (isCompleted ? .green.opacity(0.3) : Color(.systemGray5)),
                    lineWidth: isCurrentlyPlaying ? 2.0 : 1.5
                )
        )
        .scaleEffect(isCurrentlyPlaying ? 1.02 : (isCompleted ? 0.98 : 1.0))
        .animation(.spring(response: 0.3), value: isCompleted)
        .animation(.spring(response: 0.2), value: isCurrentlyPlaying)
    }
    
    @ViewBuilder
    private func BilingualContent() -> some View {
        VStack(alignment: .leading, spacing: 14) {
            // 目標語言
            VStack(alignment: .leading, spacing: 6) {
                Text("🎯 Target")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.blue)
                    .opacity(0.8)
                
                Text(lesson.targetText)
                    .font(.custom(targetLanguageFontName, size: 18))
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .lineLimit(nil)
                
                // 拼音顯示（僅限中文目標語言）
                if showPinyin, let pinyin = lesson.pinyinText, !pinyin.isEmpty {
                    Text(pinyin)
                        .font(.system(size: 14, weight: .regular, design: .monospaced))
                        .foregroundColor(.purple)
                        .padding(.top, 2)
                }
                
                // 假名顯示（僅限日語目標語言）
                if showKana {
                    if let hiragana = lesson.hiraganaText, !hiragana.isEmpty {
                        Text("ひらがな: \(hiragana)")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(.orange)
                            .padding(.top, 2)
                    }
                    if let katakana = lesson.katakanaText, !katakana.isEmpty {
                        Text("カタカナ: \(katakana)")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundColor(.red)
                            .padding(.top, 2)
                    }
                }
            }
            
            Divider()
                .opacity(0.5)
            
            // 母語翻譯
            VStack(alignment: .leading, spacing: 6) {
                Text("🏠 Translation")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.green)
                    .opacity(0.8)
                
                Text(lesson.nativeText)
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .foregroundColor(.secondary)
                    .lineLimit(nil)
            }
        }
    }
    
    @ViewBuilder
    private func TargetOnlyContent() -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(lesson.targetText)
                .font(.custom(targetLanguageFontName, size: 20))
                .fontWeight(.medium)
                .foregroundColor(.primary)
                .lineLimit(nil)
            
            // 拼音顯示（僅限中文目標語言）
            if showPinyin, let pinyin = lesson.pinyinText, !pinyin.isEmpty {
                Text(pinyin)
                    .font(.system(size: 16, weight: .regular, design: .monospaced))
                    .foregroundColor(.purple)
                    .padding(.top, 4)
            }
            
            // 假名顯示（僅限日語目標語言）
            if showKana {
                if let hiragana = lesson.hiraganaText, !hiragana.isEmpty {
                    Text("ひらがな: \(hiragana)")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.orange)
                        .padding(.top, 2)
                }
                if let katakana = lesson.katakanaText, !katakana.isEmpty {
                    Text("カタカナ: \(katakana)")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.red)
                        .padding(.top, 2)
                }
            }
            
            if showTranslation {
                Text(lesson.nativeText)
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .foregroundColor(.secondary)
                    .lineLimit(nil)
                    .transition(.opacity.combined(with: .slide))
            }
        }
    }
    
    @ViewBuilder
    private func NativeOnlyContent() -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(lesson.nativeText)
                .font(.custom(nativeLanguageFontName, size: 18))
                .fontWeight(.medium)
                .foregroundColor(.primary)
                .lineLimit(nil)
            
            if showTranslation {
                VStack(alignment: .leading, spacing: 8) {
                    Text(lesson.targetText)
                        .font(.custom(targetLanguageFontName, size: 16))
                        .foregroundColor(.secondary)
                        .lineLimit(nil)
                    
                    // 拼音顯示（僅限中文目標語言）
                    if showPinyin, let pinyin = lesson.pinyinText, !pinyin.isEmpty {
                        Text(pinyin)
                            .font(.system(size: 14, weight: .regular, design: .monospaced))
                            .foregroundColor(.purple)
                            .padding(.top, 2)
                    }
                    
                    // 假名顯示（僅限日語目標語言）
                    if showKana {
                        if let hiragana = lesson.hiraganaText, !hiragana.isEmpty {
                            Text("ひらがな: \(hiragana)")
                                .font(.system(size: 14, weight: .regular))
                                .foregroundColor(.orange)
                                .padding(.top, 2)
                        }
                        if let katakana = lesson.katakanaText, !katakana.isEmpty {
                            Text("カタカナ: \(katakana)")
                                .font(.system(size: 14, weight: .regular))
                                .foregroundColor(.red)
                                .padding(.top, 2)
                        }
                    }
                }
                .transition(.opacity.combined(with: .slide))
            }
        }
    }
}

// MARK: - Supporting Views (Reused from original)
struct LanguageTag: View {
    let language: String
    let color: Color
    
    var body: some View {
        Text(language.uppercased())
            .font(.system(size: 10, weight: .bold, design: .monospaced))
            .foregroundColor(color)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 4)
                    .fill(color.opacity(0.1))
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(color.opacity(0.3), lineWidth: 1)
                    )
            )
    }
}

struct StatItem: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundColor(color)
            
            Text(title)
                .font(.system(size: 12))
                .foregroundColor(.secondary)
        }
    }
}

// MARK: - Preview
struct UpdatedLessonView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            UpdatedLessonView(
                sortOrder: 1,
                targetLanguage: "ja-JP",
                nativeLanguage: "en",
                targetTopic: "基本問候と自己紹介",
                nativeTopic: "Basic Greetings & Introductions",
                targetLanguageFontName: "HiraginoSans-W3",
                nativeLanguageFontName: "Helvetica"
            )
        }
    }
}
