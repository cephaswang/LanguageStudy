// DatabaseManager.swift — 加入拼音和日语假名查询支援
import SQLite3
import SwiftUI

class DatabaseManager: ObservableObject {
    private var database: OpaquePointer?
    @Published var error: Error?
    private let queue = DispatchQueue(label: "DatabaseManager", qos: .background)
    private var isInitialized = false

    deinit {
        if database != nil {
            sqlite3_close(database)
        }
    }

    func openDatabase() {
        queue.sync {
            guard !isInitialized else { return }
            _openDatabase()
            isInitialized = true
        }
    }

    private func _openDatabase() {
        // 1) Documents/study.db path
        guard let documentsPath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first else {
            let err = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "無法找到 Documents 目錄"])
            print(err.localizedDescription)
            DispatchQueue.main.async { self.error = err }
            return
        }
        let dbURL = documentsPath.appendingPathComponent("study.db")
        let dbPath = dbURL.path

        // 2) 僅在容量不同（或 Documents 不存在）時，從 bundle 複製 study.db
        if !conditionalCopyBundledDB(to: dbURL) {
            let err = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "缺少 bundled study.db"])
            print(err.localizedDescription)
            DispatchQueue.main.async { self.error = err }
            return
        }

        // 3) Open DB
        if sqlite3_open(dbPath, &database) != SQLITE_OK {
            let err = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "無法開啟資料庫"])
            print(err.localizedDescription)
            sqlite3_close(database)
            database = nil
            DispatchQueue.main.async { self.error = err }
            return
        }
        print("資料庫已開啟: \(dbPath)")
    }

    /// 只有在「Documents 下不存在」或「容量不同」時才複製 bundle 的 study.db。
    /// - Returns: true 代表流程成功（不論是否實際複製），false 代表 bundle 無檔或出錯。
    private func conditionalCopyBundledDB(to destinationURL: URL) -> Bool {
        guard let bundledDB = Bundle.main.url(forResource: "study", withExtension: "db") else {
            // bundle 沒有預建 DB
            return false
        }
        do {
            let fm = FileManager.default
            let bundledAttr = try fm.attributesOfItem(atPath: bundledDB.path)
            let bundledSize = (bundledAttr[.size] as? NSNumber)?.int64Value ?? 0

            var needCopy = false
            if fm.fileExists(atPath: destinationURL.path) {
                let destAttr = try fm.attributesOfItem(atPath: destinationURL.path)
                let destSize = (destAttr[.size] as? NSNumber)?.int64Value ?? -1
                if destSize != bundledSize {
                    needCopy = true
                }
            } else {
                // Documents 尚無檔案 → 必須複製
                needCopy = true
            }

            if needCopy {
                if fm.fileExists(atPath: destinationURL.path) {
                    try fm.removeItem(at: destinationURL)
                }
                try fm.copyItem(at: bundledDB, to: destinationURL)
                print("已複製/覆蓋 Documents 下的 study.db（因容量不同或不存在）")
            } else {
                print("Documents 下已有相同容量的 study.db，不需複製")
            }
            return true
        } catch {
            print("比較或複製 study.db 失敗: \(error)")
            return false
        }
    }

    // MARK: - Queries

    func fetchOutlines(targetLanguage: String, nativeLanguage: String) -> [Outline] {
        openDatabase()
        return queue.sync {
            guard let database = database else { return [] }

            let query = """
                SELECT t.sort_order, t.outline as target_text, n.outline as native_text
                FROM outlines t
                JOIN outlines n ON t.sort_order = n.sort_order
                WHERE t.lang_code = ? AND n.lang_code = ?
                ORDER BY t.sort_order
            """

            var statement: OpaquePointer?
            var results: [Outline] = []
            defer { sqlite3_finalize(statement) }

            if sqlite3_prepare_v2(database, query, -1, &statement, nil) == SQLITE_OK {
                sqlite3_bind_text(statement, 1, (targetLanguage as NSString).utf8String, -1, SQLITE_TRANSIENT)
                sqlite3_bind_text(statement, 2, (nativeLanguage as NSString).utf8String, -1, SQLITE_TRANSIENT)

                while sqlite3_step(statement) == SQLITE_ROW {
                    let sortOrder = Int(sqlite3_column_int(statement, 0))
                    let targetText = String(cString: sqlite3_column_text(statement, 1))
                    let nativeText = String(cString: sqlite3_column_text(statement, 2))
                    results.append(Outline(sortOrder: sortOrder, targetLanguageText: targetText, nativeLanguageText: nativeText))
                }
            } else {
                let msg = String(cString: sqlite3_errmsg(database))
                print("查詢失敗: \(msg)")
                DispatchQueue.main.async {
                    self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "查詢失敗: \(msg)"])
                }
            }

            print("fetchOutlines -> \(results.count) 筆")
            return results
        }
    }

    func fetchTopics(targetLanguage: String, nativeLanguage: String, sortOrder: Int) -> [Topic] {
        openDatabase()
        return queue.sync {
            guard let database = database else { return [] }

            let startIndex = sortOrder * 10 - 10
            let endIndex = sortOrder * 10

            let query = """
                SELECT t.sort_order, t.topic as target_topic, n.topic as native_topic
                FROM "topics_\(targetLanguage)" t
                JOIN "topics_\(nativeLanguage)" n ON t.sort_order = n.sort_order
                WHERE t.sort_order > ? AND t.sort_order <= ?
                ORDER BY t.sort_order
            """

            var statement: OpaquePointer?
            var results: [Topic] = []
            defer { sqlite3_finalize(statement) }

            if sqlite3_prepare_v2(database, query, -1, &statement, nil) == SQLITE_OK {
                sqlite3_bind_int(statement, 1, Int32(startIndex))
                sqlite3_bind_int(statement, 2, Int32(endIndex))

                while sqlite3_step(statement) == SQLITE_ROW {
                    let index = Int(sqlite3_column_int(statement, 0))
                    let targetText = String(cString: sqlite3_column_text(statement, 1))
                    let nativeText = String(cString: sqlite3_column_text(statement, 2))
                    results.append(Topic(index: index, targetText: targetText, nativeText: nativeText))
                }
            } else {
                let msg = String(cString: sqlite3_errmsg(database))
                print("查詢主題失敗: \(msg)")
                DispatchQueue.main.async {
                    self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "查詢主題失敗: \(msg)"])
                }
            }

            print("fetchTopics -> \(results.count) 筆主題")
            return results
        }
    }

    struct LessonRow {
        let id: Int
        let targetText: String
        let nativeText: String
        let pinyinText: String? // 拼音字段
        let hiraganaText: String? // 平假名字段
        let katakanaText: String? // 片假名字段
    }

    /// 查詢指定主題 (topics_sn = sortOrder) 的會話句子，雙語對齊（依 sort_order 排序）
    /// 當目標語言為中文時，同時查詢拼音；當目標語言為日語時，同時查詢平假名和片假名
    func fetchLessons(targetLanguage: String, nativeLanguage: String, sortOrder: Int) -> [LessonRow] {
        openDatabase()
        return queue.sync {
            guard let database = database else { return [] }

            // 檢查是否為中文目標語言
            let isChineseTarget = targetLanguage == "zh_TW" || targetLanguage == "zh_CN"
            // 檢查是否為日語目標語言
            let isJapaneseTarget = targetLanguage == "ja-JP"
            
            let query: String
            if isChineseTarget {
                // 中文目標語言時，加入拼音查詢
                query = """
                    SELECT t.sort_order, t.sentence AS target_sentence, n.sentence AS native_sentence, p.sentence AS pinyin_sentence
                    FROM "sentence_\(targetLanguage)" t
                    JOIN "sentence_\(nativeLanguage)" n
                      ON t.topics_sn = n.topics_sn
                     AND t.sort_order = n.sort_order
                    LEFT JOIN "sentence_pinyin" p
                      ON t.topics_sn = p.topics_sn
                     AND t.sort_order = p.sort_order
                    WHERE t.topics_sn = ?
                    ORDER BY t.sort_order;
                """
            } else if isJapaneseTarget {
                // 日語目標語言時，加入平假名和片假名查詢
                query = """
                    SELECT t.sort_order, t.sentence AS target_sentence, n.sentence AS native_sentence,
                           h.sentence AS hiragana_sentence, k.sentence AS katakana_sentence
                    FROM "sentence_\(targetLanguage)" t
                    JOIN "sentence_\(nativeLanguage)" n
                      ON t.topics_sn = n.topics_sn
                     AND t.sort_order = n.sort_order
                    LEFT JOIN "sentence_ja-Hira" h
                      ON t.topics_sn = h.topics_sn
                     AND t.sort_order = h.sort_order
                    LEFT JOIN "sentence_ja-Kana" k
                      ON t.topics_sn = k.topics_sn
                     AND t.sort_order = k.sort_order
                    WHERE t.topics_sn = ?
                    ORDER BY t.sort_order;
                """
            } else {
                // 非中文/日語目標語言時，不查詢額外發音數據
                query = """
                    SELECT t.sort_order, t.sentence AS target_sentence, n.sentence AS native_sentence
                    FROM "sentence_\(targetLanguage)" t
                    JOIN "sentence_\(nativeLanguage)" n
                      ON t.topics_sn = n.topics_sn
                     AND t.sort_order = n.sort_order
                    WHERE t.topics_sn = ?
                    ORDER BY t.sort_order;
                """
            }

            var statement: OpaquePointer?
            var results: [LessonRow] = []
            defer { sqlite3_finalize(statement) }

            if sqlite3_prepare_v2(database, query, -1, &statement, nil) == SQLITE_OK {
                sqlite3_bind_int(statement, 1, Int32(sortOrder))

                while sqlite3_step(statement) == SQLITE_ROW {
                    let id = Int(sqlite3_column_int(statement, 0))
                    let targetText = String(cString: sqlite3_column_text(statement, 1))
                    let nativeText = String(cString: sqlite3_column_text(statement, 2))
                    
                    var pinyinText: String? = nil
                    var hiraganaText: String? = nil
                    var katakanaText: String? = nil
                    
                    if isChineseTarget {
                        // 檢查拼音列是否有數據
                        if let pinyinPointer = sqlite3_column_text(statement, 3) {
                            pinyinText = String(cString: pinyinPointer)
                        }
                    } else if isJapaneseTarget {
                        // 檢查平假名和片假名列是否有數據
                        if let hiraganaPointer = sqlite3_column_text(statement, 3) {
                            hiraganaText = String(cString: hiraganaPointer)
                        }
                        if let katakanaPointer = sqlite3_column_text(statement, 4) {
                            katakanaText = String(cString: katakanaPointer)
                        }
                    }
                    
                    results.append(LessonRow(
                        id: id,
                        targetText: targetText,
                        nativeText: nativeText,
                        pinyinText: pinyinText,
                        hiraganaText: hiraganaText,
                        katakanaText: katakanaText
                    ))
                }
            } else {
                let msg = String(cString: sqlite3_errmsg(database))
                print("查詢句子失敗: \(msg)")
                DispatchQueue.main.async {
                    self.error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "查詢句子失敗: \(msg)"])
                }
            }

            print("fetchLessons -> \(results.count) 筆句子（topics_sn=\(sortOrder)）")
            if isChineseTarget {
                let pinyinCount = results.compactMap { $0.pinyinText }.count
                print("其中 \(pinyinCount) 筆有拼音數據")
            } else if isJapaneseTarget {
                let hiraganaCount = results.compactMap { $0.hiraganaText }.count
                let katakanaCount = results.compactMap { $0.katakanaText }.count
                print("其中 \(hiraganaCount) 筆有平假名數據，\(katakanaCount) 筆有片假名數據")
            }
            return results
        }
    }
    
    /// 檢查拼音表是否存在
    func checkPinyinTableExists() -> Bool {
        openDatabase()
        return queue.sync {
            guard let database = database else { return false }
            
            let query = """
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='sentence_pinyin';
            """
            
            var statement: OpaquePointer?
            var exists = false
            defer { sqlite3_finalize(statement) }
            
            if sqlite3_prepare_v2(database, query, -1, &statement, nil) == SQLITE_OK {
                if sqlite3_step(statement) == SQLITE_ROW {
                    exists = true
                }
            }
            
            print("拼音表存在狀態: \(exists)")
            return exists
        }
    }
    
    /// 檢查日語假名表是否存在
    func checkJapaneseKanaTablesExist() -> (hiragana: Bool, katakana: Bool) {
        openDatabase()
        return queue.sync {
            guard let database = database else { return (false, false) }
            
            // 檢查平假名表
            let hiraganaQuery = """
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='sentence_ja-Hira';
            """
            
            var hiraganaStatement: OpaquePointer?
            var hiraganaExists = false
            defer { sqlite3_finalize(hiraganaStatement) }
            
            if sqlite3_prepare_v2(database, hiraganaQuery, -1, &hiraganaStatement, nil) == SQLITE_OK {
                if sqlite3_step(hiraganaStatement) == SQLITE_ROW {
                    hiraganaExists = true
                }
            }
            
            // 檢查片假名表
            let katakanaQuery = """
                SELECT name FROM sqlite_master 
                WHERE type='table' AND name='sentence_ja-Kana';
            """
            
            var katakanaStatement: OpaquePointer?
            var katakanaExists = false
            defer { sqlite3_finalize(katakanaStatement) }
            
            if sqlite3_prepare_v2(database, katakanaQuery, -1, &katakanaStatement, nil) == SQLITE_OK {
                if sqlite3_step(katakanaStatement) == SQLITE_ROW {
                    katakanaExists = true
                }
            }
            
            print("平假名表存在狀態: \(hiraganaExists), 片假名表存在狀態: \(katakanaExists)")
            return (hiraganaExists, katakanaExists)
        }
    }
    
    /// 獲取指定主題的拼音數據統計
    func getPinyinStats(sortOrder: Int) -> (total: Int, withPinyin: Int) {
        openDatabase()
        return queue.sync {
            guard let database = database else { return (0, 0) }
            
            // 總句子數
            let totalQuery = """
                SELECT COUNT(*) FROM sentence_pinyin 
                WHERE topics_sn = ?
            """
            
            var totalStatement: OpaquePointer?
            var total = 0
            defer { sqlite3_finalize(totalStatement) }
            
            if sqlite3_prepare_v2(database, totalQuery, -1, &totalStatement, nil) == SQLITE_OK {
                sqlite3_bind_int(totalStatement, 1, Int32(sortOrder))
                if sqlite3_step(totalStatement) == SQLITE_ROW {
                    total = Int(sqlite3_column_int(totalStatement, 0))
                }
            }
            
            // 有拼音的句子數
            let pinyinQuery = """
                SELECT COUNT(*) FROM sentence_pinyin 
                WHERE topics_sn = ? AND sentence IS NOT NULL AND sentence != ''
            """
            
            var pinyinStatement: OpaquePointer?
            var withPinyin = 0
            defer { sqlite3_finalize(pinyinStatement) }
            
            if sqlite3_prepare_v2(database, pinyinQuery, -1, &pinyinStatement, nil) == SQLITE_OK {
                sqlite3_bind_int(pinyinStatement, 1, Int32(sortOrder))
                if sqlite3_step(pinyinStatement) == SQLITE_ROW {
                    withPinyin = Int(sqlite3_column_int(pinyinStatement, 0))
                }
            }
            
            return (total, withPinyin)
        }
    }
    
    /// 獲取指定主題的日語假名數據統計
    func getJapaneseKanaStats(sortOrder: Int) -> (total: Int, withHiragana: Int, withKatakana: Int) {
        openDatabase()
        return queue.sync {
            guard let database = database else { return (0, 0, 0) }
            
            // 總句子數
            let totalQuery = """
                SELECT COUNT(*) FROM "sentence_ja-Hira" 
                WHERE topics_sn = ?
            """
            
            var totalStatement: OpaquePointer?
            var total = 0
            defer { sqlite3_finalize(totalStatement) }
            
            if sqlite3_prepare_v2(database, totalQuery, -1, &totalStatement, nil) == SQLITE_OK {
                sqlite3_bind_int(totalStatement, 1, Int32(sortOrder))
                if sqlite3_step(totalStatement) == SQLITE_ROW {
                    total = Int(sqlite3_column_int(totalStatement, 0))
                }
            }
            
            // 有平假名的句子數
            let hiraganaQuery = """
                SELECT COUNT(*) FROM "sentence_ja-Hira" 
                WHERE topics_sn = ? AND sentence IS NOT NULL AND sentence != ''
            """
            
            var hiraganaStatement: OpaquePointer?
            var withHiragana = 0
            defer { sqlite3_finalize(hiraganaStatement) }
            
            if sqlite3_prepare_v2(database, hiraganaQuery, -1, &hiraganaStatement, nil) == SQLITE_OK {
                sqlite3_bind_int(hiraganaStatement, 1, Int32(sortOrder))
                if sqlite3_step(hiraganaStatement) == SQLITE_ROW {
                    withHiragana = Int(sqlite3_column_int(hiraganaStatement, 0))
                }
            }
            
            // 有片假名的句子數
            let katakanaQuery = """
                SELECT COUNT(*) FROM "sentence_ja-Kana" 
                WHERE topics_sn = ? AND sentence IS NOT NULL AND sentence != ''
            """
            
            var katakanaStatement: OpaquePointer?
            var withKatakana = 0
            defer { sqlite3_finalize(katakanaStatement) }
            
            if sqlite3_prepare_v2(database, katakanaQuery, -1, &katakanaStatement, nil) == SQLITE_OK {
                sqlite3_bind_int(katakanaStatement, 1, Int32(sortOrder))
                if sqlite3_step(katakanaStatement) == SQLITE_ROW {
                    withKatakana = Int(sqlite3_column_int(katakanaStatement, 0))
                }
            }
            
            return (total, withHiragana, withKatakana)
        }
    }
}

// Helper for safe transient binding
private let SQLITE_TRANSIENT = unsafeBitCast(-1, to: sqlite3_destructor_type.self)
