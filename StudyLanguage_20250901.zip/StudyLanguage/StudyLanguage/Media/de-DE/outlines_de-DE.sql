BEGIN TRANSACTION;
INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES
 ('de-DE','Grundlegende Alltagsausdrücke',1),
 ('de-DE','Sozialleben & Interessen',2),
 ('de-DE','Zuhause & Alltag',3),
 ('de-DE','Studium & Arbeit',4),
 ('de-DE','Reisen & Kultur',5),
 ('de-DE','Erweiterte Kommunikation',6),
 ('de-DE','Gesellschaft & Nachrichten',7),
 ('de-DE','Fortgeschrittenes Denken',8),
 ('de-DE','Fachsprache',9),
 ('de-DE','Integrierte Anwendung',10);
COMMIT;
