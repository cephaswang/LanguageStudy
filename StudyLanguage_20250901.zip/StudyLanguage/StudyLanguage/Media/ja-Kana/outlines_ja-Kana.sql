BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES
 ('ja-Kana','キホンテキナニチジョウヒョウゲン',1),
 ('ja-Kana','シャカイセイカツトシュミ',2),
 ('ja-Kana','カテイトニチジョウセイカツ',3),
 ('ja-Kana','ガクシュウトシゴト',4),
 ('ja-Kana','リョコウトブンカ',5),
 ('ja-Kana','コウドナコミュニケーション',6),
 ('ja-Kana','シャカイトニュース',7),
 ('ja-Kana','コウドナシコウ',8),
 ('ja-Kana','センモンテキナゲンゴ',9),
 ('ja-Kana','トウゴウテキナオウヨウ',10);

COMMIT;
