import re
import sys

# ひらがなをカタカナに変換する関数
def hira_to_kata(text):
    return ''.join(chr(ord(c) + 0x60) if 0x3041 <= ord(c) <= 0x3096 else c for c in text)

# 入力ファイルと出力ファイルをコマンドライン引数から取得
if len(sys.argv) != 3:
    print("Usage: python convert_hira_to_kata.py input.sql output.sql")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2]

# 入力ファイルを読み込む
with open(input_file, 'r', encoding='utf-8') as f:
    content = f.read()

# INSERT文のsentence部分を正規表現でマッチして変換
# パターン: ('sentence', num, num)
def replace_sentence(match):
    sentence = match.group(1)
    converted = hira_to_kata(sentence)
    return f"('{converted}',{match.group(2)},{match.group(3)})"

converted_content = re.sub(r"\('([^']+)',(\d+),(\d+)\)", replace_sentence, content)

# 出力ファイルに書き込む
with open(output_file, 'w', encoding='utf-8') as f:
    f.write(converted_content)

print(f"Conversion completed: {input_file} -> {output_file}")

