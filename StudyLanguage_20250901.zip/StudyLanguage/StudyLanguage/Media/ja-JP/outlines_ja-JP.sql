BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES


 ('ja-JP','基本的な日常表現',1),
 ('ja-JP','社会生活と趣味',2),
 ('ja-JP','家庭と日常生活',3),
 ('ja-JP','学習と仕事',4),
 ('ja-JP','旅行と文化',5),
 ('ja-JP','高度なコミュニケーション',6),
 ('ja-JP','社会とニュース',7),
 ('ja-JP','高度な思考',8),
 ('ja-JP','専門的な言語',9),
 ('ja-JP','統合的な応用',10);



COMMIT;
