BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('it-IT','Espressioni quotidiane di base',1),
 ('it-IT','Vita sociale e interessi',2),
 ('it-IT','Casa e vita quotidiana',3),
 ('it-IT','Studio e lavoro',4),
 ('it-IT','Viaggi e cultura',5),
 ('it-IT','Comunicazione avanzata',6),
 ('it-IT','Società e notizie',7),
 ('it-IT','Pensiero avanzato',8),
 ('it-IT','Linguaggio professionale',9),
 ('it-IT','Applicazione integrata',10);

COMMIT;
