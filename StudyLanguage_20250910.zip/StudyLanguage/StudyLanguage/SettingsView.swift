import SwiftUI

struct SettingsView: View {
    @StateObject private var settingsManager = SettingsManager()
    @StateObject private var practiceDatabase = PracticeDatabase()
    @State private var showingClearAlert = false
    @State private var clearAlertType: ClearAlertType = .all
    
    enum ClearAlertType {
        case all
        case current
    }
    
    var body: some View {
        NavigationView {
            Form {
                // MARK: - TTS Settings Section
                Section(header: Text(NSLocalizedString("tts_settings_section", comment: "TTS Settings section header"))) {
                    // Target Language Toggle
                    HStack {
                        Image(systemName: "target")
                            .foregroundColor(.blue)
                        Toggle(NSLocalizedString("play_target_language", comment: "Play Target Language toggle"), isOn: $settingsManager.playTargetLanguage)
                    }
                    
                    // Native Language Toggle
                    HStack {
                        Image(systemName: "house")
                            .foregroundColor(.green)
                        Toggle(NSLocalizedString("play_native_language", comment: "Play Native Language toggle"), isOn: $settingsManager.playNativeLanguage)
                    }
                    
                    // Playback Order
                    HStack {
                        Image(systemName: "arrow.up.arrow.down")
                            .foregroundColor(.orange)
                        
                        VStack(alignment: .leading) {
                            Text(NSLocalizedString("playback_order", comment: "Playback Order label"))
                            Picker(NSLocalizedString("playback_order", comment: "Playback Order picker"), selection: $settingsManager.playbackOrder) {
                                ForEach(SettingsManager.PlaybackOrder.allCases, id: \.self) { order in
                                    Text(order.displayName).tag(order)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                        }
                    }
                    
                    // Repeat Count
                    HStack {
                        Image(systemName: "repeat")
                            .foregroundColor(.purple)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(NSLocalizedString("repeat_count_per_sentence", comment: "Repeat Count per Sentence label"))
                            Stepper(value: $settingsManager.singleSentenceRepeatCount, in: 1...10) {
                                Text("\(settingsManager.singleSentenceRepeatCount) times")
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    
                    // Speech Rate
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "speedometer")
                                .foregroundColor(.red)
                            Text(NSLocalizedString("speech_rate", comment: "Speech Rate label"))
                            Spacer()
                            Text(String(format: "%.1fx", settingsManager.speechRate))
                                .foregroundColor(.secondary)
                        }
                        
                        Slider(value: $settingsManager.speechRate, in: 0.1...2.0, step: 0.1) {
                            Text(NSLocalizedString("speech_rate", comment: "Speech Rate slider"))
                        } minimumValueLabel: {
                            Text(NSLocalizedString("slow_label", comment: "Slow label"))
                                .font(.caption)
                        } maximumValueLabel: {
                            Text(NSLocalizedString("fast_label", comment: "Fast label"))
                                .font(.caption)
                        }
                    }
                }
                
                // MARK: - Continuous Play Section
                Section(header: Text(NSLocalizedString("continuous_play_section", comment: "Continuous Play Settings section header"))) {
                    HStack {
                        Image(systemName: "play.circle")
                            .foregroundColor(.indigo)
                        Toggle(NSLocalizedString("enable_continuous_play", comment: "Enable Continuous Play toggle"), isOn: $settingsManager.continuousPlayEnabled)
                    }
                    
                    if settingsManager.continuousPlayEnabled {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Image(systemName: "timer")
                                    .foregroundColor(.cyan)
                                Text(NSLocalizedString("pause_between_sentences", comment: "Pause Between Sentences label"))
                                Spacer()
                                Text(String(format: "%.1f s", settingsManager.pauseBetweenSentences))
                                    .foregroundColor(.secondary)
                            }
                            
                            Slider(value: $settingsManager.pauseBetweenSentences, in: 0.0...5.0, step: 0.5) {
                                Text(NSLocalizedString("pause_between_sentences", comment: "Pause Between Sentences slider"))
                            } minimumValueLabel: {
                                Text("0s")
                                    .font(.caption)
                            } maximumValueLabel: {
                                Text("5s")
                                    .font(.caption)
                            }
                        }
                    }
                }
                
                // MARK: - Progress Management Section
                Section(header: Text(NSLocalizedString("progress_management_section", comment: "Progress Management section header"))) {
                    // Clear All Progress
                    Button(action: {
                        clearAlertType = .all
                        showingClearAlert = true
                    }) {
                        HStack {
                            Image(systemName: "trash")
                                .foregroundColor(.red)
                            Text(NSLocalizedString("clear_all_progress", comment: "Clear All Progress button"))
                                .foregroundColor(.red)
                        }
                    }
                    
                    // Reset Settings
                    Button(action: {
                        settingsManager.resetToDefaults()
                    }) {
                        HStack {
                            Image(systemName: "arrow.counterclockwise")
                                .foregroundColor(.orange)
                            Text(NSLocalizedString("reset_to_default_settings", comment: "Reset to Default Settings button"))
                                .foregroundColor(.orange)
                        }
                    }
                }
                
                // MARK: - About Section
                Section(header: Text(NSLocalizedString("about_section", comment: "About section header"))) {
                    HStack {
                        Image(systemName: "info.circle")
                            .foregroundColor(.blue)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(NSLocalizedString("version_info", comment: "Version Info label"))
                            Text(NSLocalizedString("language_study_version", comment: "App version"))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    HStack {
                        Image(systemName: "book")
                            .foregroundColor(.green)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(NSLocalizedString("course_structure", comment: "Course Structure label"))
                            Text(NSLocalizedString("course_structure_detail", comment: "Course structure detail"))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    HStack {
                        Image(systemName: "envelope")
                            .foregroundColor(.orange)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(NSLocalizedString("support_email", comment: "Support Email label"))
                            Text(NSLocalizedString("support_email_address", comment: "Support email address"))
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            .navigationTitle(NSLocalizedString("language_study_title", comment: "Settings navigation title"))
            .navigationBarTitleDisplayMode(.inline)
            .alert(NSLocalizedString("clear_progress_alert_title", comment: "Clear Progress alert title"), isPresented: $showingClearAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Clear", role: .destructive) {
                    switch clearAlertType {
                    case .all:
                        practiceDatabase.clearAllProgress()
                    case .current:
                        // This would require course context
                        break
                    }
                }
            } message: {
                Text(clearAlertType == .all ?
                     NSLocalizedString("clear_all_progress_message", comment: "Clear all progress alert message") :
                     NSLocalizedString("clear_current_progress_message", comment: "Clear current progress alert message"))
            }
        }
    }
}

// MARK: - Preview
struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
            .environment(\.locale, .init(identifier: "zh-Hant")) // Preview in Traditional Chinese
    }
}
