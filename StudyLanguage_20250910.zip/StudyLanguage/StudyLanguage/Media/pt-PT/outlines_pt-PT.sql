BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('pt-PT','Expressões Diárias Básicas',1),
 ('pt-PT','Vida Social e Interesses',2),
 ('pt-PT','Casa e Vida Quotidiana',3),
 ('pt-PT','Estudo e Trabalho',4),
 ('pt-PT','Viagens e Cultura',5),
 ('pt-PT','Comunicação Avançada',6),
 ('pt-PT','Sociedade e Notícias',7),
 ('pt-PT','Pensamento Avançado',8),
 ('pt-PT','Linguagem Profissional',9),
 ('pt-PT','Aplicação Integrada',10);

COMMIT;
