BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('fi-FI','Perustavat Päivittäiset Ilmaisut',1),
 ('fi-FI','Sosiaalinen Elämä ja Kiinnostuksen Kohteet',2),
 ('fi-FI','Koti ja Arkipäivän Elämä',3),
 ('fi-FI','Opiskelu ja Työ',4),
 ('fi-FI','Matkailu ja Kulttuuri',5),
 ('fi-FI','Edistynyt Viestintä',6),
 ('fi-FI','Yhteiskunta ja Uutiset',7),
 ('fi-FI','Edistynyt Ajattelu',8),
 ('fi-FI','Ammatillinen Kieli',9),
 ('fi-FI','Integroitu Soveltaminen',10);

COMMIT;
