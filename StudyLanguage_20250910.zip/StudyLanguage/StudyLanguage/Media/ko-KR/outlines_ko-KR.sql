BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('ko-KR','기초 일상 표현',1),
 ('ko-KR','사회 생활과 관심사',2),
 ('ko-KR','가정과 일상 생활',3),
 ('ko-KR','학업과 일',4),
 ('ko-KR','여행과 문화',5),
 ('ko-KR','고급 의사소통',6),
 ('ko-KR','사회와 뉴스',7),
 ('ko-KR','심화 사고',8),
 ('ko-KR','전문 언어',9),
 ('ko-KR','통합 활용',10);

COMMIT;
