BEGIN TRANSACTION;

DELETE FROM "outlines"
WHERE "lang_code" = 'th-TH';

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES
 ('th-TH','สำนวนพื้นฐานในชีวิตประจำวัน',1),
 ('th-TH','ชีวิตทางสังคมและความสนใจ',2),
 ('th-TH','บ้านและชีวิตประจำวัน',3),
 ('th-TH','การเรียนและการทำงาน',4),
 ('th-TH','การท่องเที่ยวและวัฒนธรรม',5),
 ('th-TH','การสื่อสารขั้นสูง',6),
 ('th-TH','สังคมและข่าวสาร',7),
 ('th-TH','การคิดขั้นสูง',8),
 ('th-TH','ภาษามืออาชีพ',9),
 ('th-TH','การประยุกต์ใช้อย่างบูรณาการ',10);

COMMIT;
