BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('fr-FR','Expressions Quotidiennes de Base',1),
 ('fr-FR','Vie Sociale et Centres d’Intérêt',2),
 ('fr-FR','Maison et Vie Quotidienne',3),
 ('fr-FR','Études et Travail',4),
 ('fr-FR','Voyages et Culture',5),
 ('fr-FR','Communication Avancée',6),
 ('fr-FR','Société et Actualités',7),
 ('fr-FR','Réflexion Avancée',8),
 ('fr-FR','Langage Professionnel',9),
 ('fr-FR','Application Intégrée',10);

COMMIT;
