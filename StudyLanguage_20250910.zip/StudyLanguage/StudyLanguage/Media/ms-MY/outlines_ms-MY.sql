BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('ms-MY','Ungkapan Harian Asas',1),
 ('ms-MY','Kehidupan Sosial dan Minat',2),
 ('ms-MY','Rumah dan Kehidupan Harian',3),
 ('ms-MY','Pembelajaran dan Pekerjaan',4),
 ('ms-MY','Perjalanan dan Budaya',5),
 ('ms-MY','Komunikasi Lanjutan',6),
 ('ms-MY','Masyarakat dan Berita',7),
 ('ms-MY','Pemikiran Lanjutan',8),
 ('ms-MY','Bahasa Profesional',9),
 ('ms-MY','Aplikasi Bersepadu',10);

COMMIT;
