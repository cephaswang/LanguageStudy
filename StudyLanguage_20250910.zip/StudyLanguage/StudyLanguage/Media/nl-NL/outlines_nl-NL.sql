BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('nl-NL','Basis Dagelijkse Uitdrukkingen',1),
 ('nl-NL','Sociaal Leven en Interesses',2),
 ('nl-NL','Huis en Dagelijks Leven',3),
 ('nl-NL','Studie en Werk',4),
 ('nl-NL','Reizen en Cultuur',5),
 ('nl-NL','Gevorderde Communicatie',6),
 ('nl-NL','Samenleving en Nieuws',7),
 ('nl-NL','Gevorderd Denken',8),
 ('nl-NL','Professionele Taal',9),
 ('nl-NL','Geïntegreerde Toepassing',10);

COMMIT;
