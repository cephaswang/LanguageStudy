BEGIN TRANSACTION;
INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES
 ('zh-CN','基础生活用语',1),
 ('zh-CN','社交与兴趣',2),
 ('zh-CN','家庭与生活',3),
 ('zh-CN','学习与工作',4),
 ('zh-CN','旅行与文化',5),
 ('zh-CN','进阶交流',6),
 ('zh-CN','社会与新闻',7),
 ('zh-CN','高阶思考',8),
 ('zh-CN','专业语言',9),
 ('zh-CN','综合应用',10);
COMMIT;
