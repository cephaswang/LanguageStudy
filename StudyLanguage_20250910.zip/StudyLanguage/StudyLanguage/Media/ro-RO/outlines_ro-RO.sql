BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('ro-RO','Expresii Zilnice de Bază',1),
 ('ro-RO','Viață Socială și Interese',2),
 ('ro-RO','Acasă și Viața Cotidiană',3),
 ('ro-RO','Studii și Muncă',4),
 ('ro-RO','Călătorii și Cultură',5),
 ('ro-RO','Comunicare Avansată',6),
 ('ro-RO','Societate și Știri',7),
 ('ro-RO','Gândire Avansată',8),
 ('ro-RO','Limbaj Profesional',9),
 ('ro-RO','Aplicație Integrată',10);

COMMIT;
