BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('hu-HU','Alapvető Napi Kifejezések',1),
 ('hu-HU','Társas Élet és Érdeklődési Körök',2),
 ('hu-HU','Otthon és Mindennapi Élet',3),
 ('hu-HU','Tanulás és Munka',4),
 ('hu-HU','Utazás és Kultúra',5),
 ('hu-HU','Haladó Kommunikáció',6),
 ('hu-HU','Társadalom és Hírek',7),
 ('hu-HU','Haladó Gondolkodás',8),
 ('hu-HU','Szakmai Nyelv',9),
 ('hu-HU','Integrált Alkalmazás',10);

COMMIT;
