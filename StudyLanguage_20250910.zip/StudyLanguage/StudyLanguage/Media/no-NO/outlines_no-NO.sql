BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('no-NO','Grunnleggende Daglige Uttrykk',1),
 ('no-NO','Sosialt Liv og Interesser',2),
 ('no-NO','Hjem og Dagligliv',3),
 ('no-NO','Studier og Arbeid',4),
 ('no-NO','Reiser og Kultur',5),
 ('no-NO','Avansert Kommunikasjon',6),
 ('no-NO','Samfunn og Nyheter',7),
 ('no-NO','Avansert Tenkning',8),
 ('no-NO','Profesjonelt Språk',9),
 ('no-NO','Integrert Anvendelse',10);

COMMIT;
