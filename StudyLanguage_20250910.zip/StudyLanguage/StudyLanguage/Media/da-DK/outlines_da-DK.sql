BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('da-DK','Grundlæggende Daglige Udtryk',1),
 ('da-DK','Socialt Liv og Interesser',2),
 ('da-DK','Hjem og Dagligliv',3),
 ('da-DK','Studier og Arbejde',4),
 ('da-DK','Rejser og Kultur',5),
 ('da-DK','Avanceret Kommunikation',6),
 ('da-DK','Samfund og Nyheder',7),
 ('da-DK','Avanceret Tænkning',8),
 ('da-DK','Fagligt Sprog',9),
 ('da-DK','Integreret Anvendelse',10);

COMMIT;
