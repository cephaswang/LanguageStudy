BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('sv-SE','Grundläggande Dagliga Uttryck',1),
 ('sv-SE','Socialt Liv och Intressen',2),
 ('sv-SE','Hem och Dagligt Liv',3),
 ('sv-SE','Studier och Arbete',4),
 ('sv-SE','Resor och Kultur',5),
 ('sv-SE','Avancerad Kommunikation',6),
 ('sv-SE','Samhälle och Nyheter',7),
 ('sv-SE','Avancerat Tänkande',8),
 ('sv-SE','Professionellt Språk',9),
 ('sv-SE','Integrerad Tillämpning',10);

COMMIT;
