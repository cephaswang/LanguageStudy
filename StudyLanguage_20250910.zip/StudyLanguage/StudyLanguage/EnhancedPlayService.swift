import Foundation
import AVFoundation
import os.log
import Combine

class EnhancedPlayService: NSObject, ObservableObject {
    // MARK: - Published Properties
    @Published var isPlaying = false
    @Published var isPaused = false
    @Published var currentPlayingLessonId: Int?
    @Published var playbackProgress: Double = 0.0
    @Published var voiceAvailabilityError: String?
    @Published var currentPlayingText: String = ""

    // MARK: - Private Properties
    private let speechSynthesizer = AVSpeechSynthesizer()
    private let logger = Logger(subsystem: "org.share35app.BibleTTS", category: "EnhancedPlayService")
    private var settingsManager: SettingsManager
    private var practiceDatabase: PracticeDatabase

    // Playback queue management
    private var playbackQueue: [PlaybackItem] = []
    private var currentQueueIndex = 0
    private var currentRepeatCount = 0
    private var isContinuousPlayback = false

    // Combine subscriptions
    private var cancellables = Set<AnyCancellable>()

    struct PlaybackItem {
        let text: String
        let language: String // BCP-47 like "en-US", "zh-TW"
        let lessonId: Int
        let voice: AVSpeechSynthesisVoice?
        let isTarget: Bool
    }

    // MARK: - Initialization
    init(settingsManager: SettingsManager, practiceDatabase: PracticeDatabase) {
        self.settingsManager = settingsManager
        self.practiceDatabase = practiceDatabase
        super.init()

        initializeTextToSpeech()
        setupSettingsObservers()
    }

    private func initializeTextToSpeech() {
        speechSynthesizer.delegate = self
        configureAudioSession()
        logger.info("Enhanced TTS Service initialized")
    }

    private func configureAudioSession() {
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playback, mode: .spokenAudio, options: [.mixWithOthers])
            try audioSession.setActive(true)
            logger.info("AVAudioSession configured for background playback")
        } catch {
            logger.error("Failed to configure AVAudioSession: \(error.localizedDescription)")
        }
    }

    private func setupSettingsObservers() {
        settingsManager.$speechRate
            .sink { [weak self] _ in
                // Speech rate will be applied to individual utterances
                self?.logger.debug("speechRate updated; will apply on next utterance")
            }
            .store(in: &cancellables)
    }

    // MARK: - Single Sentence Playback
    /// Plays one sentence pair (target/native) based on settings. Languages are taken from parameters.
    func playSingleSentence(
        lessonId: Int,
        targetText: String,
        nativeText: String,
        courseOrder: Int,
        targetLang: String,
        nativeLang: String
    ) {
        guard !isPlaying else {
            logger.warning("Already playing, ignoring request")
            return
        }

        logger.info("""
                ▶️ playSingleSentence called with params:
                lessonId=\(lessonId),
                targetText=\(targetText),
                nativeText=\(nativeText),
                courseOrder=\(courseOrder),
                targetLang=\(targetLang),
                nativeLang=\(nativeLang)
                """)

        currentPlayingLessonId = lessonId
        playbackQueue.removeAll()
        currentQueueIndex = 0
        currentRepeatCount = 0
        isContinuousPlayback = false

        // Build playback queue based on settings (USE PASSED-IN LANGS)
        buildSingleSentenceQueue(
            lessonId: lessonId,
            targetText: targetText,
            nativeText: nativeText,
            targetLang: targetLang,
            nativeLang: nativeLang
        )

        if !playbackQueue.isEmpty {
            startPlayback()

            // Update practice database
            practiceDatabase.updateProgress(
                lessonId: lessonId,
                courseOrder: courseOrder,
                targetLang: targetLang,
                nativeLang: nativeLang,
                isCompleted: false
            )
            logger.info("Progress updated for lesson \(lessonId)")
        }
    }

    private func buildSingleSentenceQueue(
        lessonId: Int,
        targetText: String,
        nativeText: String,
        targetLang: String,
        nativeLang: String
    ) {
        let targetVoice = AVSpeechSynthesisVoice(language: targetLang)
        let nativeVoice = AVSpeechSynthesisVoice(language: nativeLang)

        if targetVoice == nil {
            logger.error("Target language voice not available: \(targetLang)")
            voiceAvailabilityError = "目標語言語音不可用，請檢查系統設定"
        }
        if nativeVoice == nil {
            logger.error("Native language voice not available: \(nativeLang)")
            voiceAvailabilityError = "母語語音不可用，請檢查系統設定"
        }

        for _ in 0..<settingsManager.singleSentenceRepeatCount {
            switch settingsManager.playbackOrder {
            case .targetFirst:
                if settingsManager.shouldPlayTargetLanguage() {
                    playbackQueue.append(PlaybackItem(text: targetText, language: targetLang, lessonId: lessonId, voice: targetVoice, isTarget: true))
                }
                if settingsManager.shouldPlayNativeLanguage() {
                    playbackQueue.append(PlaybackItem(text: nativeText, language: nativeLang, lessonId: lessonId, voice: nativeVoice, isTarget: false))
                }

            case .nativeFirst:
                if settingsManager.shouldPlayNativeLanguage() {
                    playbackQueue.append(PlaybackItem(text: nativeText, language: nativeLang, lessonId: lessonId, voice: nativeVoice, isTarget: false))
                }
                if settingsManager.shouldPlayTargetLanguage() {
                    playbackQueue.append(PlaybackItem(text: targetText, language: targetLang, lessonId: lessonId, voice: targetVoice, isTarget: true))
                }

            case .targetOnly:
                if settingsManager.shouldPlayTargetLanguage() {
                    playbackQueue.append(PlaybackItem(text: targetText, language: targetLang, lessonId: lessonId, voice: targetVoice, isTarget: true))
                }

            case .nativeOnly:
                if settingsManager.shouldPlayNativeLanguage() {
                    playbackQueue.append(PlaybackItem(text: nativeText, language: nativeLang, lessonId: lessonId, voice: nativeVoice, isTarget: false))
                }
            }
        }
    }

    // MARK: - Continuous Playback
    func startContinuousPlayback(
        fromLessonId: Int,
        lessons: [Lesson],
        courseOrder: Int,
        targetLang: String,
        nativeLang: String
    ) {
        guard !isPlaying else { return }

        // Find starting index
        guard let startIndex = lessons.firstIndex(where: { $0.id == fromLessonId }) else {
            logger.error("Cannot find lesson with ID \(fromLessonId)")
            return
        }

        currentPlayingLessonId = fromLessonId
        playbackQueue.removeAll()
        currentQueueIndex = 0
        isContinuousPlayback = true

        // Build continuous playback queue with PASSED-IN LANGS
        buildContinuousQueue(lessons: Array(lessons[startIndex...]), targetLang: targetLang, nativeLang: nativeLang)

        if !playbackQueue.isEmpty {
            startPlayback()
        }
    }

    private func buildContinuousQueue(lessons: [Lesson], targetLang: String, nativeLang: String) {
        let targetVoice = AVSpeechSynthesisVoice(language: targetLang)
        let nativeVoice = AVSpeechSynthesisVoice(language: nativeLang)

        if targetVoice == nil {
            logger.error("Target language voice not available: \(targetLang)")
            voiceAvailabilityError = "目標語言語音不可用，請檢查系統設定"
        }
        if nativeVoice == nil {
            logger.error("Native language voice not available: \(nativeLang)")
            voiceAvailabilityError = "母語語音不可用，請檢查系統設定"
        }

        for lesson in lessons {
            for _ in 0..<settingsManager.singleSentenceRepeatCount {
                switch settingsManager.playbackOrder {
                case .targetFirst:
                    if settingsManager.shouldPlayTargetLanguage() {
                        playbackQueue.append(PlaybackItem(text: lesson.targetText, language: targetLang, lessonId: lesson.id, voice: targetVoice, isTarget: true))
                    }
                    if settingsManager.shouldPlayNativeLanguage() {
                        playbackQueue.append(PlaybackItem(text: lesson.nativeText, language: nativeLang, lessonId: lesson.id, voice: nativeVoice, isTarget: false))
                    }

                case .nativeFirst:
                    if settingsManager.shouldPlayNativeLanguage() {
                        playbackQueue.append(PlaybackItem(text: lesson.nativeText, language: nativeLang, lessonId: lesson.id, voice: nativeVoice, isTarget: false))
                    }
                    if settingsManager.shouldPlayTargetLanguage() {
                        playbackQueue.append(PlaybackItem(text: lesson.targetText, language: targetLang, lessonId: lesson.id, voice: targetVoice, isTarget: true))
                    }

                case .targetOnly:
                    if settingsManager.shouldPlayTargetLanguage() {
                        playbackQueue.append(PlaybackItem(text: lesson.targetText, language: targetLang, lessonId: lesson.id, voice: targetVoice, isTarget: true))
                    }

                case .nativeOnly:
                    if settingsManager.shouldPlayNativeLanguage() {
                        playbackQueue.append(PlaybackItem(text: lesson.nativeText, language: nativeLang, lessonId: lesson.id, voice: nativeVoice, isTarget: false))
                    }
                }
            }
        }
    }

    // MARK: - Playback Control
    private func startPlayback() {
        guard currentQueueIndex < playbackQueue.count else {
            finishPlayback()
            return
        }

        isPlaying = true
        let item = playbackQueue[currentQueueIndex]
        currentPlayingLessonId = item.lessonId
        currentPlayingText = item.text

        let utterance = AVSpeechUtterance(string: item.text)
        utterance.rate = settingsManager.speechRate
        // Prefer the provided AVSpeechSynthesisVoice; fall back to the language code, then to en-US
        if let v = item.voice {
            utterance.voice = v
        } else if let langVoice = AVSpeechSynthesisVoice(language: item.language) {
            utterance.voice = langVoice
        } else {
            utterance.voice = AVSpeechSynthesisVoice(language: "en-US")
        }

        logger.info("Playing: \(item.text) (Lesson: \(item.lessonId), Language: \(item.language))")
        speechSynthesizer.speak(utterance)
    }

    private func playNextInQueue() {
        currentQueueIndex += 1
        updateProgress()

        if currentQueueIndex < playbackQueue.count {
            // Add pause between sentences if in continuous mode
            if isContinuousPlayback && settingsManager.pauseBetweenSentences > 0 {
                DispatchQueue.main.asyncAfter(deadline: .now() + settingsManager.pauseBetweenSentences) { [weak self] in
                    self?.startPlayback()
                }
            } else {
                startPlayback()
            }
        } else {
            finishPlayback()
        }
    }

    private func finishPlayback() {
        isPlaying = false
        isPaused = false
        currentPlayingLessonId = nil
        currentPlayingText = ""
        playbackQueue.removeAll()
        currentQueueIndex = 0
        isContinuousPlayback = false
        playbackProgress = 1.0
        logger.info("Playback completed")
    }

    func stopPlayback() {
        if isPlaying || isPaused {
            speechSynthesizer.stopSpeaking(at: .immediate)
            finishPlayback()
            logger.info("Playback stopped")
        }
    }

    func pauseResume() {
        if isPlaying {
            speechSynthesizer.pauseSpeaking(at: .word)
            isPlaying = false
            isPaused = true
            logger.info("Playback paused")
        } else if isPaused {
            speechSynthesizer.continueSpeaking()
            isPlaying = true
            isPaused = false
            logger.info("Playback resumed")
        }
    }

    // MARK: - Progress Calculation
    private func updateProgress() {
        guard !playbackQueue.isEmpty else {
            playbackProgress = 0.0
            return
        }
        playbackProgress = Double(currentQueueIndex) / Double(playbackQueue.count)
    }

    // MARK: - Voice Utilities
    func refreshVoices() {
        // Kept for API compatibility; in the dynamic setup we resolve per-request
        logger.debug("refreshVoices called – voices are resolved dynamically per request")
    }

    func getAvailableVoices(for language: String) -> [AVSpeechSynthesisVoice] {
        // Show voices whose language starts with the same language code (e.g., "en")
        let prefix = String(language.prefix(2))
        return AVSpeechSynthesisVoice.speechVoices().filter { $0.language.hasPrefix(prefix) }
    }

    // MARK: - Cleanup
    deinit {
        speechSynthesizer.stopSpeaking(at: .immediate)
        cancellables.removeAll()
        logger.info("EnhancedPlayService deinitialized")
    }
}

// MARK: - AVSpeechSynthesizerDelegate
extension EnhancedPlayService: AVSpeechSynthesizerDelegate {
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didStart utterance: AVSpeechUtterance) {
        logger.info("Started speaking: \(utterance.speechString.prefix(50))...")
        updateProgress()
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        logger.info("Finished speaking: \(utterance.speechString.prefix(50))...")
        playNextInQueue()
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        logger.info("Cancelled speaking: \(utterance.speechString.prefix(50))...")
        finishPlayback()
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didPause utterance: AVSpeechUtterance) {
        logger.info("Paused speaking")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didContinue utterance: AVSpeechUtterance) {
        logger.info("Continued speaking")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        // Update current speaking position for visual feedback
        let speechString = utterance.speechString
        
        // Validate the range bounds to prevent crashes
        guard characterRange.location >= 0,
              characterRange.location < speechString.count else {
            // If the range is invalid, just use the full text
            DispatchQueue.main.async { [weak self] in
                self?.currentPlayingText = speechString
            }
            return
        }
        
        // Safe index calculation with bounds checking
        let startIndex = speechString.index(speechString.startIndex, offsetBy: characterRange.location)
        
        // Additional safety check for the end range
        let maxLength = speechString.distance(from: startIndex, to: speechString.endIndex)
        let safeLength = min(characterRange.length, maxLength)
        
        let endIndex = speechString.index(startIndex, offsetBy: safeLength)
        let currentText = String(speechString[startIndex..<endIndex])
        
        DispatchQueue.main.async { [weak self] in
            self?.currentPlayingText = currentText.isEmpty ? speechString : currentText
        }
    }
    /*
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, willSpeakRangeOfSpeechString characterRange: NSRange, utterance: AVSpeechUtterance) {
        // Update current speaking position for visual feedback
        let start = utterance.speechString.index(utterance.speechString.startIndex, offsetBy: characterRange.location)
        let currentText = String(utterance.speechString[start...])
        DispatchQueue.main.async { [weak self] in
            self?.currentPlayingText = currentText
        }
    }*/
}

