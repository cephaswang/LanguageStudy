import SwiftUI

// 大綱資料模型
struct Outline: Identifiable {
    let id = UUID()
    let sortOrder: Int
    let targetLanguageText: String
    let nativeLanguageText: String
}

// 主要的 OutlineView
struct OutlineView: View {
    let targetLanguage: String
    let nativeLanguage: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    @StateObject private var databaseManager = DatabaseManager()
    @State private var outlines: [Outline] = []
    @State private var isLoading = true
    @State private var showError = false
    @State private var debugInfo = ""
    
    // 添加環境變量來處理頁面關閉
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack {
                if isLoading {
                    VStack(spacing: 16) {
                        ProgressView()
                            .scaleEffect(1.2)
                        Text("載入學習大綱中...")
                            .font(.custom(nativeLanguageFontName, size: 16))
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if outlines.isEmpty {
                    VStack(spacing: 20) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .font(.system(size: 50))
                            .foregroundColor(.orange)
                        
                        VStack(spacing: 8) {
                            Text("無法載入學習大綱")
                                .font(.custom(nativeLanguageFontName, size: 20))
                                .fontWeight(.semibold)
                            
                            Text("請檢查資料庫連接")
                                .font(.custom(nativeLanguageFontName, size: 16))
                                .foregroundColor(.secondary)
                        }
                        
                        if !debugInfo.isEmpty {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("除錯資訊:")
                                    .font(.custom(nativeLanguageFontName, size: 12))
                                    .fontWeight(.semibold)
                                Text(debugInfo)
                                    .font(.custom(nativeLanguageFontName, size: 12))
                                    .foregroundColor(.secondary)
                                    .padding(.horizontal)
                            }
                            .padding()
                            .background(Color.gray.opacity(0.1))
                            .cornerRadius(8)
                        }
                        
                        Button("重新載入") {
                            loadOutlines()
                        }
                        .padding(.horizontal, 20)
                        .padding(.vertical, 10)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .font(.custom(nativeLanguageFontName, size: 16))
                        .cornerRadius(8)
                    }
                    .padding()
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    List(outlines) { outline in
                        NavigationLink(
                            destination: TopicView(
                                sortOrder: outline.sortOrder,
                                targetLanguage: targetLanguage,
                                nativeLanguage: nativeLanguage,
                                targetOutline: outline.targetLanguageText,  // 新增
                                nativeOutline: outline.nativeLanguageText,  // 新增
                                targetLanguageFontName: targetLanguageFontName,
                                nativeLanguageFontName: nativeLanguageFontName
                            )
                        ) {
                            OutlineRowView(
                                outline: outline,
                                targetLanguage: targetLanguage,
                                nativeLanguage: nativeLanguage,
                                targetLanguageFontName: targetLanguageFontName,
                                nativeLanguageFontName: nativeLanguageFontName
                            )
                        }
                    }
                    .listStyle(PlainListStyle())
                    .refreshable {
                        loadOutlines()
                    }
                }
            }
            .navigationTitle(NSLocalizedString("language_study_title", comment: "App title"))
            .navigationBarTitleDisplayMode(.large)
            // 添加返回按鈕到導航欄
            .navigationBarBackButtonHidden(true)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button(action: {
                        dismiss()
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "chevron.left")
                                .font(.system(size: 16, weight: .medium))
                            Text("Back")
                                .font(.custom(nativeLanguageFontName, size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                }
            }
            .onAppear {
                loadOutlines()
            }
            .alert("載入錯誤", isPresented: $showError) {
                Button("確定") { }
                Button("重試") {
                    loadOutlines()
                }
            } message: {
                Text(databaseManager.error?.localizedDescription ?? "未知錯誤")
                    .font(.custom(nativeLanguageFontName, size: 14))
            }
            .onReceive(databaseManager.$error) { error in
                showError = error != nil
                if let error = error {
                    debugInfo = "錯誤: \(error.localizedDescription)"
                }
            }
        }
    }
    
    private func loadOutlines() {
        print("🚀 開始載入大綱資料...")
        isLoading = true
        debugInfo = "目標語言: \(targetLanguage), 母語: \(nativeLanguage)"
        
        databaseManager.error = nil
        
        DispatchQueue.global(qos: .userInitiated).async {
            let fetchedOutlines = self.databaseManager.fetchOutlines(
                targetLanguage: self.targetLanguage,
                nativeLanguage: self.nativeLanguage
            )
            
            DispatchQueue.main.async {
                self.outlines = fetchedOutlines
                self.isLoading = false
                
                if fetchedOutlines.isEmpty {
                    self.debugInfo += "\n查詢結果為空"
                    print("⚠️ 大綱載入完成，但沒有找到資料")
                } else {
                    self.debugInfo = ""
                    print("✅ 成功載入 \(fetchedOutlines.count) 個大綱項目")
                }
            }
        }
    }
}

// 大綱列表項目視圖
struct OutlineRowView: View {
    let outline: Outline
    let targetLanguage: String
    let nativeLanguage: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.blue)
                    .frame(width: 42, height: 42)
                
                Text("\(outline.sortOrder)")
                    .foregroundColor(.white)
                    .font(.system(size: 16, weight: .semibold))
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text(outline.targetLanguageText)
                    .font(.custom(targetLanguageFontName, size: 18))
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
                
                Text(outline.nativeLanguageText)
                    .font(.custom(nativeLanguageFontName, size: 14))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.leading)
                    .lineLimit(2)
            }
            
            Spacer()
            
        }
        .padding(.vertical, 12)
        .contentShape(Rectangle())
    }
}

#Preview {
    OutlineView(
        targetLanguage: "en",
        nativeLanguage: "zh_TW",
        targetLanguageFontName: "Helvetica",
        nativeLanguageFontName: "PingFangTC-Regular"
    )
}
