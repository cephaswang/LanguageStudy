import SwiftUI

struct LanguageSelectionView: View {
    @State private var searchText = ""
    @State private var selectedTargetLanguage = ""
    @State private var selectedNativeLanguage = ""
    @State private var showOutlineView = false
    
    // iOS 實際支援的 AVSpeechSynthesisVoice 語言列表（按英文排序）
    // 基於 iOS 設備上的真實 TTS 語音支援
    let languageOptions = [
        LanguageOption(code: "ar-SA", englishName: "Arabic (Saudi Arabia)", chineseName: "阿拉伯語", flagEmoji: "🇸🇦"),
        LanguageOption(code: "cs-CZ", englishName: "Czech", chineseName: "捷克語", flagEmoji: "🇨🇿"),
        LanguageOption(code: "da-DK", englishName: "Danish", chineseName: "丹麥語", flagEmoji: "🇩🇰"),
        LanguageOption(code: "de-DE", englishName: "German", chineseName: "德語", flagEmoji: "🇩🇪"),
        LanguageOption(code: "el-GR", englishName: "Greek", chineseName: "希臘語", flagEmoji: "🇬🇷"),
        //LanguageOption(code: "en-AU", englishName: "English (Australia)", chineseName: "英語（澳洲）", flagEmoji: "🇦🇺"),
        //LanguageOption(code: "en-GB", englishName: "English (UK)", chineseName: "英語（英國）", flagEmoji: "🇬🇧"),
        //LanguageOption(code: "en-IE", englishName: "English (Ireland)", chineseName: "英語（愛爾蘭）", flagEmoji: "🇮🇪"),
        //LanguageOption(code: "en-IN", englishName: "English (India)", chineseName: "英語（印度）", flagEmoji: "🇮🇳"),
        LanguageOption(code: "en-US", englishName: "English (US)", chineseName: "英語（美國）", flagEmoji: "🇺🇸"),
        //LanguageOption(code: "en-ZA", englishName: "English (South Africa)", chineseName: "英語（南非）", flagEmoji: "🇿🇦"),
        LanguageOption(code: "es-ES", englishName: "Spanish (Spain)", chineseName: "西班牙語", flagEmoji: "🇪🇸"),
        //LanguageOption(code: "es-MX", englishName: "Spanish (Mexico)", chineseName: "西班牙語（墨西哥）", flagEmoji: "🇲🇽"),
        LanguageOption(code: "fi-FI", englishName: "Finnish", chineseName: "芬蘭語", flagEmoji: "🇫🇮"),
        //LanguageOption(code: "fr-CA", englishName: "French (Canada)", chineseName: "法語（加拿大）", flagEmoji: "🇨🇦"),
        LanguageOption(code: "fr-FR", englishName: "French (France)", chineseName: "法語（法國）", flagEmoji: "🇫🇷"),
        LanguageOption(code: "he-IL", englishName: "Hebrew", chineseName: "希伯來語", flagEmoji: "🇮🇱"),
        LanguageOption(code: "hi-IN", englishName: "Hindi", chineseName: "印地語", flagEmoji: "🇮🇳"),
        LanguageOption(code: "hu-HU", englishName: "Hungarian", chineseName: "匈牙利語", flagEmoji: "🇭🇺"),
        LanguageOption(code: "id-ID", englishName: "Indonesian", chineseName: "印尼語", flagEmoji: "🇮🇩"),
        LanguageOption(code: "it-IT", englishName: "Italian", chineseName: "義大利語", flagEmoji: "🇮🇹"),
        LanguageOption(code: "ja-JP", englishName: "Japanese", chineseName: "日語", flagEmoji: "🇯🇵"),
        LanguageOption(code: "ko-KR", englishName: "Korean", chineseName: "韓語", flagEmoji: "🇰🇷"),
        //LanguageOption(code: "nl-BE", englishName: "Dutch (Belgium)", chineseName: "荷蘭語（比利時）", flagEmoji: "🇧🇪"),
        LanguageOption(code: "nl-NL", englishName: "Dutch (Netherlands)", chineseName: "荷蘭語", flagEmoji: "🇳🇱"),
        LanguageOption(code: "no-NO", englishName: "Norwegian", chineseName: "挪威語", flagEmoji: "🇳🇴"),
        LanguageOption(code: "pl-PL", englishName: "Polish", chineseName: "波蘭語", flagEmoji: "🇵🇱"),
        //LanguageOption(code: "pt-BR", englishName: "Portuguese (Brazil)", chineseName: "葡萄牙語（巴西）", flagEmoji: "🇧🇷"),
        LanguageOption(code: "pt-PT", englishName: "Portuguese (Portugal)", chineseName: "葡萄牙語（葡萄牙）", flagEmoji: "🇵🇹"),
        LanguageOption(code: "ro-RO", englishName: "Romanian", chineseName: "羅馬尼亞語", flagEmoji: "🇷🇴"),
        LanguageOption(code: "ru-RU", englishName: "Russian", chineseName: "俄語", flagEmoji: "🇷🇺"),
        LanguageOption(code: "sk-SK", englishName: "Slovak", chineseName: "斯洛伐克語", flagEmoji: "🇸🇰"),
        LanguageOption(code: "sv-SE", englishName: "Swedish", chineseName: "瑞典語", flagEmoji: "🇸🇪"),
        LanguageOption(code: "th-TH", englishName: "Thai", chineseName: "泰語", flagEmoji: "🇹🇭"),
        LanguageOption(code: "tr-TR", englishName: "Turkish", chineseName: "土耳其語", flagEmoji: "🇹🇷"),
        LanguageOption(code: "uk-UA", englishName: "Ukrainian", chineseName: "烏克蘭語", flagEmoji: "🇺🇦"),
        LanguageOption(code: "zh-CN", englishName: "Chinese (Simplified)", chineseName: "簡體中文", flagEmoji: "🇨🇳"),
        LanguageOption(code: "zh-HK", englishName: "Chinese (Hong Kong)", chineseName: "中文（香港）", flagEmoji: "🇭🇰"),
        LanguageOption(code: "zh-TW", englishName: "Chinese (Traditional)", chineseName: "繁體中文", flagEmoji: "🇹🇼")
    ]
    
    var filteredLanguages: [LanguageOption] {
        if searchText.isEmpty {
            return languageOptions
        } else {
            return languageOptions.filter { language in
                language.englishName.localizedCaseInsensitiveContains(searchText) ||
                language.chineseName.localizedCaseInsensitiveContains(searchText)
            }
        }
    }
    
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ZStack {
                    // 藍天白雲背景
                    LinearGradient(
                        gradient: Gradient(colors: [
                            Color(red: 0.6, green: 0.8, blue: 1.0),
                            Color(red: 0.8, green: 0.9, blue: 1.0)
                        ]),
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .ignoresSafeArea()
                    
                    // 白雲效果
                    ForEach(0..<8, id: \.self) { i in
                        Circle()
                            .fill(Color.white.opacity(0.3))
                            .frame(width: CGFloat.random(in: 60...120))
                            .position(
                                x: CGFloat.random(in: 0...geometry.size.width),
                                y: CGFloat.random(in: 0...geometry.size.height/2)
                            )
                    }
                    
                    VStack(spacing: 24) {
                        // 標題
                        Text("Language Study")
                            .font(.largeTitle)
                            .fontWeight(.bold)
                            .foregroundColor(.black)
                            .padding(.top, 20)
                        
                        // 搜尋框
                        SearchBar(text: $searchText)
                            .padding(.horizontal)
                        
                        ScrollView {
                            VStack(spacing: 30) {
                                // 目標語言選擇
                                LanguageSelectionSection(
                                    title: "Target language (language to be learned)",
                                    selectedLanguage: $selectedTargetLanguage,
                                    languages: filteredLanguages,
                                    cardWidth: geometry.size.width * 0.5
                                )
                                
                                // 母語選擇
                                LanguageSelectionSection(
                                    title: "Native language (your language)",
                                    selectedLanguage: $selectedNativeLanguage,
                                    languages: filteredLanguages,
                                    cardWidth: geometry.size.width * 0.5
                                )
                                
                                // 開始學習按鈕
                                if !selectedTargetLanguage.isEmpty && !selectedNativeLanguage.isEmpty {
                                    Button(action: {
                                        // 儲存選擇到 UserDefaults
                                        UserDefaults.standard.set(selectedTargetLanguage, forKey: "selectedTargetLanguage")
                                        UserDefaults.standard.set(selectedNativeLanguage, forKey: "selectedNativeLanguage")
                                        showOutlineView = true
                                    }) {
                                        HStack {
                                            Image(systemName: "play.fill")
                                            Text("Start learning")
                                        }
                                        .font(.title2)
                                        .foregroundColor(.white)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(
                                            LinearGradient(
                                                gradient: Gradient(colors: [Color.blue, Color.purple]),
                                                startPoint: .leading,
                                                endPoint: .trailing
                                            )
                                        )
                                        .cornerRadius(15)
                                        .shadow(radius: 5)
                                    }
                                    .padding(.horizontal)
                                    .padding(.top, 10)
                                }
                            }
                            .padding(.bottom, 20)
                        }
                    }
                }
            }
            .navigationBarHidden(true)
            .onAppear {
                // 載入已儲存的選擇
                selectedTargetLanguage = UserDefaults.standard.string(forKey: "selectedTargetLanguage") ?? ""
                selectedNativeLanguage = UserDefaults.standard.string(forKey: "selectedNativeLanguage") ?? ""
            }
        }
        .fullScreenCover(isPresented: $showOutlineView) {
            OutlineView(
                targetLanguage: selectedTargetLanguage,
                nativeLanguage: selectedNativeLanguage,
                targetLanguageFontName: getFontName(for: selectedTargetLanguage),
                nativeLanguageFontName: getFontName(for: selectedNativeLanguage)
            )
        }
    }
    
    // 根據語言代碼獲取適合的字體名稱（針對實際支援的 TTS 語言）
    func getFontName(for languageCode: String) -> String {
        switch languageCode {
        // 中文字體（簡體、繁體、香港）
        case "zh-CN", "zh-TW", "zh-HK":
            return "PingFangTC-Regular"
        
        // 日文字體
        case "ja-JP":
            return "HiraginoSans-W3"
        
        // 韓文字體
        case "ko-KR":
            return "AppleSDGothicNeo-Regular"
        
        // 阿拉伯語系字體（阿拉伯語、希伯來語）
        case "ar-SA", "he-IL":
            return "GeezaPro"
        
        // 印地語字體
        case "hi-IN":
            return "NotoSansDevanagari"
        
        // 泰語字體
        case "th-TH":
            return "Thonburi"
        
        // 其他歐洲和拉丁語系使用系統字體
        default:
            return "Helvetica"
        }
    }
}

// 語言選項結構
struct LanguageOption: Identifiable {
    let id = UUID()
    let code: String
    let englishName: String
    let chineseName: String
    let flagEmoji: String
}

// 搜尋框組件
struct SearchBar: View {
    @Binding var text: String
    
    var body: some View {
        HStack {
            Image(systemName: "magnifyingglass")
                .foregroundColor(.gray)
            
            TextField("Search language...", text: $text)
                .textFieldStyle(PlainTextFieldStyle())
                .submitLabel(.done)
                .onSubmit {
                    hideKeyboard()
                }
            
            if !text.isEmpty {
                Button(action: {
                    text = ""
                    hideKeyboard()
                }) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.gray)
                }
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.9))
        .cornerRadius(10)
        .shadow(radius: 2)
    }
}

extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

// 語言選擇區段組件 - 改為水平滾動，增加前後佔位元素
struct LanguageSelectionSection: View {
    let title: String
    @Binding var selectedLanguage: String
    let languages: [LanguageOption]
    let cardWidth: CGFloat
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
                .fontWeight(.semibold)
                .foregroundColor(.white)
                .padding(.horizontal)
            
            ScrollViewReader { proxy in
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 15) {
                        // 前置隱藏佔位元素 - 用於將選中項居中
                        Spacer()
                            .frame(width: cardWidth * 0.6)
                            .opacity(0)
                            .id("leading_spacer")
                        
                        ForEach(languages) { language in
                            LanguageCard(
                                language: language,
                                isSelected: selectedLanguage == language.code,
                                cardWidth: cardWidth,
                                onTap: {
                                    selectedLanguage = language.code
                                }
                            )
                            .id(language.code)
                        }
                        
                        // 後置隱藏佔位元素 - 用於將選中項居中
                        Spacer()
                            .frame(width: cardWidth * 0.6)
                            .opacity(0)
                            .id("trailing_spacer")
                    }
                    .padding(.horizontal, 8)
                }
                .onAppear {
                    // 頁面載入時將選取的語言置中
                    if !selectedLanguage.isEmpty {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            withAnimation(.easeInOut(duration: 0.5)) {
                                proxy.scrollTo(selectedLanguage, anchor: .center)
                            }
                        }
                    }
                }
                .onChange(of: selectedLanguage) { newValue in
                    // 當選擇改變時也將新選擇的語言置中
                    if !newValue.isEmpty {
                        withAnimation(.easeInOut(duration: 0.5)) {
                            proxy.scrollTo(newValue, anchor: .center)
                        }
                    }
                }
            }
        }
    }
}

// 語言卡片組件 - 改為方形
struct LanguageCard: View {
    let language: LanguageOption
    let isSelected: Bool
    let cardWidth: CGFloat
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 10) {
                Text(language.flagEmoji)
                    .font(.system(size: 32))
                
                Text(language.englishName)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundColor(.primary)
                    .multilineTextAlignment(.center)
                    .lineLimit(2)
                
                Text(language.chineseName)
                    .font(.system(size: 11))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .lineLimit(1)
            }
            .frame(width: cardWidth * 0.8, height: cardWidth * 0.8)
            .background(
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white.opacity(isSelected ? 1.0 : 0.8))
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(isSelected ? Color.blue : Color.clear, lineWidth: 3)
                    )
            )
            .shadow(radius: isSelected ? 8 : 3)
            .scaleEffect(isSelected ? 1.1 : 1.0)
            .animation(.easeInOut(duration: 0.3), value: isSelected)
        }
        .buttonStyle(PlainButtonStyle())
    }
}

#Preview {
    LanguageSelectionView()
}
