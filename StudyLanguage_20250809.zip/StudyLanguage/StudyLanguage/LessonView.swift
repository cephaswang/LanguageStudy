
import SwiftUI

struct Lesson {
    let id: Int
    let targetText: String
    let nativeText: String
    let pinyinText: String? // Pinyin text
    let hiraganaText: String? // Hiragana text
    let katakanaText: String? // Katakana text
    let audioPath: String?
}

struct UpdatedLessonView: View {
    let sortOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let targetTopic: String
    let nativeTopic: String
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    
    @StateObject private var databaseManager = DatabaseManager()
    @StateObject private var settingsManager = SettingsManager()
    @StateObject private var practiceDatabase = PracticeDatabase()
    @StateObject private var playService: EnhancedPlayService
    
    @State private var lessons: [Lesson] = []
    @State private var isLoading = true
    @State private var completedLessons: Set<Int> = []
    @State private var displayMode: DisplayMode = .bilingual
    @State private var showingSettings = false
    @State private var showPinyin = true // Pinyin display control
    @State private var showKana = true // Japanese kana display control
    
    enum DisplayMode: String, CaseIterable {
        case bilingual = "Bilingual Display"
        case targetOnly = "Target Language"
        case nativeOnly = "Native Language"
    }
    
    // MARK: - Language Direction Support
    
    /// Check if it's a right-to-left (RTL) writing language
    private var isRTLTarget: Bool {
        return RTLLanguageHelper.isRTLLanguage(targetLanguage)
    }
    
    private var isRTLNative: Bool {
        return RTLLanguageHelper.isRTLLanguage(nativeLanguage)
    }
    
    /// Check if it's a Chinese language
    private var isChineseTarget: Bool {
        return targetLanguage == "zh-TW" || targetLanguage == "zh-CN" || targetLanguage.hasPrefix("zh")
    }
    
    /// Check if it's a Japanese language
    private var isJapaneseTarget: Bool {
        return targetLanguage == "ja-JP" || targetLanguage.hasPrefix("ja")
    }
    
    /// Check if auxiliary text needs to be displayed (pinyin, kana, etc.)
    private var shouldShowAuxiliaryText: Bool {
        return isChineseTarget || isJapaneseTarget
    }
    
    // Custom initializer to properly initialize StateObject dependencies
    init(sortOrder: Int, targetLanguage: String, nativeLanguage: String, targetTopic: String, nativeTopic: String, targetLanguageFontName: String, nativeLanguageFontName: String) {
        self.sortOrder = sortOrder
        self.targetLanguage = targetLanguage
        self.nativeLanguage = nativeLanguage
        self.targetTopic = targetTopic
        self.nativeTopic = nativeTopic
        self.targetLanguageFontName = targetLanguageFontName
        self.nativeLanguageFontName = nativeLanguageFontName
        
        let settings = SettingsManager()
        let practice = PracticeDatabase()
        self._settingsManager = StateObject(wrappedValue: settings)
        self._practiceDatabase = StateObject(wrappedValue: practice)
        self._playService = StateObject(wrappedValue: EnhancedPlayService(settingsManager: settings, practiceDatabase: practice))
    }
    
    var progressPercentage: Double {
        guard !lessons.isEmpty else { return 0 }
        return Double(completedLessons.count) / Double(lessons.count)
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Top information area
            HeaderSection()
            
            // Playback control area
            PlaybackControlSection()
            
            // Main content area
            if isLoading {
                LoadingView()
            } else if lessons.isEmpty {
                EmptyStateView()
            } else {
                LessonContentView()
            }
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                HStack {
                    // Auxiliary text display toggle (pinyin/kana)
                    if shouldShowAuxiliaryText {
                        if isChineseTarget {
                            Button(action: { showPinyin.toggle() }) {
                                Image(systemName: showPinyin ? "textformat.abc" : "textformat.abc.dottedunderline")
                                    .foregroundColor(showPinyin ? .blue : .gray)
                            }
                        }
                        
                        if isJapaneseTarget {
                            Button(action: { showKana.toggle() }) {
                                Image(systemName: showKana ? "character.book.closed.fill" : "character.book.closed")
                                    .foregroundColor(showKana ? .purple : .gray)
                            }
                        }
                    }
                    
                    // Display mode selection
                    Menu {
                        ForEach(DisplayMode.allCases, id: \.self) { mode in
                            Button(mode.rawValue) {
                                displayMode = mode
                            }
                        }
                    } label: {
                        Image(systemName: "textformat.alt")
                            .foregroundColor(.blue)
                    }
                    
                    /*
                    // Settings button
                    Button(action: { showingSettings = true }) {
                        Image(systemName: "gearshape.fill")
                            .foregroundColor(.gray)
                    }*/
                }
            }
        }
        .onAppear {
            loadLessons()
            loadCompletedLessons()
        }
        .onDisappear {
            // Stop playback when leaving the page
            playService.stopPlayback()
        }
        .sheet(isPresented: $showingSettings) {
            SettingsView()
        }
        .alert("Loading Error",
               isPresented: Binding(
                get: { databaseManager.error != nil },
                set: { newVal in if !newVal { databaseManager.error = nil } }
               )) {
            Button("OK") {
                databaseManager.error = nil
            }
            Button("Retry") {
                databaseManager.error = nil
                loadLessons()
            }
        } message: {
            Text(databaseManager.error?.localizedDescription ?? "Unknown error")
                .font(.custom(nativeLanguageFontName, size: 14))
        }
        // Apply global RTL environment (if target or native language is RTL)
        .environment(\.layoutDirection, (isRTLTarget || isRTLNative) ? .rightToLeft : .leftToRight)
    }
    
    // MARK: - Header Section
    @ViewBuilder
    private func HeaderSection() -> some View {
        VStack(spacing: 16) {
            HStack(spacing: 16) {
                // Lesson number circle
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [.purple, .pink, .orange],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 60, height: 60)
                        .shadow(color: .purple.opacity(0.3), radius: 8, x: 0, y: 4)
                    
                    VStack(spacing: 2) {
                        Text("Lesson")
                            .font(.custom(nativeLanguageFontName, size: 12))
                            .foregroundColor(.white)
                        Text("\(sortOrder)")
                            .font(.system(size: 18, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                    }
                }
                
                // Topic information (supports RTL alignment)
                VStack(alignment: isRTLTarget ? .trailing : .leading, spacing: 8) {
                    Text(targetTopic)
                        .font(.custom(targetLanguageFontName, size: 20))
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                        .lineLimit(2)
                        .multilineTextAlignment(isRTLTarget ? .trailing : .leading)
                        .flipsForRightToLeftLayoutDirection(isRTLTarget)
                    
                    Text(nativeTopic)
                        .font(.custom(nativeLanguageFontName, size: 16))
                        .foregroundColor(.secondary)
                        .lineLimit(2)
                        .multilineTextAlignment(isRTLNative ? .trailing : .leading)
                        .flipsForRightToLeftLayoutDirection(isRTLNative)
                    
                    // Language tags
                    HStack(spacing: 12) {
                        LanguageTag(language: targetLanguage, color: .blue)
                        LanguageTag(language: nativeLanguage, color: .green)
                        if shouldShowAuxiliaryText {
                            if isChineseTarget {
                                LanguageTag(language: "Pinyin", color: .purple)
                            }
                            if isJapaneseTarget {
                                LanguageTag(language: "Kana", color: .orange)
                            }
                        }
                    }
                }
                
                Spacer()
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
        }
        .background(
            LinearGradient(
                colors: [Color(.systemBackground), Color(.systemGray6)],
                startPoint: .top,
                endPoint: .bottom
            )
        )
    }
    
    // MARK: - Playback Control Section
    @ViewBuilder
    private func PlaybackControlSection() -> some View {
        HStack(spacing: 20) {
            // Playback status indicator
            VStack(alignment: .leading, spacing: 4) {
                if playService.isPlaying || playService.isPaused {
                    Text("Playing sentence \(playService.currentPlayingLessonId ?? 0)")
                        .font(.custom(nativeLanguageFontName, size: 12))
                        .foregroundColor(.blue)
                    
                    if !playService.currentPlayingText.isEmpty {
                        Text(playService.currentPlayingText.prefix(30) + "...")
                            .font(.custom(targetLanguageFontName, size: 10))
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                } else {
                    Text("Ready to play")
                        .font(.custom(nativeLanguageFontName, size: 12))
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            // Playback control buttons
            HStack(spacing: 16) {
                // Stop button
                Button(action: {
                    playService.stopPlayback()
                }) {
                    Image(systemName: "stop.fill")
                        .font(.system(size: 18))
                        .foregroundColor(playService.isPlaying || playService.isPaused ? .red : .gray)
                }
                .disabled(!playService.isPlaying && !playService.isPaused)
                
                // Play/Pause button
                Button(action: {
                    playService.pauseResume()
                }) {
                    Image(systemName: playService.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 20))
                        .foregroundColor(.blue)
                }
                
                // Continuous play button
                if settingsManager.continuousPlayEnabled {
                    Button(action: {
                        if let firstLesson = lessons.first {
                            playService.startContinuousPlayback(
                                fromLessonId: firstLesson.id,
                                lessons: lessons,
                                courseOrder: sortOrder,
                                targetLang: targetLanguage,
                                nativeLang: nativeLanguage
                            )
                        }
                    }) {
                        Image(systemName: "play.rectangle.fill")
                            .font(.system(size: 18))
                            .foregroundColor(.green)
                    }
                    .disabled(playService.isPlaying || lessons.isEmpty)
                }
            }
        }
        .padding(.horizontal, 20)
        .padding(.vertical, 12)
        .background(Color(.systemGray6).opacity(0.5))
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(Color(.systemGray4)),
            alignment: .bottom
        )
    }
    
    // MARK: - Content Views
    @ViewBuilder
    private func LoadingView() -> some View {
        VStack(spacing: 20) {
            ProgressView()
                .scaleEffect(1.5)
                .tint(.blue)
            
            Text("Loading lessons...")
                .font(.custom(nativeLanguageFontName, size: 18))
                .foregroundColor(.secondary)
            
            Text("30 sentences waiting for your practice")
                .font(.custom(nativeLanguageFontName, size: 14))
                .foregroundColor(Color(.tertiaryLabel))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }
    
    @ViewBuilder
    private func EmptyStateView() -> some View {
        VStack(spacing: 24) {
            Image(systemName: "book.closed.fill")
                .font(.system(size: 60))
                .foregroundColor(.orange)
            
            VStack(spacing: 12) {
                Text("No Lesson Content")
                    .font(.custom(nativeLanguageFontName, size: 22))
                    .fontWeight(.bold)
                
                Text("The lessons for this topic are being prepared\nPlease try again later")
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
                    .lineSpacing(4)
            }
            
            Button(action: loadLessons) {
                HStack(spacing: 8) {
                    Image(systemName: "arrow.clockwise")
                    Text("Reload")
                        .font(.custom(nativeLanguageFontName, size: 16))
                }
                .foregroundColor(.white)
                .padding(.horizontal, 24)
                .padding(.vertical, 12)
                .background(
                    LinearGradient(
                        colors: [.blue, .purple],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .cornerRadius(25)
            }
        }
        .padding(32)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }
    
    @ViewBuilder
    private func LessonContentView() -> some View {
        ScrollViewReader { proxy in
            ScrollView {
                LazyVStack(spacing: 16) {
                    ForEach(lessons, id: \.id) { lesson in
                        EnhancedLessonCard(
                            lesson: lesson,
                            displayMode: displayMode,
                            targetLanguageFontName: targetLanguageFontName,
                            nativeLanguageFontName: nativeLanguageFontName,
                            isCompleted: completedLessons.contains(lesson.id),
                            isCurrentlyPlaying: playService.currentPlayingLessonId == lesson.id,
                            playService: playService,
                            settingsManager: settingsManager,
                            practiceDatabase: practiceDatabase,
                            courseOrder: sortOrder,
                            targetLanguage: targetLanguage,
                            nativeLanguage: nativeLanguage,
                            allLessons: lessons,
                            showPinyin: showPinyin && isChineseTarget,
                            showKana: showKana && isJapaneseTarget,
                            isRTLTarget: isRTLTarget,
                            isRTLNative: isRTLNative,
                            onComplete: {
                                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                                    toggleLessonCompletion(lesson.id)
                                }
                            }
                        )
                        .id(lesson.id)
                    }
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 20)
            }
            .onChange(of: playService.currentPlayingLessonId) { newId in
                if let id = newId {
                    withAnimation(.easeInOut) {
                        proxy.scrollTo(id, anchor: .top)
                    }
                }
            }
        }
        .background(Color(.systemGroupedBackground))
        .refreshable {
            loadLessons()
            loadCompletedLessons()
        }
    }

    
    // MARK: - Helper Functions
    private func loadLessons() {
        print("🚀 Starting to load lesson materials... sortOrder: \(sortOrder)")
        isLoading = true
        
        DispatchQueue.global(qos: .userInitiated).async {
            let rows = databaseManager.fetchLessons(
                targetLanguage: targetLanguage,
                nativeLanguage: nativeLanguage,
                sortOrder: sortOrder
            )
            
            let mapped = rows.map { row in
                Lesson(
                    id: row.id,
                    targetText: row.targetText,
                    nativeText: row.nativeText,
                    pinyinText: row.pinyinText,
                    hiraganaText: row.hiraganaText,
                    katakanaText: row.katakanaText,
                    audioPath: nil
                )
            }
            
            DispatchQueue.main.async {
                withAnimation(.easeInOut(duration: 0.5)) {
                    self.lessons = mapped
                    self.isLoading = false
                }
                print("✅ Successfully loaded \(mapped.count) lesson items")
            }
        }
    }
    
    private func loadCompletedLessons() {
        completedLessons = practiceDatabase.getCompletedLessons(
            courseOrder: sortOrder,
            targetLang: targetLanguage,
            nativeLang: nativeLanguage
        )
    }
    
    private func toggleLessonCompletion(_ lessonId: Int) {
        if completedLessons.contains(lessonId) {
            completedLessons.remove(lessonId)
            practiceDatabase.updateProgress(
                lessonId: lessonId,
                courseOrder: sortOrder,
                targetLang: targetLanguage,
                nativeLang: nativeLanguage,
                isCompleted: false
            )
        } else {
            completedLessons.insert(lessonId)
            practiceDatabase.updateProgress(
                lessonId: lessonId,
                courseOrder: sortOrder,
                targetLang: targetLanguage,
                nativeLang: nativeLanguage,
                isCompleted: true
            )
        }
    }
}

// MARK: - Enhanced Lesson Card with RTL Support
struct EnhancedLessonCard: View {
    let lesson: Lesson
    let displayMode: UpdatedLessonView.DisplayMode
    let targetLanguageFontName: String
    let nativeLanguageFontName: String
    let isCompleted: Bool
    let isCurrentlyPlaying: Bool
    let playService: EnhancedPlayService
    let settingsManager: SettingsManager
    let practiceDatabase: PracticeDatabase
    let courseOrder: Int
    let targetLanguage: String
    let nativeLanguage: String
    let allLessons: [Lesson]
    let showPinyin: Bool
    let showKana: Bool
    let isRTLTarget: Bool
    let isRTLNative: Bool
    let onComplete: () -> Void
    
    @State private var showTranslation = false
    
    var body: some View {
        VStack(spacing: 0) {
            // Card title row
            HStack {
                // Lesson number
                Text("Sentence \(lesson.id)")
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundColor(.white)
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(
                        Capsule()
                            .fill(
                                LinearGradient(
                                    colors: isCompleted ? [.green, .mint] : (isCurrentlyPlaying ? [.orange, .red] : [.blue, .purple]),
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                    )
                
                Spacer()
                
                // Function buttons
                HStack(spacing: 12) {
                    // Show translation button
                    if displayMode == .targetOnly || displayMode == .nativeOnly {
                        Button(action: { showTranslation.toggle() }) {
                            Image(systemName: showTranslation ? "eye.slash" : "eye")
                                .font(.system(size: 16))
                                .foregroundColor(.blue)
                        }
                    }
                    
                    // Single sentence play button
                    Button(action: {
                        playService.playSingleSentence(
                            lessonId: lesson.id,
                            targetText: lesson.targetText,
                            nativeText: lesson.nativeText,
                            courseOrder: courseOrder,
                            targetLang: targetLanguage,
                            nativeLang: nativeLanguage
                        )
                    }) {
                        Image(systemName: isCurrentlyPlaying ? "waveform" : "play.circle.fill")
                            .font(.system(size: 20))
                            .foregroundColor(isCurrentlyPlaying ? .orange : .green)
                    }
                    .disabled(playService.isPlaying && !isCurrentlyPlaying)
                    
                    // Start continuous play from this sentence button
                    if settingsManager.continuousPlayEnabled {
                        Button(action: {
                            playService.startContinuousPlayback(
                                fromLessonId: lesson.id,
                                lessons: allLessons,
                                courseOrder: courseOrder,
                                targetLang: targetLanguage,
                                nativeLang: nativeLanguage
                            )
                        }) {
                            Image(systemName: "play.rectangle.fill")
                                .font(.system(size: 16))
                                .foregroundColor(.purple)
                        }
                        .disabled(playService.isPlaying)
                    }
                    
                    // Complete button
                    Button(action: onComplete) {
                        Image(systemName: isCompleted ? "checkmark.circle.fill" : "circle")
                            .font(.system(size: 20))
                            .foregroundColor(isCompleted ? .green : .gray)
                    }
                }
            }
            .padding(.horizontal, 20)
            .padding(.top, 16)
            .padding(.bottom, 12)
            
            // Sentence content
            VStack(alignment: .leading, spacing: 12) {
                // Display content based on display mode
                switch displayMode {
                case .bilingual:
                    BilingualContent()
                case .targetOnly:
                    TargetOnlyContent()
                case .nativeOnly:
                    NativeOnlyContent()
                }
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 20)
        }
        .background(
            RoundedRectangle(cornerRadius: 16)
                .fill(Color(.systemBackground))
                .shadow(
                    color: isCurrentlyPlaying ? .orange.opacity(0.3) : (isCompleted ? .green.opacity(0.2) : .black.opacity(0.08)),
                    radius: 8,
                    x: 0,
                    y: 4
                )
        )
        .overlay(
            RoundedRectangle(cornerRadius: 16)
                .stroke(
                    isCurrentlyPlaying ? .orange.opacity(0.5) : (isCompleted ? .green.opacity(0.3) : Color(.systemGray5)),
                    lineWidth: isCurrentlyPlaying ? 2.0 : 1.5
                )
        )
        .scaleEffect(isCurrentlyPlaying ? 1.02 : (isCompleted ? 0.98 : 1.0))
        .animation(.spring(response: 0.3), value: isCompleted)
        .animation(.spring(response: 0.2), value: isCurrentlyPlaying)
    }
    
    @ViewBuilder
    private func BilingualContent() -> some View {
        VStack(alignment: .leading, spacing: 14) {
            // Target language
            VStack(alignment: isRTLTarget ? .trailing : .leading, spacing: 6) {
                Text("🎯 Target")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.blue)
                    .opacity(0.8)
                
                Text(lesson.targetText)
                    .font(.custom(targetLanguageFontName, size: 18))
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .lineLimit(nil)
                    .multilineTextAlignment(isRTLTarget ? .trailing : .leading)
                    .flipsForRightToLeftLayoutDirection(isRTLTarget)
                
                // Auxiliary text display
                AuxiliaryTextView(lesson: lesson, showPinyin: showPinyin, showKana: showKana, alignment: isRTLTarget ? .trailing : .leading)
            }
            
            Divider()
                .opacity(0.5)
            
            // Native translation
            VStack(alignment: isRTLNative ? .trailing : .leading, spacing: 6) {
                Text("🏠 Translation")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundColor(.green)
                    .opacity(0.8)
                
                Text(lesson.nativeText)
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .foregroundColor(.secondary)
                    .lineLimit(nil)
                    .multilineTextAlignment(isRTLNative ? .trailing : .leading)
                    .flipsForRightToLeftLayoutDirection(isRTLNative)
            }
        }
    }
    
    @ViewBuilder
    private func TargetOnlyContent() -> some View {
        VStack(alignment: isRTLTarget ? .trailing : .leading, spacing: 12) {
            Text(lesson.targetText)
                .font(.custom(targetLanguageFontName, size: 20))
                .fontWeight(.medium)
                .foregroundColor(.primary)
                .lineLimit(nil)
                .multilineTextAlignment(isRTLTarget ? .trailing : .leading)
                .flipsForRightToLeftLayoutDirection(isRTLTarget)
            
            // Auxiliary text display
            AuxiliaryTextView(lesson: lesson, showPinyin: showPinyin, showKana: showKana, alignment: isRTLTarget ? .trailing : .leading)
            
            if showTranslation {
                Text(lesson.nativeText)
                    .font(.custom(nativeLanguageFontName, size: 16))
                    .foregroundColor(.secondary)
                    .lineLimit(nil)
                    .multilineTextAlignment(isRTLNative ? .trailing : .leading)
                    .flipsForRightToLeftLayoutDirection(isRTLNative)
                    .transition(.opacity.combined(with: .slide))
            }
        }
    }
    
    @ViewBuilder
    private func NativeOnlyContent() -> some View {
        VStack(alignment: isRTLNative ? .trailing : .leading, spacing: 12) {
            Text(lesson.nativeText)
                .font(.custom(nativeLanguageFontName, size: 18))
                .fontWeight(.medium)
                .foregroundColor(.primary)
                .lineLimit(nil)
                .multilineTextAlignment(isRTLNative ? .trailing : .leading)
                .flipsForRightToLeftLayoutDirection(isRTLNative)
            
            if showTranslation {
                VStack(alignment: isRTLTarget ? .trailing : .leading, spacing: 8) {
                    Text(lesson.targetText)
                        .font(.custom(targetLanguageFontName, size: 16))
                        .foregroundColor(.secondary)
                        .lineLimit(nil)
                        .multilineTextAlignment(isRTLTarget ? .trailing : .leading)
                        .flipsForRightToLeftLayoutDirection(isRTLTarget)
                    
                    // Auxiliary text display
                    AuxiliaryTextView(lesson: lesson, showPinyin: showPinyin, showKana: showKana, alignment: isRTLTarget ? .trailing : .leading)
                }
                .transition(.opacity.combined(with: .slide))
            }
        }
    }
}

// MARK: - Auxiliary Text View (Pinyin, Kana, etc.)
struct AuxiliaryTextView: View {
    let lesson: Lesson
    let showPinyin: Bool
    let showKana: Bool
    let alignment: HorizontalAlignment
    
    var body: some View {
        VStack(alignment: alignment, spacing: 4) {
            // Pinyin display (Chinese target language only)
            if showPinyin, let pinyin = lesson.pinyinText, !pinyin.isEmpty {
                Text(pinyin)
                    .font(.system(size: 14, weight: .regular, design: .monospaced))
                    .foregroundColor(.purple)
                    .multilineTextAlignment(alignment == .trailing ? .trailing : .leading)
            }
            
            // Kana display (Japanese target language only)
            if showKana {
                if let hiragana = lesson.hiraganaText, !hiragana.isEmpty {
                    Text("Hiragana: \(hiragana)")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.orange)
                        .multilineTextAlignment(alignment == .trailing ? .trailing : .leading)
                }
                if let katakana = lesson.katakanaText, !katakana.isEmpty {
                    Text("Katakana: \(katakana)")
                        .font(.system(size: 14, weight: .regular))
                        .foregroundColor(.red)
                        .multilineTextAlignment(alignment == .trailing ? .trailing : .leading)
                }
            }
        }
    }
}

// MARK: - RTL Language Helper
struct RTLLanguageHelper {
    /// List of RTL languages supported by iOS TTS
    static let rtlLanguages: Set<String> = [
        // Arabic family
        "ar", "ar-SA", "ar-AE", "ar-BH", "ar-DZ", "ar-EG", "ar-IQ", "ar-JO",
        "ar-KW", "ar-LB", "ar-LY", "ar-MA", "ar-OM", "ar-QA", "ar-SY", "ar-TN", "ar-YE",
        
        // Hebrew
        "he", "he-IL", "iw", "iw-IL",
        
        // Persian/Farsi
        "fa", "fa-IR", "per",
        
        // Urdu
        "ur", "ur-IN", "ur-PK",
        
        // Uyghur
        "ug", "ug-CN",
        
        // Kurdish
        "ku", "ckb"
    ]
    
    /// Check if language code is RTL language
    static func isRTLLanguage(_ languageCode: String) -> Bool {
        let normalizedCode = languageCode.lowercased()
        
        // Direct match
        if rtlLanguages.contains(normalizedCode) {
            return true
        }
        
        // Check language prefix (e.g. "ar-XX" matches "ar")
        for rtlLang in rtlLanguages {
            if normalizedCode.hasPrefix(rtlLang + "-") || rtlLang.hasPrefix(normalizedCode + "-") {
                return true
            }
        }
        
        return false
    }
    
    /// Get language display name
    static func getLanguageDisplayName(_ languageCode: String) -> String {
        let locale = Locale.current
        return locale.localizedString(forLanguageCode: languageCode) ?? languageCode.uppercased()
    }
}

// MARK: - iOS TTS Language Support Helper
struct TTSLanguageHelper {
    /// Complete list of languages supported by iOS TTS
    static let supportedLanguages: [String: String] = [
        // Arabic family
        "ar-SA": "Arabic (Saudi Arabia)",
        "ar-AE": "Arabic (UAE)",
        "ar-EG": "Arabic (Egypt)",
        "ar-MA": "Arabic (Morocco)",
        "ar-JO": "Arabic (Jordan)",
        "ar-KW": "Arabic (Kuwait)",
        "ar-LB": "Arabic (Lebanon)",
        "ar-QA": "Arabic (Qatar)",
        "ar-SY": "Arabic (Syria)",
        
        // Chinese family
        "zh-CN": "Chinese (Mainland)",
        "zh-TW": "Chinese (Taiwan)",
        "zh-HK": "Chinese (Hong Kong)",
        "yue-CN": "Chinese (Cantonese)",
        
        // English family
        "en-US": "English (US)",
        "en-GB": "English (UK)",
        "en-AU": "English (Australia)",
        "en-CA": "English (Canada)",
        "en-IN": "English (India)",
        "en-IE": "English (Ireland)",
        "en-NZ": "English (New Zealand)",
        "en-SG": "English (Singapore)",
        "en-ZA": "English (South Africa)",
        
        // Spanish family
        "es-ES": "Spanish (Spain)",
        "es-MX": "Spanish (Mexico)",
        "es-AR": "Spanish (Argentina)",
        "es-CL": "Spanish (Chile)",
        "es-CO": "Spanish (Colombia)",
        "es-PE": "Spanish (Peru)",
        "es-VE": "Spanish (Venezuela)",
        
        // French family
        "fr-FR": "French (France)",
        "fr-CA": "French (Canada)",
        "fr-CH": "French (Switzerland)",
        "fr-BE": "French (Belgium)",
        
        // German family
        "de-DE": "German (Germany)",
        "de-AT": "German (Austria)",
        "de-CH": "German (Switzerland)",
        
        // Italian
        "it-IT": "Italian (Italy)",
        "it-CH": "Italian (Switzerland)",
        
        // Portuguese
        "pt-BR": "Portuguese (Brazil)",
        "pt-PT": "Portuguese (Portugal)",
        
        // Russian
        "ru-RU": "Russian",
        
        // Japanese
        "ja-JP": "Japanese",
        
        // Korean
        "ko-KR": "Korean",
        
        // Hindi
        "hi-IN": "Hindi",
        
        // Thai
        "th-TH": "Thai",
        
        // Vietnamese
        "vi-VN": "Vietnamese",
        
        // Indonesian
        "id-ID": "Indonesian",
        
        // Malay
        "ms-MY": "Malay",
        
        // Dutch
        "nl-NL": "Dutch (Netherlands)",
        "nl-BE": "Dutch (Belgium)",
        
        // Swedish
        "sv-SE": "Swedish",
        
        // Norwegian
        "nb-NO": "Norwegian",
        
        // Danish
        "da-DK": "Danish",
        
        // Finnish
        "fi-FI": "Finnish",
        
        // Polish
        "pl-PL": "Polish",
        
        // Czech
        "cs-CZ": "Czech",
        
        // Slovak
        "sk-SK": "Slovak",
        
        // Hungarian
        "hu-HU": "Hungarian",
        
        // Romanian
        "ro-RO": "Romanian",
        
        // Bulgarian
        "bg-BG": "Bulgarian",
        
        // Croatian
        "hr-HR": "Croatian",
        
        // Greek
        "el-GR": "Greek",
        
        // Hebrew
        "he-IL": "Hebrew",
        
        // Turkish
        "tr-TR": "Turkish",
        
        // Persian
        "fa-IR": "Persian",
        
        // Urdu
        "ur-PK": "Urdu",
        
        // Bengali
        "bn-BD": "Bengali (Bangladesh)",
        "bn-IN": "Bengali (India)",
        
        // Gujarati
        "gu-IN": "Gujarati",
        
        // Marathi
        "mr-IN": "Marathi",
        
        // Tamil
        "ta-IN": "Tamil (India)",
        "ta-SG": "Tamil (Singapore)",
        "ta-LK": "Tamil (Sri Lanka)",
        
        // Telugu
        "te-IN": "Telugu",
        
        // Kannada
        "kn-IN": "Kannada",
        
        // Malayalam
        "ml-IN": "Malayalam",
        
        // Punjabi
        "pa-IN": "Punjabi",
        
        // Odia
        "or-IN": "Odia",
        
        // Assamese
        "as-IN": "Assamese",
        
        // Ukrainian
        "uk-UA": "Ukrainian",
        
        // Lithuanian
        "lt-LT": "Lithuanian",
        
        // Latvian
        "lv-LV": "Latvian",
        
        // Estonian
        "et-EE": "Estonian",
        
        // Slovenian
        "sl-SI": "Slovenian",
        
        // Serbian
        "sr-RS": "Serbian",
        
        // Macedonian
        "mk-MK": "Macedonian",
        
        // Albanian
        "sq-AL": "Albanian",
        
        // Armenian
        "hy-AM": "Armenian",
        
        // Georgian
        "ka-GE": "Georgian",
        
        // Azerbaijani
        "az-AZ": "Azerbaijani",
        
        // Kazakh
        "kk-KZ": "Kazakh",
        
        // Uzbek
        "uz-UZ": "Uzbek",
        
        // Uyghur
        "ug-CN": "Uyghur",
        
        // Mongolian
        "mn-MN": "Mongolian",
        
        // Tibetan
        "bo-CN": "Tibetan",
        
        // Burmese
        "my-MM": "Burmese",
        
        // Khmer
        "km-KH": "Khmer",
        
        // Lao
        "lo-LA": "Lao",
        
        // Sinhala
        "si-LK": "Sinhala",
        
        // Dhivehi
        "dv-MV": "Dhivehi",
        
        // Nepali
        "ne-NP": "Nepali",
        
        // Dzongkha
        "dz-BT": "Dzongkha",
        
        // Welsh
        "cy-GB": "Welsh",
        
        // Irish
        "ga-IE": "Irish",
        
        // Scottish Gaelic
        "gd-GB": "Scottish Gaelic",
        
        // Basque
        "eu-ES": "Basque",
        
        // Catalan
        "ca-ES": "Catalan",
        
        // Galician
        "gl-ES": "Galician",
        
        // Maltese
        "mt-MT": "Malta",
        
        // Icelandic
        "is-IS": "Icelandic",
        
        // Faroese
        "fo-FO": "Faroese",
        
        // Northern Sami
        "se-NO": "Northern Sami",
        
        // Afrikaans
        "af-ZA": "Afrikaans",
        
        // Zulu
        "zu-ZA": "Zulu",
        
        // Xhosa
        "xh-ZA": "Xhosa",
        
        // Swahili
        "sw-KE": "Swahili (Kenya)",
        "sw-TZ": "Swahili (Tanzania)",
        
        // Amharic
        "am-ET": "Amharic",
        
        // Hausa
        "ha-NG": "Hausa",
        
        // Yoruba
        "yo-NG": "Yoruba",
        
        // Igbo
        "ig-NG": "Igbo"
    ]
    
    /// Check if a language is supported
    static func isLanguageSupported(_ languageCode: String) -> Bool {
        return supportedLanguages.keys.contains(languageCode)
    }
    
    /// Get supported language display name
    static func getLanguageDisplayName(_ languageCode: String) -> String {
        return supportedLanguages[languageCode] ?? languageCode.uppercased()
    }
    
    /// Get all supported language codes
    static func getAllSupportedLanguageCodes() -> [String] {
        return Array(supportedLanguages.keys).sorted()
    }
    
    /// Group languages by family
    static func getLanguagesByFamily() -> [String: [String]] {
        var families: [String: [String]] = [:]
        
        for (code, name) in supportedLanguages {
            let prefix = String(code.prefix(2))
            let familyName = getLanguageFamilyName(prefix)
            
            if families[familyName] == nil {
                families[familyName] = []
            }
            families[familyName]?.append(code)
        }
        
        // Sort languages within each family
        for key in families.keys {
            families[key]?.sort()
        }
        
        return families
    }
    
    private static func getLanguageFamilyName(_ languagePrefix: String) -> String {
        switch languagePrefix {
        case "ar": return "Arabic"
        case "zh", "yue": return "Chinese"
        case "en": return "English"
        case "es": return "Spanish"
        case "fr": return "French"
        case "de": return "German"
        case "it": return "Italian"
        case "pt": return "Portuguese"
        case "ru": return "Russian"
        case "ja": return "Japanese"
        case "ko": return "Korean"
        case "hi", "bn", "gu", "mr", "ta", "te", "kn", "ml", "pa", "or", "as", "ne": return "Indo-Aryan"
        case "th": return "Thai"
        case "vi": return "Vietnamese"
        case "id": return "Indonesian"
        case "ms": return "Malay"
        case "nl": return "Dutch"
        case "sv": return "Swedish"
        case "nb": return "Norwegian"
        case "da": return "Danish"
        case "fi": return "Finnish"
        case "pl": return "Polish"
        case "cs": return "Czech"
        case "sk": return "Slovak"
        case "hu": return "Hungarian"
        case "ro": return "Romanian"
        case "bg": return "Bulgarian"
        case "hr": return "Croatian"
        case "el": return "Greek"
        case "he": return "Hebrew"
        case "tr": return "Turkish"
        case "fa": return "Persian"
        case "ur": return "Urdu"
        case "uk": return "Ukrainian"
        case "lt": return "Lithuanian"
        case "lv": return "Latvian"
        case "et": return "Estonian"
        case "sl": return "Slovenian"
        case "sr": return "Serbian"
        case "mk": return "Macedonian"
        case "sq": return "Albanian"
        case "hy": return "Armenian"
        case "ka": return "Georgian"
        case "az": return "Azerbaijani"
        case "kk": return "Kazakh"
        case "uz": return "Uzbek"
        case "ug": return "Uyghur"
        case "mn": return "Mongolian"
        case "bo": return "Tibetan"
        case "my": return "Burmese"
        case "km": return "Khmer"
        case "lo": return "Lao"
        case "si": return "Sinhala"
        case "dv": return "Dhivehi"
        case "dz": return "Dzongkha"
        case "cy": return "Welsh"
        case "ga": return "Irish"
        case "gd": return "Scottish Gaelic"
        case "eu": return "Basque"
        case "ca": return "Catalan"
        case "gl": return "Galician"
        case "mt": return "Maltese"
        case "is": return "Icelandic"
        case "fo": return "Faroese"
        case "se": return "Sami"
        case "af": return "Afrikaans"
        case "zu": return "Zulu"
        case "xh": return "Xhosa"
        case "sw": return "Swahili"
        case "am": return "Amharic"
        case "ha": return "Hausa"
        case "yo": return "Yoruba"
        case "ig": return "Igbo"
        default: return "Other"
        }
    }
}

// MARK: - Supporting Views (Enhanced for RTL)
struct LanguageTag: View {
    let language: String
    let color: Color
    
    var body: some View {
        Text(TTSLanguageHelper.getLanguageDisplayName(language))
            .font(.system(size: 10, weight: .bold, design: .monospaced))
            .foregroundColor(color)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(
                RoundedRectangle(cornerRadius: 4)
                    .fill(color.opacity(0.1))
                    .overlay(
                        RoundedRectangle(cornerRadius: 4)
                            .stroke(color.opacity(0.3), lineWidth: 1)
                    )
            )
    }
}

struct StatItem: View {
    let title: String
    let value: String
    let color: Color
    
    var body: some View {
        VStack(spacing: 4) {
            Text(value)
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundColor(color)
            
            Text(title)
                .font(.system(size: 12))
                .foregroundColor(.secondary)
        }
    }
}

/*
// MARK: - Language Selection Helper View
struct LanguageSelectionView: View {
    @Binding var selectedLanguage: String
    let title: String
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            List {
                ForEach(TTSLanguageHelper.getLanguagesByFamily().sorted(by: { $0.key < $1.key }), id: \.key) { familyName, languages in
                    Section(familyName) {
                        ForEach(languages, id: \.self) { languageCode in
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(TTSLanguageHelper.getLanguageDisplayName(languageCode))
                                        .font(.body)
                                    Text(languageCode)
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    
                                    // RTL indicator
                                    if RTLLanguageHelper.isRTLLanguage(languageCode) {
                                        Text("RTL")
                                            .font(.caption2)
                                            .padding(.horizontal, 6)
                                            .padding(.vertical, 2)
                                            .background(Color.orange.opacity(0.2))
                                            .foregroundColor(.orange)
                                            .cornerRadius(4)
                                    }
                                }
                                
                                Spacer()
                                
                                if selectedLanguage == languageCode {
                                    Image(systemName: "checkmark.circle.fill")
                                        .foregroundColor(.blue)
                                }
                            }
                            .contentShape(Rectangle())
                            .onTapGesture {
                                selectedLanguage = languageCode
                                dismiss()
                            }
                        }
                    }
                }
            }
            .navigationTitle(title)
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}
*/

// MARK: - Preview
struct UpdatedLessonView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            // Japanese preview
            NavigationView {
                UpdatedLessonView(
                    sortOrder: 1,
                    targetLanguage: "ja-JP",
                    nativeLanguage: "en-US",
                    targetTopic: "Basic Greetings & Self Introduction",
                    nativeTopic: "Basic Greetings & Introductions",
                    targetLanguageFontName: "HiraginoSans-W3",
                    nativeLanguageFontName: "Helvetica"
                )
            }
            .previewDisplayName("Japanese")
            
            // Arabic preview (RTL)
            NavigationView {
                UpdatedLessonView(
                    sortOrder: 2,
                    targetLanguage: "ar-SA",
                    nativeLanguage: "en-US",
                    targetTopic: "Basic Greetings & Self Introduction",
                    nativeTopic: "Basic Greetings & Self Introduction",
                    targetLanguageFontName: ".AppleSystemUIFont",
                    nativeLanguageFontName: "Helvetica"
                )
            }
            .previewDisplayName("Arabic (RTL)")
            
            // Hebrew preview (RTL)
            NavigationView {
                UpdatedLessonView(
                    sortOrder: 3,
                    targetLanguage: "he-IL",
                    nativeLanguage: "en-US",
                    targetTopic: "Basic Greetings & Self Introduction",
                    nativeTopic: "Basic Greetings & Self Introduction",
                    targetLanguageFontName: ".AppleSystemUIFont",
                    nativeLanguageFontName: "Helvetica"
                )
            }
            .previewDisplayName("Hebrew (RTL)")
            
            // Chinese preview
            NavigationView {
                UpdatedLessonView(
                    sortOrder: 4,
                    targetLanguage: "zh-CN",
                    nativeLanguage: "en-US",
                    targetTopic: "Basic Greetings & Self Introduction",
                    nativeTopic: "Basic Greetings & Self Introduction",
                    targetLanguageFontName: "PingFangSC-Regular",
                    nativeLanguageFontName: "Helvetica"
                )
            }
            .previewDisplayName("Chinese")
        }
    }
}
