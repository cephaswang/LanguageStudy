BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('cs-CZ','Základní Každodenní Výrazy',1),
 ('cs-CZ','Společenský Život a Zájmy',2),
 ('cs-CZ','Domov a Každodenní Život',3),
 ('cs-CZ','Studium a Práce',4),
 ('cs-CZ','Cestování a Kultura',5),
 ('cs-CZ','Pokročilá Komunikace',6),
 ('cs-CZ','Společnost a Zprávy',7),
 ('cs-CZ','Pokročilé Myšlení',8),
 ('cs-CZ','Odborný Jazyk',9),
 ('cs-CZ','Integrovaná Aplikace',10);

COMMIT;
