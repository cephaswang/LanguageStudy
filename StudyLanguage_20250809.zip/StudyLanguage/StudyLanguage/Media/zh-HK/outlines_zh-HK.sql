BEGIN TRANSACTION;
INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES
 ('zh-HK','基礎生活用語',1),
 ('zh-HK','社交與興趣',2),
 ('zh-HK','家庭與生活',3),
 ('zh-HK','學習與工作',4),
 ('zh-HK','旅行與文化',5),
 ('zh-HK','進階交流',6),
 ('zh-HK','社會與新聞',7),
 ('zh-HK','高階思考',8),
 ('zh-HK','專業語言',9),
 ('zh-HK','綜合應用',10);
COMMIT;
