BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('tr-TR','Temel Günlük İfadeler',1),
 ('tr-TR','Sosyal Yaşam ve İlgi Alanları',2),
 ('tr-TR','Ev ve Günlük Yaşam',3),
 ('tr-TR','Eğitim ve İş',4),
 ('tr-TR','Seyahat ve Kültür',5),
 ('tr-TR','İleri Düzey İletişim',6),
 ('tr-TR','Toplum ve Haberler',7),
 ('tr-TR','İleri Düşünme',8),
 ('tr-TR','Mesleki Dil',9),
 ('tr-TR','Bütünleşik Uygulama',10);

COMMIT;
