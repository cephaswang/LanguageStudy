from deep_translator import GoogleTranslator

input_file = "sentence_en-US.sql"
output_file = "sentence_de-DE.sql"

translator = GoogleTranslator(source="en", target="de")

with open(input_file, "r", encoding="utf-8") as f:
    lines = f.readlines()

with open(output_file, "w", encoding="utf-8") as f:
    for line in lines:
        if line.strip().startswith("('"):
            # 取出英文句子部分
            sentence = line.split("',")[0].replace("('", "").replace("''", "'")
            # 翻譯成德語
            translated = translator.translate(sentence)
            # 處理 SQL 單引號
            translated_sql = translated.replace("'", "''")
            # 替換原句
            new_line = line.replace(sentence, translated_sql)
            f.write(new_line)
        else:
            f.write(line)

print("完成轉換，輸出到", output_file)
