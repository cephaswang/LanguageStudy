BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES
 ('ja-Hira','きほんてきなにちじょうひょうげん',1),
 ('ja-Hira','しゃかいせいかつとしゅみ',2),
 ('ja-Hira','かていとにちじょうせいかつ',3),
 ('ja-Hira','がくしゅうとしごと',4),
 ('ja-Hira','りょこうとぶんか',5),
 ('ja-Hira','こうどなコミュニケーション',6),
 ('ja-Hira','しゃかいとニュース',7),
 ('ja-Hira','こうどなしこう',8),
 ('ja-Hira','せんもんてきなげんご',9),
 ('ja-Hira','とうごうてきなおうよう',10);

COMMIT;
