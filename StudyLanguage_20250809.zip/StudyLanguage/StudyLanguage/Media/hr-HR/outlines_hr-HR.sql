BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('hr-HR','Osnovni Svakodnevni Izrazi',1),
 ('hr-HR','Društveni Život i Interesi',2),
 ('hr-HR','Dom i Svakodnevni Život',3),
 ('hr-HR','Učenje i Rad',4),
 ('hr-HR','Putovanja i Kultura',5),
 ('hr-HR','Napredna Komunikacija',6),
 ('hr-HR','Društvo i Vijesti',7),
 ('hr-HR','Napredno Razmišljanje',8),
 ('hr-HR','Stručni Jezik',9),
 ('hr-HR','Integrirana Primjena',10);

COMMIT;
