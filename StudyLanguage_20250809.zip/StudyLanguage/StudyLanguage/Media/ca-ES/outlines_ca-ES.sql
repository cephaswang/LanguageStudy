BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('ca-ES','Expressions Bàsiques Quotidianes',1),
 ('ca-ES','Vida Social i Interessos',2),
 ('ca-ES','Llar i Vida Quotidiana',3),
 ('ca-ES','Estudis i Feina',4),
 ('ca-ES','Viatges i Cultura',5),
 ('ca-ES','Comunicació Avançada',6),
 ('ca-ES','Societat i Notícies',7),
 ('ca-ES','Pensament Avançat',8),
 ('ca-ES','Llenguatge Professional',9),
 ('ca-ES','Aplicació Integrada',10);

COMMIT;
