BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('sk-SK','Základné Každodenné Výrazy',1),
 ('sk-SK','Spoločenský Život a Záujmy',2),
 ('sk-SK','Domov a Každodenný Život',3),
 ('sk-SK','Štúdium a Práca',4),
 ('sk-SK','Cestovanie a Kultúra',5),
 ('sk-SK','Pokročilá Komunikácia',6),
 ('sk-SK','Spoločnosť a Správy',7),
 ('sk-SK','Pokročilé Myslenie',8),
 ('sk-SK','Profesionálny Jazyk',9),
 ('sk-SK','Integrovaná Aplikácia',10);

COMMIT;
