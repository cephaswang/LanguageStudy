BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('vi-VN','Các biểu đạt hàng ngày cơ bản',1),
 ('vi-VN','Đời sống xã hội & Sở thích',2),
 ('vi-VN','Gia đình & Đời sống hằng ngày',3),
 ('vi-VN','Học tập & Công việc',4),
 ('vi-VN','Du lịch & Văn hóa',5),
 ('vi-VN','Giao tiếp nâng cao',6),
 ('vi-VN','Xã hội & Tin tức',7),
 ('vi-VN','Tư duy nâng cao',8),
 ('vi-VN','Ngôn ngữ chuyên ngành',9),
 ('vi-VN','Ứng dụng tổng hợp',10);

COMMIT;
