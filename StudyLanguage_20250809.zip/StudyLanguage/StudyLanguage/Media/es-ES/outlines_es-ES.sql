BEGIN TRANSACTION;


DELETE FROM "outlines"
WHERE "lang_code" = 'es-ES';

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('es-ES','Expresiones Diarias Básicas',1),
 ('es-ES','Vida Social e Intereses',2),
 ('es-ES','Hogar y Vida Cotidiana',3),
 ('es-ES','Estudio y Trabajo',4),
 ('es-ES','Viajes y Cultura',5),
 ('es-ES','Comunicación Avanzada',6),
 ('es-ES','Sociedad y Noticias',7),
 ('es-ES','Pensamiento Avanzado',8),
 ('es-ES','Lenguaje Profesional',9),
 ('es-ES','Aplicación Integrada',10);

COMMIT;
