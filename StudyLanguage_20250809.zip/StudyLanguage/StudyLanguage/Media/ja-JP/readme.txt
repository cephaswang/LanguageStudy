
python3 convert_hira_to_kata.py sentence_ja-Hira.sql sentence_ja-kata.sql
