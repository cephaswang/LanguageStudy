BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('pl-PL','Podstawowe Codzienne Zwroty',1),
 ('pl-PL','Życie Towarzyskie i Zainteresowania',2),
 ('pl-PL','Dom i Codzienne Życie',3),
 ('pl-PL','Nauka i Praca',4),
 ('pl-PL','Podróże i Kultura',5),
 ('pl-PL','Zaawansowana Komunikacja',6),
 ('pl-PL','Społeczeństwo i Wiadomości',7),
 ('pl-PL','Zaawansowane Myślenie',8),
 ('pl-PL','Język Zawodowy',9),
 ('pl-PL','Zintegrowane Zastosowanie',10);

COMMIT;
