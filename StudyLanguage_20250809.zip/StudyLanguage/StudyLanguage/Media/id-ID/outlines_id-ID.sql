BEGIN TRANSACTION;

INSERT INTO "outlines" ("lang_code","outline","sort_order") VALUES

 ('id-ID','Ungkapan Sehari-hari Dasar',1),
 ('id-ID','Kehidupan Sosial & Minat',2),
 ('id-ID','Rumah & Kehidupan Sehari-hari',3),
 ('id-ID','Belajar & Bekerja',4),
 ('id-ID','Perjalanan & Budaya',5),
 ('id-ID','Komunikasi Lanjutan',6),
 ('id-ID','Masyarakat & Berita',7),
 ('id-ID','Pemikiran Lanjutan',8),
 ('id-ID','Bahasa Profesional',9),
 ('id-ID','Aplikasi Terintegrasi',10);

COMMIT;
