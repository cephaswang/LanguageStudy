import Foundation
import Combine

class SettingsManager: ObservableObject {
    private let userDefaults = UserDefaults.standard
    
    // MARK: - TTS Settings
    @Published var playTargetLanguage: Bool {
        didSet {
            userDefaults.set(playTargetLanguage, forKey: "playTargetLanguage")
        }
    }
    
    @Published var playNativeLanguage: Bool {
        didSet {
            userDefaults.set(playNativeLanguage, forKey: "playNativeLanguage")
        }
    }
    
    @Published var singleSentenceRepeatCount: Int {
        didSet {
            userDefaults.set(singleSentenceRepeatCount, forKey: "singleSentenceRepeatCount")
        }
    }
    
    @Published var speechRate: Float {
        didSet {
            userDefaults.set(speechRate, forKey: "speechRate")
        }
    }
    
    // MARK: - Playback Order Settings
    @Published var playbackOrder: PlaybackOrder {
        didSet {
            userDefaults.set(playbackOrder.rawValue, forKey: "playbackOrder")
        }
    }
    
    // MARK: - Continuous Play Settings
    @Published var continuousPlayEnabled: Bool {
        didSet {
            userDefaults.set(continuousPlayEnabled, forKey: "continuousPlayEnabled")
        }
    }
    
    @Published var pauseBetweenSentences: Double {
        didSet {
            userDefaults.set(pauseBetweenSentences, forKey: "pauseBetweenSentences")
        }
    }
    
    enum PlaybackOrder: String, CaseIterable {
        case targetFirst = "targetFirst"
        case nativeFirst = "nativeFirst"
        case targetOnly = "targetOnly"
        case nativeOnly = "nativeOnly"
        
        var displayName: String {
            switch self {
            case .targetFirst:
                return "Target Language First"
            case .nativeFirst:
                return "Native Language First"
            case .targetOnly:
                return "Target Language Only"
            case .nativeOnly:
                return "Native Language Only"
            }
        }

        
        /*
        var displayName: String {
            switch self {
            case .targetFirst:
                return "目標語言優先"
            case .nativeFirst:
                return "母語優先"
            case .targetOnly:
                return "只播放目標語言"
            case .nativeOnly:
                return "只播放母語"
            }
        }*/
    }
    
    init() {
        // Initialize with default values or stored values
        self.playTargetLanguage = userDefaults.object(forKey: "playTargetLanguage") as? Bool ?? true
        self.playNativeLanguage = userDefaults.object(forKey: "playNativeLanguage") as? Bool ?? true
        self.singleSentenceRepeatCount = userDefaults.object(forKey: "singleSentenceRepeatCount") as? Int ?? 1
        self.speechRate = userDefaults.object(forKey: "speechRate") as? Float ?? 0.5
        
        let playbackOrderString = userDefaults.string(forKey: "playbackOrder") ?? PlaybackOrder.targetFirst.rawValue
        self.playbackOrder = PlaybackOrder(rawValue: playbackOrderString) ?? .targetFirst
        
        self.continuousPlayEnabled = userDefaults.object(forKey: "continuousPlayEnabled") as? Bool ?? false
        self.pauseBetweenSentences = userDefaults.object(forKey: "pauseBetweenSentences") as? Double ?? 1.0
    }
    
    // MARK: - Helper Methods
    func resetToDefaults() {
        playTargetLanguage = true
        playNativeLanguage = true
        singleSentenceRepeatCount = 1
        speechRate = 0.5
        playbackOrder = .targetFirst
        continuousPlayEnabled = false
        pauseBetweenSentences = 1.0
    }
    
    /// 僅依照開關判斷是否播放目標語言（順序由 `playbackOrder` 控制）
    func shouldPlayTargetLanguage() -> Bool {
        return playTargetLanguage
    }
    
    /// 僅依照開關判斷是否播放母語（順序由 `playbackOrder` 控制）
    func shouldPlayNativeLanguage() -> Bool {
        return playNativeLanguage
    }
}
