import SwiftUI

struct SettingsView: View {
    @StateObject private var settingsManager = SettingsManager()
    @StateObject private var practiceDatabase = PracticeDatabase()
    @State private var showingClearAlert = false
    @State private var clearAlertType: ClearAlertType = .all
    
    enum ClearAlertType {
        case all
        case current
    }
    
    var body: some View {
        NavigationView {
            Form {
                // MARK: - TTS Settings Section
                Section(header: Text("TTS Settings")) {
                    // Target Language Toggle
                    HStack {
                        Image(systemName: "target")
                            .foregroundColor(.blue)
                        Toggle("Play Target Language", isOn: $settingsManager.playTargetLanguage)
                    }
                    
                    // Native Language Toggle
                    HStack {
                        Image(systemName: "house")
                            .foregroundColor(.green)
                        Toggle("Play Native Language", isOn: $settingsManager.playNativeLanguage)
                    }
                    
                    // Playback Order
                    HStack {
                        Image(systemName: "arrow.up.arrow.down")
                            .foregroundColor(.orange)
                        
                        VStack(alignment: .leading) {
                            Text("Playback Order")
                            Picker("Playback Order", selection: $settingsManager.playbackOrder) {
                                ForEach(SettingsManager.PlaybackOrder.allCases, id: \.self) { order in
                                    Text(order.displayName).tag(order)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                        }
                    }
                    
                    // Repeat Count
                    HStack {
                        Image(systemName: "repeat")
                            .foregroundColor(.purple)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Repeat Count per Sentence")
                            Stepper(value: $settingsManager.singleSentenceRepeatCount, in: 1...10) {
                                Text("\(settingsManager.singleSentenceRepeatCount) times")
                                    .foregroundColor(.secondary)
                            }
                        }
                    }
                    
                    // Speech Rate
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Image(systemName: "speedometer")
                                .foregroundColor(.red)
                            Text("Speech Rate")
                            Spacer()
                            Text(String(format: "%.1fx", settingsManager.speechRate))
                                .foregroundColor(.secondary)
                        }
                        
                        Slider(value: $settingsManager.speechRate, in: 0.1...2.0, step: 0.1) {
                            Text("Speech Rate")
                        } minimumValueLabel: {
                            Text("Slow")
                                .font(.caption)
                        } maximumValueLabel: {
                            Text("Fast")
                                .font(.caption)
                        }
                    }
                }
                
                // MARK: - Continuous Play Section
                Section(header: Text("Continuous Play Settings")) {
                    HStack {
                        Image(systemName: "play.circle")
                            .foregroundColor(.indigo)
                        Toggle("Enable Continuous Play", isOn: $settingsManager.continuousPlayEnabled)
                    }
                    
                    if settingsManager.continuousPlayEnabled {
                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                Image(systemName: "timer")
                                    .foregroundColor(.cyan)
                                Text("Pause Between Sentences")
                                Spacer()
                                Text(String(format: "%.1f s", settingsManager.pauseBetweenSentences))
                                    .foregroundColor(.secondary)
                            }
                            
                            Slider(value: $settingsManager.pauseBetweenSentences, in: 0.0...5.0, step: 0.5) {
                                Text("Pause Time")
                            } minimumValueLabel: {
                                Text("0s")
                                    .font(.caption)
                            } maximumValueLabel: {
                                Text("5s")
                                    .font(.caption)
                            }
                        }
                    }
                }
                
                // MARK: - Progress Management Section
                Section(header: Text("Progress Management")) {
                    // Clear All Progress
                    Button(action: {
                        clearAlertType = .all
                        showingClearAlert = true
                    }) {
                        HStack {
                            Image(systemName: "trash")
                                .foregroundColor(.red)
                            Text("Clear All Progress")
                                .foregroundColor(.red)
                        }
                    }
                    
                    // Reset Settings
                    Button(action: {
                        settingsManager.resetToDefaults()
                    }) {
                        HStack {
                            Image(systemName: "arrow.counterclockwise")
                                .foregroundColor(.orange)
                            Text("Reset to Default Settings")
                                .foregroundColor(.orange)
                        }
                    }
                }
                
                // MARK: - About Section
                Section(header: Text("About")) {
                    HStack {
                        Image(systemName: "info.circle")
                            .foregroundColor(.blue)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Version Info")
                            Text("Language Study v1.0")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    HStack {
                        Image(systemName: "book")
                            .foregroundColor(.green)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Course Structure")
                            Text("100 Lessons × 30 Sentences")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    HStack {
                       Image(systemName: "envelope")
                           .foregroundColor(.orange)
                       VStack(alignment: .leading, spacing: 2) {
                           Text("Support Email")
                           Text("share35app@gmail.com")
                               .font(.caption)
                               .foregroundColor(.secondary)
                       }
                   }
                    
                }
            }
            .navigationTitle("Settings")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Clear Progress", isPresented: $showingClearAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Clear", role: .destructive) {
                    switch clearAlertType {
                    case .all:
                        practiceDatabase.clearAllProgress()
                    case .current:
                        // This would require course context
                        break
                    }
                }
            } message: {
                Text(clearAlertType == .all ?
                     "Are you sure you want to clear all course progress? This action cannot be undone." :
                     "Are you sure you want to clear the current course progress? This action cannot be undone.")
            }
        }
    }
}

// MARK: - Preview
struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
