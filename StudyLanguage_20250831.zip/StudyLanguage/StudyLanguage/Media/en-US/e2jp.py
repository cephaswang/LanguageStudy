import sqlite3
import csv
from google.cloud import translate_v2 as translate
import os
import time

class EnglishToJapaneseTranslator:
    def __init__(self, project_id):
        """
        Initialize the translator with Google Cloud project ID
        
        Args:
            project_id (str): Your Google Cloud project ID
        """
        self.project_id = project_id
        # Initialize the Google Translate client
        os.environ['GOOGLE_CLOUD_PROJECT'] = project_id
        
        try:
            # Set the project environment variable for quota/billing
            os.environ['GOOGLE_CLOUD_PROJECT'] = project_id
            self.translate_client = translate.Client()
            print("Google Translate client initialized successfully!")
        except Exception as e:
            print(f"Failed to initialize Google Translate client: {e}")
            print("\nPlease ensure:")
            print("1. Google Cloud SDK is installed")
            print("2. Run: gcloud auth application-default login")
            print("3. Run: gcloud auth application-default set-quota-project digital-arcade-290923")
            print("4. Translation API is enabled in your project")
            raise
    
    def read_sql_file(self, sql_file_path):
        """
        Read and parse the SQL file to extract sentences
        
        Args:
            sql_file_path (str): Path to the SQL file
            
        Returns:
            list: List of tuples containing (sentence, topics_sn, sort_order)
        """
        sentences = []
        
        try:
            with open(sql_file_path, 'r', encoding='utf-8') as file:
                content = file.read()
                
            # Find all INSERT statements and extract sentence data
            import re
            
            # Pattern to match INSERT VALUES with sentence data
            pattern = r"\('([^']+(?:''[^']*)*)',(\d+),(\d+)\)"
            matches = re.findall(pattern, content)
            
            for match in matches:
                sentence = match[0].replace("''", "'")  # Handle escaped quotes
                topics_sn = int(match[1])
                sort_order = int(match[2])
                sentences.append((sentence, topics_sn, sort_order))
                
        except Exception as e:
            print(f"Error reading SQL file: {e}")
            
        return sentences
    
    def translate_to_japanese(self, text):
        """
        Translate English text to Japanese using Google Translate API
        
        Args:
            text (str): English text to translate
            
        Returns:
            str: Translated Japanese text
        """
        try:
            # Translate text to Japanese
            result = self.translate_client.translate(
                text,
                target_language='ja',
                source_language='en'
            )
            return result['translatedText']
        except Exception as e:
            print(f"Translation error for '{text}': {e}")
            return text  # Return original text if translation fails
    
    def translate_sentences_batch(self, sentences, batch_size=50):
        """
        Translate sentences in batches to avoid API limits
        
        Args:
            sentences (list): List of sentence tuples
            batch_size (int): Number of sentences to process at once
            
        Returns:
            list: List of tuples with translated sentences
        """
        translated_sentences = []
        total = len(sentences)
        
        print(f"Starting translation of {total} sentences...")
        
        for i in range(0, total, batch_size):
            batch = sentences[i:i + batch_size]
            batch_translations = []
            
            print(f"Processing batch {i//batch_size + 1}/{(total + batch_size - 1)//batch_size}")
            
            for sentence, topics_sn, sort_order in batch:
                japanese_text = self.translate_to_japanese(sentence)
                batch_translations.append((sentence, japanese_text, topics_sn, sort_order))
                
                # Small delay to respect API limits
                time.sleep(0.1)
            
            translated_sentences.extend(batch_translations)
            
            # Longer pause between batches
            if i + batch_size < total:
                print("Pausing between batches...")
                time.sleep(2)
        
        print("Translation completed!")
        return translated_sentences
    
    def save_to_sql(self, translated_sentences, output_file):
        """
        Save translated sentences to a new SQL file
        
        Args:
            translated_sentences (list): List of translated sentence tuples
            output_file (str): Output SQL file path
        """
        try:
            with open(output_file, 'w', encoding='utf-8') as file:
                file.write("BEGIN TRANSACTION;\n")
                file.write('DROP TABLE IF EXISTS "sentence_ja-JP";\n')
                file.write('CREATE TABLE "sentence_ja-JP" (\n')
                file.write('\t"sentence"\tTEXT,\n')
                file.write('\t"topics_sn"\tINTEGER,\n')
                file.write('\t"sort_order"\tINTEGER\n')
                file.write(');\n')
                file.write('INSERT INTO "sentence_ja-JP" ("sentence","topics_sn","sort_order") VALUES\n\n')
                
                for i, (original, japanese, topics_sn, sort_order) in enumerate(translated_sentences):
                    # Escape single quotes for SQL
                    japanese_escaped = japanese.replace("'", "''")
                    
                    if i == len(translated_sentences) - 1:
                        # Last row - no comma
                        file.write(f"('{japanese_escaped}',{topics_sn},{sort_order});\n")
                    else:
                        file.write(f"('{japanese_escaped}',{topics_sn},{sort_order}),\n")
                
                file.write("COMMIT;\n")
            
            print(f"SQL file saved to: {output_file}")
            
        except Exception as e:
            print(f"Error saving SQL file: {e}")
    
    def save_to_csv(self, translated_sentences, output_file):
        """
        Save translated sentences to CSV file
        
        Args:
            translated_sentences (list): List of translated sentence tuples
            output_file (str): Output CSV file path
        """
        try:
            with open(output_file, 'w', newline='', encoding='utf-8') as file:
                writer = csv.writer(file)
                writer.writerow(['original_english', 'japanese_translation', 'topics_sn', 'sort_order'])
                
                for original, japanese, topics_sn, sort_order in translated_sentences:
                    writer.writerow([original, japanese, topics_sn, sort_order])
            
            print(f"CSV file saved to: {output_file}")
            
        except Exception as e:
            print(f"Error saving CSV file: {e}")

def main():
    # Your Google Cloud project ID
    PROJECT_ID = "digital-arcade-290923"
    
    # File paths
    INPUT_SQL_FILE = "sentence_en-US.sql"  # Update this path as needed
    OUTPUT_SQL_FILE = "sentence_ja-JP.sql"
    OUTPUT_CSV_FILE = "translated_sentences.csv"
    
    # Initialize translator
    translator = EnglishToJapaneseTranslator(PROJECT_ID)
    
    # Read sentences from SQL file
    print("Reading sentences from SQL file...")
    sentences = translator.read_sql_file(INPUT_SQL_FILE)
    print(f"Found {len(sentences)} sentences to translate.")
    
    if not sentences:
        print("No sentences found. Please check the SQL file path and format.")
        return
    
    # Translate sentences
    translated_sentences = translator.translate_sentences_batch(sentences, batch_size=30)
    
    # Save results
    translator.save_to_sql(translated_sentences, OUTPUT_SQL_FILE)
    translator.save_to_csv(translated_sentences, OUTPUT_CSV_FILE)
    
    print("\nTranslation process completed!")
    print(f"- Original sentences: {len(sentences)}")
    print(f"- Translated sentences: {len(translated_sentences)}")
    print(f"- SQL output: {OUTPUT_SQL_FILE}")
    print(f"- CSV output: {OUTPUT_CSV_FILE}")

if __name__ == "__main__":
    # Make sure to set up authentication before running
    print("Google Cloud Translation - English to Japanese")
    print("=" * 50)
    
    # Check if Google Cloud credentials are set up
    try:
        import google.auth
        credentials, project = google.auth.default()
        print(f"Using Google Cloud project: {project}")
    except Exception as e:
        print("Warning: Google Cloud authentication not properly configured.")
        print("Please run: gcloud auth application-default login")
        print("Or set GOOGLE_APPLICATION_CREDENTIALS environment variable.")
        
    main()
