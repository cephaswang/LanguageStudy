from google.cloud import translate_v3 as translate

def translate_text(
    project_id: str,
    text: str,
    target_language: str,
    source_language: str = None # 可選，如果未指定，API會自動偵測
) -> str:
    """
    將提供的文字翻譯成目標語言。
    Args:
        project_id: 您的 Google Cloud 專案 ID。
        text: 要翻譯的文字內容。
        target_language: 目標語言的 ISO 639-1 代碼 (例如 'en' 代表英文，'zh-TW' 代表繁體中文)。
        source_language: 來源語言的 ISO 639-1 代碼 (例如 'fr' 代表法文)。可選。
    Returns:
        翻譯後的文字。
    """

    API_KEY = "YOUR_ACTUAL_API_KEY_HERE"
    client = translate.TranslationServiceClient(api_key=API_KEY)
    

    # 專案 ID 的完整路徑
    # 通常格式為 projects/YOUR_PROJECT_ID
    parent = f"projects/{project_id}"

    # 構建翻譯請求
    request = {
        "parent": parent,
        "contents": [text],
        "target_language_code": target_language,
    }

    if source_language:
        request["source_language_code"] = source_language

    response = client.translate_text(request=request)

    # 處理回應並返回翻譯結果
    translated_text = ""
    for translation in response.translations:
        translated_text += translation.translated_text
    
    return translated_text

# --- 如何使用 ---
if __name__ == "__main__":
    # 請替換為您的實際專案 ID
    # 範例中的 'digital-arcade-290923' 是您頁面中顯示的專案 ID
    my_project_id = "digital-arcade-290923" 

    text_to_translate = "Hello, world! How are you today?"
    target_lang = "zh-TW"  # 翻譯成繁體中文
    
    print(f"原始文字: {text_to_translate}")
    print(f"目標語言: {target_lang}")

    try:
        translated_result = translate_text(my_project_id, text_to_translate, target_lang)
        print(f"翻譯結果: {translated_result}")

        print("\n--- 另一個範例 (自動偵測來源語言) ---")
        text_to_translate_2 = "Hola mundo. ¿Cómo estás?"
        target_lang_2 = "en" # 翻譯成英文
        print(f"原始文字: {text_to_translate_2}")
        print(f"目標語言: {target_lang_2}")
        translated_result_2 = translate_text(my_project_id, text_to_translate_2, target_lang_2)
        print(f"翻譯結果: {translated_result_2}")

        print("\n--- 帶有來源語言的範例 ---")
        text_to_translate_3 = "Bonjour le monde!"
        target_lang_3 = "ja" # 翻譯成日文
        source_lang_3 = "fr" # 指定來源語言為法文
        print(f"原始文字: {text_to_translate_3}")
        print(f"目標語言: {target_lang_3}")
        print(f"來源語言: {source_lang_3}")
        translated_result_3 = translate_text(my_project_id, text_to_translate_3, target_lang_3, source_lang_3)
        print(f"翻譯結果: {translated_result_3}")

    except Exception as e:
        print(f"發生錯誤: {e}")
        print("請確認您的專案 ID 正確，Cloud Translation API 已啟用，且已設定驗證憑證。")


