import Foundation
import AVFoundation
import os.log
import Combine

class b05PlayService: NSObject, ObservableObject {
    // MARK: - Language Constants
    
    static let targetLanguage = "ru-RU" // Use BCP-47 code for Russian
    static let nativeLanguage = "en-US" // Use BCP-47 code for English
    static let targetLanguageVoice = "ru-RU" // Russian voice
    static let nativeLanguageVoice = "en-US" // English voice
    
    // MARK: - Properties
    @Published var isPlaying = false
    @Published var currentVerse = ""
    @Published var isPaused = false
    @Published var voiceAvailabilityError: String? // To notify UI of voice issues

    private let speechSynthesizer = AVSpeechSynthesizer()
    private let logger = Logger(subsystem: "org.share35app.BibleTTS", category: "b05PlayService")
    private var speechRate: Float = AVSpeechUtteranceDefaultSpeechRate
    private var currentVoice: AVSpeechSynthesisVoice?
    private var currentLocale: Locale = .init(identifier: targetLanguage)

    // MARK: - Initialization
    override init() {
        super.init()
        initializeTextToSpeech()
    }

    private func initializeTextToSpeech() {
        speechSynthesizer.delegate = self
        setLanguage(.init(identifier: Self.targetLanguage))
        
        if #available(iOS 14.0, *) {
            logger.info("TTS Service initializing...")
        }
        
        do {
            let audioSession = AVAudioSession.sharedInstance()
            try audioSession.setCategory(.playback, mode: .spokenAudio, options: [.mixWithOthers])
            try audioSession.setActive(true)
            logger.info("AVAudioSession configured for background playback")
        } catch {
            logger.error("Failed to configure AVAudioSession: \(error.localizedDescription)")
        }
        
        logger.info("TTS Initialized successfully")
    }

    // MARK: - Language Setting
    func setLanguage(_ locale: Locale) {
        currentLocale = locale
        let languageCode = locale.identifier
        logger.info("Attempting to set language to: \(languageCode)")
      //  let availableVoices = AVSpeechSynthesisVoice.speechVoices()
      //  logger.info("Available voices: \(availableVoices.map { $0.identifier })")
        
        if let voice = AVSpeechSynthesisVoice(language: languageCode) {
            currentVoice = voice
            voiceAvailabilityError = nil
            logger.info("Language set to: \(languageCode), Voice: \(voice.name)")
        } else {
            logger.error("Language not supported: \(languageCode). Falling back to en-US.")
            currentVoice = AVSpeechSynthesisVoice(language: "en-US")
            voiceAvailabilityError = "Ukrainian voice unavailable. Please download it from Settings > Accessibility > Spoken Content > Voices."
            if currentVoice == nil {
                logger.error("Fallback voice en-US also unavailable.")
                voiceAvailabilityError = "No voices available. Please check system settings."
            }
        }
    }

    // MARK: - Speech Rate Setting
    func setSpeechRate(_ rate: Float) {
        speechRate = rate
        logger.info("Speech rate set to: \(rate)")
    }

    // MARK: - Playback Methods
    func playVerse(_ verseText: String) {
        guard !isPlaying else { return }
        guard !verseText.isEmpty else {
            logger.error("Empty verse text provided")
            return
        }
        currentVerse = verseText
        isPlaying = true
        let utterance = AVSpeechUtterance(string: verseText)
        utterance.rate = speechRate
        utterance.voice = currentVoice ?? AVSpeechSynthesisVoice(language: "en-US") // Fallback if currentVoice is nil
        speechSynthesizer.speak(utterance)
        logger.info("Playing verse: \(verseText)")
    }

    func playVerse(_ verseText: String, book: String, chapter: String, verse: String) {
        guard !isPlaying else { return }
        guard !verseText.isEmpty else {
            logger.error("Empty verse text provided")
            return
        }
        currentVerse = verseText
        isPlaying = true
        let utterance = AVSpeechUtterance(string: verseText)
        utterance.rate = speechRate
        utterance.voice = currentVoice ?? AVSpeechSynthesisVoice(language: "en-US") // Fallback if currentVoice is nil
        speechSynthesizer.speak(utterance)
        logger.info("Playing verse: (Book: \(book), Chapter: \(chapter), Verse: \(verse))")
        logger.info("Verse content: \(verseText)")
    }

    func stopPlayback() {
        if isPlaying || isPaused {
            speechSynthesizer.stopSpeaking(at: .immediate)
            isPlaying = false
            isPaused = false
            currentVerse = ""
            logger.info("Playback stopped")
        }
    }

    func pauseResume() {
        if isPlaying {
            speechSynthesizer.pauseSpeaking(at: .word)
            isPlaying = false
            isPaused = true
            logger.info("Playback paused")
        } else {
            if speechSynthesizer.isPaused {
                speechSynthesizer.continueSpeaking()
                isPlaying = true
                isPaused = false
                logger.info("Playback resumed from pause")
            } else if !currentVerse.isEmpty {
                let utterance = AVSpeechUtterance(string: currentVerse)
                utterance.rate = speechRate
                utterance.voice = currentVoice ?? AVSpeechSynthesisVoice(language: "en-US")
                speechSynthesizer.speak(utterance)
                isPlaying = true
                isPaused = false
                logger.info("Resuming verse from start")
            }
        }
    }

    func saveVerseToFile(jsonArray: [[String: Any]], fileName: String) {
        do {
            let data = try JSONSerialization.data(withJSONObject: jsonArray, options: .prettyPrinted)
            let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent(fileName)
            try data.write(to: fileURL)
            logger.info("Verse saved to file: \(fileName)")
        } catch {
            logger.error("Error saving verse to file: \(error.localizedDescription)")
        }
    }

    // MARK: - Cleanup
    deinit {
        speechSynthesizer.stopSpeaking(at: .immediate)
        isPlaying = false
        logger.info("b05PlayService deinitialized")
    }
}

// MARK: - AVSpeechSynthesizerDelegate
extension b05PlayService: AVSpeechSynthesizerDelegate {
    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
        isPlaying = false
        isPaused = false
        logger.info("Playback completed")
    }

    func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didCancel utterance: AVSpeechUtterance) {
        isPlaying = false
        isPaused = false
        logger.info("Playback cancelled")
    }
}

